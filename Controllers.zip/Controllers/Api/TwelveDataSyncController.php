<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CoinPair;
use App\Models\MarketData;
use App\Services\TwelveDataService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class TwelveDataSyncController extends Controller
{
    public function sync(Request $request, TwelveDataService $td)
    {
        // عدد الأزواج اللي هنعملها Sync
        $limit = (int)($request->limit ?? 20);
        if ($limit <= 0 || $limit > 200) {
            $limit = 20;
        }

        // ✅ TTL للكاش بالثواني لتقليل credits (افتراضي 15 ثانية)
        // تقدر تغيره من الريكوست: /api/td/sync?limit=20&ttl=30
        $ttl = (int)($request->ttl ?? 15);
        if ($ttl < 5) $ttl = 5;
        if ($ttl > 300) $ttl = 300;

        try {
            $pairs = CoinPair::active()
                ->with('coin:id,symbol', 'market:id,currency_id', 'market.currency:id,symbol')
                ->orderBy('id', 'desc')
                ->take($limit)
                ->get();

            if ($pairs->isEmpty()) {
                return response()->json([
                    'success' => true,
                    'updated' => 0,
                    'data' => [],
                    'errors' => [],
                    'note' => 'No active pairs found',
                ]);
            }

            // ✅ Forex/Metals symbols (تتسعر BASE/QUOTE)
            $twoPartSymbols = [
                'EUR','GBP','JPY','AUD','CAD','NZD','CHF',
                'CNY','HKD','SGD','INR','MXN','ZAR','TRY',
                'XAU','XAG','XPT','XPD','XCU',
            ];

            // ✅ Indices mapping (حسب TwelveData الشائع — قابل للتعديل)
            $symbolMapping = [
                'NIKKEI' => 'N225',
                'HSI'    => 'HSI',
                'FTSE'   => 'FTSE',
                'SPX'    => 'SPX',
                'NDX'    => 'NDX',
                'DJI'    => 'DJI',
                'RUT'    => 'RUT',
                'VIX'    => 'VIX',
            ];

            $updated = 0;
            $data = [];
            $errors = [];

            foreach ($pairs as $pair) {
                $base  = $pair->coin->symbol ?? null;
                $quote = optional(optional($pair->market)->currency)->symbol ?? null;

                if (!$base || !$quote) {
                    $errors[] = [
                        'pair_id' => $pair->id,
                        'pair_symbol' => $pair->symbol,
                        'error' => 'Missing base/quote relation',
                    ];
                    continue;
                }

                // ✅ لو عندك لاحقاً عمود td_symbol في DB هيتاخد تلقائي
                $tdSymbol = $pair->td_symbol ?? null;

                if (!$tdSymbol) {
                    // Indices mapping (لو الـ base هو رمز مؤشر)
                    if (isset($symbolMapping[strtoupper($base)])) {
                        $tdSymbol = $symbolMapping[strtoupper($base)];
                    } elseif (in_array(strtoupper($base), $twoPartSymbols)) {
                        // Forex/Metals: BASE/QUOTE (EUR/USD, XAU/USD)
                        $tdSymbol = strtoupper($base) . '/' . strtoupper($quote);
                    } else {
                        // Stocks/Crypto: BASE فقط (AAPL, BTC)
                        $tdSymbol = strtoupper($base);
                    }
                }

                // ✅ Cache key لتقليل requests
                $cacheKey = 'td_quote:' . md5($tdSymbol);

                try {
                    $q = Cache::remember($cacheKey, $ttl, function () use ($td, $tdSymbol) {
                        return $td->quote($tdSymbol);
                    });

                    // السعر: TwelveData ساعات يرجع close أو price
                    $price = 0.0;
                    if (is_array($q)) {
                        if (isset($q['close'])) $price = (float)$q['close'];
                        elseif (isset($q['price'])) $price = (float)$q['price'];
                    }

                    if ($price <= 0) {
                        $errors[] = [
                            'pair_id' => $pair->id,
                            'pair_symbol' => $pair->symbol,
                            'td_symbol' => $tdSymbol,
                            'error' => 'Price not found or invalid',
                            'raw' => $q,
                        ];
                        continue;
                    }

                    $currencyId = (int)(optional($pair->market)->currency_id ?? 0);

                    MarketData::updateOrCreate(
                        [
                            'pair_id' => $pair->id,
                            'currency_id' => $currencyId,
                        ],
                        [
                            'price' => $price,
                            'symbol' => $pair->symbol, // نخزن symbol الحقيقي بتاع المنصة
                        ]
                    );

                    $updated++;
                    $data[] = [
                        'pair_id' => $pair->id,
                        'pair_symbol' => $pair->symbol,
                        'td_symbol' => $tdSymbol,
                        'price' => $price,
                        'cached_ttl' => $ttl,
                    ];

                } catch (\Throwable $e) {
                    $errors[] = [
                        'pair_id' => $pair->id,
                        'pair_symbol' => $pair->symbol,
                        'td_symbol' => $tdSymbol,
                        'error' => $e->getMessage(),
                    ];
                }
            }

            return response()->json([
                'success' => true,
                'updated' => $updated,
                'data' => $data,
                'errors' => $errors,
                'meta' => [
                    'limit' => $limit,
                    'ttl' => $ttl,
                ],
            ]);

        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
