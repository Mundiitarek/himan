{{-- Standalone Home Page (NO THEME HEADER/FOOTER) --}}
@php
    // لو عندك إعدادات RTL أو لغة… تقدر تتحكم هنا
    $pageTitle = $pageTitle ?? 'Golden Trade';
@endphp
<!doctype html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $pageTitle }}</title>

    {{-- لو عندك favicon --}}
    {{-- <link rel="icon" href="{{ asset('path/to/favicon.png') }}"> --}}

    <style>
        :root{
            --bg:#0b0f14;
            --bg2:#0e141b;
            --card:rgba(255,255,255,.06);
            --card2:rgba(255,255,255,.08);
            --stroke:rgba(255,255,255,.10);
            --text:rgba(255,255,255,.92);
            --muted:rgba(255,255,255,.65);
            --gold:#d2a44b;
            --gold2:#b9892e;
            --shadow: 0 18px 55px rgba(0,0,0,.55);
            --radius:18px;
        }

        *{ box-sizing:border-box; }
        body{
            margin:0;
            background: var(--bg);
            color: var(--text);
            font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, "Noto Sans", "Helvetica Neue", sans-serif;
        }
        a{ color:inherit; }

        .gt-wrap{
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
                radial-gradient(900px 520px at 40% 90%, rgba(255,255,255,.06), transparent 70%),
                linear-gradient(180deg, var(--bg) 0%, #0a0d12 100%);
            min-height: 100vh;
            padding: 28px 0 70px;
            position: relative;
            overflow: hidden;
        }

        .gt-noise{
            position:absolute; inset:0;
            background-image: radial-gradient(rgba(255,255,255,.06) 1px, transparent 1px);
            background-size: 22px 22px;
            opacity: .16;
            pointer-events:none;
            mix-blend-mode: overlay;
        }

        .gt-container{
            width:min(1180px, calc(100% - 28px));
            margin-inline:auto;
            position: relative;
            z-index: 2;
        }

        /* NAV */
        .gt-nav{
            position: sticky;
            top: 14px;
            z-index: 50;
            margin-bottom: 26px;
        }
        .gt-nav-inner{
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:14px;
            padding: 14px 18px;
            background: rgba(10,14,19,.72);
            border: 1px solid var(--stroke);
            border-radius: 16px;
            backdrop-filter: blur(10px);
            box-shadow: 0 10px 35px rgba(0,0,0,.35);
        }

        .gt-brand{
            display:flex; align-items:center; gap:10px;
            min-width: 220px;
        }

        /* ✅ LOGO LINK: غير href هنا للينك اللي انت عايزه */
        .gt-brand a{
            text-decoration:none;
            display:flex;
            align-items:center;
            gap:10px;
        }

        .gt-logo{
            width:34px; height:34px;
            display:grid; place-items:center;
            border-radius: 12px;
            background: linear-gradient(180deg, rgba(210,164,75,.25), rgba(210,164,75,.08));
            border: 1px solid rgba(210,164,75,.35);
            box-shadow: inset 0 0 0 1px rgba(255,255,255,.05);
            font-weight: 900;
            letter-spacing:.4px;
        }
        .gt-brand-title{
            font-weight: 800;
            letter-spacing:.4px;
            font-size: 14px;
            opacity: .95;
        }

        .gt-links{
            display:flex;
            align-items:center;
            gap: 18px;
            flex-wrap: wrap;
            justify-content:center;
        }
        .gt-links a{
            color: rgba(255,255,255,.78);
            text-decoration:none;
            font-size: 13px;
            padding: 8px 10px;
            border-radius: 12px;
            transition: .2s ease;
        }
        .gt-links a:hover{
            background: rgba(255,255,255,.06);
            color: rgba(255,255,255,.92);
        }

        .gt-cta{
            display:flex; align-items:center; gap:10px;
            min-width: 220px;
            justify-content:flex-start; /* عشان RTL */
        }

        .gt-btn{
            border: 0;
            cursor:pointer;
            text-decoration:none;
            display:inline-flex; align-items:center; justify-content:center;
            height: 38px;
            padding: 0 14px;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing:.2px;
            transition:.2s ease;
            white-space: nowrap;
        }
        .gt-btn-primary{
            color: #1a1408;
            background: linear-gradient(180deg, var(--gold) 0%, var(--gold2) 100%);
            box-shadow: 0 10px 24px rgba(210,164,75,.22);
        }
        .gt-btn-primary:hover{ transform: translateY(-1px); }
        .gt-btn-ghost{
            color: rgba(255,255,255,.86);
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
        }
        .gt-btn-ghost:hover{ background: rgba(255,255,255,.09); }

        /* HERO */
        .gt-hero{
            display:grid;
            grid-template-columns: 1.15fr .85fr;
            gap: 26px;
            align-items: stretch;
            margin-top: 14px;
        }

        .gt-hero-left{
            padding: 34px 28px;
            border-radius: 22px;
            border: 1px solid rgba(255,255,255,.10);
            background:
                radial-gradient(900px 300px at 0% 0%, rgba(210,164,75,.14), transparent 55%),
                linear-gradient(180deg, rgba(255,255,255,.06) 0%, rgba(255,255,255,.03) 100%);
            box-shadow: var(--shadow);
            position: relative;
            overflow:hidden;
        }

        .gt-badge{
            display:inline-flex;
            align-items:center;
            gap:8px;
            padding: 7px 10px;
            border-radius: 999px;
            font-size: 12px;
            color: rgba(255,255,255,.82);
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
        }
        .gt-dot{
            width:8px; height:8px; border-radius:50%;
            background: var(--gold);
            box-shadow: 0 0 0 4px rgba(210,164,75,.18);
        }

        .gt-title{
            margin: 14px 0 10px;
            font-size: clamp(28px, 4vw, 44px);
            line-height: 1.08;
            font-weight: 900;
            letter-spacing: -.6px;
        }
        .gt-sub{
            margin: 0 0 18px;
            color: var(--muted);
            font-size: 14px;
            max-width: 54ch;
            line-height: 1.7;
        }

        .gt-actions{
            display:flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 16px;
        }

        .gt-metrics{
            display:flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 18px;
        }
        .gt-pill{
            display:flex;
            align-items:center;
            gap: 8px;
            padding: 10px 12px;
            border-radius: 14px;
            background: rgba(255,255,255,.05);
            border: 1px solid rgba(255,255,255,.10);
            color: rgba(255,255,255,.80);
            font-size: 12px;
        }
        .gt-pill i{
            width: 22px; height: 22px;
            border-radius: 10px;
            display:grid; place-items:center;
            background: rgba(210,164,75,.14);
            border: 1px solid rgba(210,164,75,.28);
            color: var(--gold);
            font-style: normal;
            font-weight: 900;
            font-size: 12px;
        }

        .gt-hero-right{
            border-radius: 22px;
            border: 1px solid rgba(255,255,255,.10);
            background: linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,.02));
            box-shadow: var(--shadow);
            padding: 18px;
            position: relative;
            overflow:hidden;
        }

        .gt-mini-card{
            border-radius: 18px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(15,20,26,.68);
            backdrop-filter: blur(10px);
            padding: 16px;
        }
        .gt-mini-head{
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom: 10px;
            color: rgba(255,255,255,.78);
            font-size: 12px;
        }
        .gt-chart{
            width:100%;
            height: 150px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,.08);
            background: radial-gradient(400px 160px at 30% 30%, rgba(210,164,75,.15), transparent 60%),
                        rgba(255,255,255,.03);
            position: relative;
            overflow:hidden;
        }
        .gt-chart svg{ width:100%; height:100%; display:block; opacity:.9; }
        .gt-bubbles{
            display:flex; gap:10px;
            justify-content:flex-start; /* RTL */
            margin-top: 12px;
            flex-wrap: wrap;
        }
        .gt-bubble{
            border-radius: 999px;
            padding: 9px 12px;
            font-size: 12px;
            color: rgba(255,255,255,.82);
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.05);
        }
        .gt-bubble strong{ color: var(--gold); font-weight:900; }

        /* SECTION TITLES */
        .gt-section{ margin-top: 26px; }
        .gt-h2{ font-size: 18px; letter-spacing: .2px; margin: 0 0 10px; }
        .gt-p{ margin: 0 0 16px; color: var(--muted); font-size: 13px; line-height: 1.7; }

        /* GRID */
        .gt-grid{
            display:grid;
            grid-template-columns: repeat(12, 1fr);
            gap: 14px;
        }
        .gt-card{
            grid-column: span 3;
            border-radius: 18px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
            box-shadow: 0 14px 40px rgba(0,0,0,.35);
            padding: 16px 16px 14px;
            min-height: 140px;
        }
        .gt-ic{
            width: 44px; height: 44px;
            border-radius: 16px;
            display:grid; place-items:center;
            background: rgba(210,164,75,.14);
            border: 1px solid rgba(210,164,75,.28);
            margin-bottom: 10px;
            color: var(--gold);
            font-weight: 900;
        }
        .gt-card h3{ margin: 0 0 6px; font-size: 13px; color: rgba(255,255,255,.90); }
        .gt-card p{ margin:0; font-size: 12px; color: rgba(255,255,255,.65); line-height: 1.6; }

        .gt-sidecard{
            grid-column: span 4;
            border-radius: 18px;
            border: 1px solid rgba(210,164,75,.22);
            background:
                radial-gradient(550px 220px at 25% 25%, rgba(210,164,75,.18), transparent 60%),
                rgba(255,255,255,.04);
            padding: 16px;
            min-height: 220px;
            box-shadow: 0 18px 55px rgba(0,0,0,.4);
        }
        .gt-sidecard .gt-mini-head{ margin-bottom: 8px; }
        .gt-sidecard .gt-chart{ height: 170px; }

        /* PRICING */
        .gt-price-row{
            display:grid;
            grid-template-columns: repeat(12, 1fr);
            gap: 14px;
            margin-top: 10px;
        }
        .gt-person{
            grid-column: span 3;
            border-radius: 18px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
            padding: 16px;
            min-height: 170px;
            display:flex;
            flex-direction: column;
            gap: 10px;
            justify-content: space-between;
        }
        .gt-avatar{
            width: 44px; height: 44px;
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,.12);
            background: rgba(255,255,255,.06);
            display:grid; place-items:center;
            color: rgba(255,255,255,.75);
            font-weight: 900;
        }
        .gt-person small{ color: rgba(255,255,255,.65); }

        .gt-plan{
            grid-column: span 3;
            border-radius: 18px;
            border: 1px solid rgba(210,164,75,.35);
            background:
                radial-gradient(650px 260px at 30% 20%, rgba(210,164,75,.18), transparent 60%),
                rgba(255,255,255,.04);
            padding: 16px;
            min-height: 170px;
            box-shadow: 0 18px 55px rgba(0,0,0,.45);
            position: relative;
        }
        .gt-plan .tag{
            position:absolute;
            top: 12px; left: 12px; /* RTL */
            font-size: 11px;
            padding: 6px 10px;
            border-radius: 999px;
            background: rgba(210,164,75,.16);
            border: 1px solid rgba(210,164,75,.28);
            color: rgba(255,255,255,.82);
        }
        .gt-plan h3{ margin: 2px 0 4px; font-size: 14px; }
        .gt-price{
            font-size: 36px;
            font-weight: 900;
            letter-spacing: -.8px;
            margin: 0;
        }
        .gt-price span{ font-size: 12px; color: rgba(255,255,255,.65); font-weight: 700; }
        .gt-list{ margin: 10px 0 0; padding:0; list-style:none; }
        .gt-list li{
            display:flex; gap:8px;
            align-items:flex-start;
            color: rgba(255,255,255,.72);
            font-size: 12px;
            margin: 8px 0;
        }
        .gt-list li b{
            color: var(--gold);
            font-weight: 900;
            margin-top: 1px;
        }

        /* FAQ */
        .gt-faq{
            display:grid;
            grid-template-columns: 1.2fr .8fr;
            gap: 14px;
            align-items:start;
            margin-top: 10px;
        }
        .gt-accordion{
            border-radius: 18px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
            overflow:hidden;
        }
        .gt-q{
            width:100%;
            text-align:right; /* RTL */
            padding: 14px 14px;
            border:0;
            background: transparent;
            color: rgba(255,255,255,.88);
            cursor:pointer;
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:10px;
            border-bottom: 1px solid rgba(255,255,255,.08);
            font-size: 13px;
            font-weight: 800;
        }
        .gt-q:last-child{ border-bottom: 0; }
        .gt-a{
            padding: 0 14px 14px;
            color: rgba(255,255,255,.66);
            font-size: 12px;
            line-height: 1.8;
            display:none;
        }
        .gt-q[aria-expanded="true"] + .gt-a{ display:block; }

        .gt-faq-side{
            border-radius: 18px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
            padding: 16px;
        }

        /* CTA */
        .gt-cta-bar{
            margin-top: 18px;
            border-radius: 20px;
            border: 1px solid rgba(210,164,75,.35);
            background: linear-gradient(90deg, rgba(210,164,75,.18), rgba(210,164,75,.08));
            padding: 18px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap: 14px;
            flex-wrap: wrap;
        }
        .gt-cta-bar h3{ margin: 0; font-size: 16px; letter-spacing:.2px; }
        .gt-cta-bar p{ margin: 4px 0 0; color: rgba(255,255,255,.70); font-size: 12px; }

        /* Simple footer (اختياري) */
        .gt-footer{
            margin-top: 22px;
            padding-top: 16px;
            border-top: 1px solid rgba(255,255,255,.08);
            display:flex;
            gap: 10px;
            justify-content: space-between;
            flex-wrap: wrap;
            color: rgba(255,255,255,.55);
            font-size: 12px;
        }

        /* RESPONSIVE */
        @media (max-width: 980px){
            .gt-hero{ grid-template-columns: 1fr; }
            .gt-card{ grid-column: span 6; }
            .gt-sidecard{ grid-column: span 12; }
            .gt-person{ grid-column: span 6; }
            .gt-plan{ grid-column: span 6; }
            .gt-faq{ grid-template-columns: 1fr; }
            .gt-brand, .gt-cta{ min-width: auto; }
        }
        @media (max-width: 560px){
            .gt-links{ display:none; }
            .gt-card{ grid-column: span 12; }
            .gt-person{ grid-column: span 12; }
            .gt-plan{ grid-column: span 12; }
            .gt-hero-left{ padding: 28px 18px; }
            .gt-hero-right{ padding: 14px; }
        }
    </style>
</head>

<body>
<div class="gt-wrap">
    <div class="gt-noise"></div>

    <div class="gt-container">

        {{-- NAVBAR (ده الجديد بتاعنا فقط) --}}
        <div class="gt-nav" id="top">
            <div class="gt-nav-inner">
                <div class="gt-brand">
                    {{-- ✅ غير href ده للينك اللي انت عايزه للوجو --}}
                    <a href="{{ url('/') }}">
                        <div class="gt-logo">GT</div>
                        <div class="gt-brand-title">GOLDEN TRADE</div>
                    </a>
                </div>

                <div class="gt-links">
                    <a href="#home">الرئيسية</a>
                    <a href="#features">المميزات</a>
                    <a href="#pricing">الخطط</a>
                    <a href="#faq">FAQ</a>
                    <a href="#contact">تواصل</a>
                </div>

                <div class="gt-cta">
                    <a class="gt-btn gt-btn-ghost" href="#pricing">View Plans</a>
                    <a class="gt-btn gt-btn-primary" href="{{ url('user/register') }}">Get Started</a>
                </div>
            </div>
        </div>

        {{-- HERO --}}
        <div class="gt-hero" id="home">
            <div class="gt-hero-left">
                <div class="gt-badge"><span class="gt-dot"></span> منصة استثمار ذكية</div>
                <h1 class="gt-title">Trade Smarter. Grow Faster.</h1>
                <p class="gt-sub">
                    أدوات حديثة، بيانات لحظية، وتجربة استخدام أنيقة تساعدك تتابع السوق وتنفّذ قراراتك بثقة.
                </p>

                <div class="gt-actions">
                    <a class="gt-btn gt-btn-primary" href="{{ url('user/register') }}">Get Started</a>
                    <a class="gt-btn gt-btn-ghost" href="#features">View Demo</a>
                </div>

                <div class="gt-metrics">
                    <div class="gt-pill"><i>✓</i> Secure</div>
                    <div class="gt-pill"><i>⏱</i> Real-time Data</div>
                    <div class="gt-pill"><i>★</i> Low Fees</div>
                </div>
            </div>

            <div class="gt-hero-right">
                <div class="gt-mini-card">
                    <div class="gt-mini-head">
                        <span>Dashboard</span>
                        <span>⚙</span>
                    </div>

                    <div class="gt-chart">
                        <svg viewBox="0 0 600 200" preserveAspectRatio="none" aria-hidden="true">
                            <path d="M0,140 C60,120 90,170 140,130 C190,90 220,120 260,100 C300,80 330,120 370,95 C410,70 440,110 480,80 C520,55 560,70 600,50"
                                  fill="none" stroke="rgba(210,164,75,.85)" stroke-width="3"/>
                            <path d="M0,200 L0,140 C60,120 90,170 140,130 C190,90 220,120 260,100 C300,80 330,120 370,95 C410,70 440,110 480,80 C520,55 560,70 600,50 L600,200 Z"
                                  fill="rgba(210,164,75,.12)"/>
                        </svg>
                    </div>

                    <div class="gt-bubbles">
                        <div class="gt-bubble"><strong>+12%</strong> Today</div>
                        <div class="gt-bubble"><strong>+138%</strong> YTD</div>
                    </div>
                </div>
            </div>
        </div>

        {{-- ✅ أسعار العملات (هنا بتحط كودك القديم فقط) --}}
        <div class="gt-section" id="currency">
            <h2 class="gt-h2">أسعار العملات</h2>
            <p class="gt-p">الصق هنا “سيكشن الأسعار” من الكود القديم زي ما هو، وسيب باقي الصفحة على التصميم الجديد.</p>

            {{-- ✅ PASTE YOUR CURRENCY PRICES SECTION HERE --}}
            {{-- مثال ديمو (امسحه أول ما تلزق كودك الحقيقي) --}}
            @php
                $demoPrices = $demoPrices ?? [
                    ['symbol'=>'BTC/USDT','price'=>'42,120.50','change'=>'+1.82%'],
                    ['symbol'=>'ETH/USDT','price'=>'2,318.10','change'=>'-0.44%'],
                    ['symbol'=>'BNB/USDT','price'=>'312.60','change'=>'+0.21%'],
                    ['symbol'=>'SOL/USDT','price'=>'98.44','change'=>'+3.11%'],
                ];
            @endphp

            <div class="gt-grid" style="margin-top:10px;">
                @foreach($demoPrices as $c)
                    <div class="gt-card" style="grid-column: span 3;">
                        <div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">
                            <div style="font-weight:900; letter-spacing:.2px;">{{ $c['symbol'] }}</div>
                            @php
                                $isPlus = str_starts_with($c['change'], '+');
                                $chgColor = $isPlus ? 'rgba(210,164,75,.92)' : 'rgba(255,120,120,.92)';
                            @endphp
                            <div style="font-size:12px; color: {{ $chgColor }};">
                                {{ $c['change'] }}
                            </div>
                        </div>
                        <div style="margin-top:10px; font-size:26px; font-weight:900; letter-spacing:-.6px;">
                            {{ $c['price'] }}
                        </div>
                        <div style="margin-top:6px; color:rgba(255,255,255,.6); font-size:12px;">
                            Updated just now
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

        {{-- FEATURES --}}
        <div class="gt-section" id="features">
            <h2 class="gt-h2">Unlock Powerful Features</h2>
            <p class="gt-p">Tools designed to help you track markets and make smarter decisions.</p>

            <div class="gt-grid">
                <div class="gt-card">
                    <div class="gt-ic">▦</div>
                    <h3>Advanced Charting</h3>
                    <p>Track price action with clean charts and key indicators.</p>
                </div>
                <div class="gt-card">
                    <div class="gt-ic">⌕</div>
                    <h3>Real-time Data</h3>
                    <p>Get instant updates and monitor volatility in seconds.</p>
                </div>
                <div class="gt-card">
                    <div class="gt-ic">⛨</div>
                    <h3>Risk Controls</h3>
                    <p>Smart limits and alerts to protect your positions.</p>
                </div>
                <div class="gt-card">
                    <div class="gt-ic">⦿</div>
                    <h3>Global Markets</h3>
                    <p>Follow multiple assets with unified watchlists.</p>
                </div>

                <div class="gt-sidecard">
                    <div class="gt-mini-head">
                        <span>Elite Plan</span>
                        <span>★</span>
                    </div>
                    <div class="gt-chart">
                        <svg viewBox="0 0 600 200" preserveAspectRatio="none" aria-hidden="true">
                            <path d="M0,150 C50,140 90,100 140,120 C190,140 220,80 260,95 C300,110 330,60 370,90 C410,120 440,70 480,85 C520,100 560,60 600,70"
                                  fill="none" stroke="rgba(210,164,75,.85)" stroke-width="3"/>
                            <path d="M0,200 L0,150 C50,140 90,100 140,120 C190,140 220,80 260,95 C300,110 330,60 370,90 C410,120 440,70 480,85 C520,100 560,60 600,70 L600,200 Z"
                                  fill="rgba(210,164,75,.12)"/>
                        </svg>
                    </div>
                    <div class="gt-bubbles">
                        <div class="gt-bubble"><strong>$179</strong> / month</div>
                        <div class="gt-bubble">Priority Support</div>
                    </div>
                </div>
            </div>
        </div>

        {{-- PRICING --}}
        <div class="gt-section" id="pricing">
            <h2 class="gt-h2">Transparent Pricing</h2>
            <p class="gt-p">Choose a plan that fits your needs.</p>

            <div class="gt-price-row">
                <div class="gt-person">
                    <div style="display:flex; gap:10px; align-items:center;">
                        <div class="gt-avatar">JS</div>
                        <div>
                            <div style="font-weight:900;">John S.</div>
                            <small>Pro Trader</small>
                        </div>
                    </div>
                    <div style="color:rgba(255,255,255,.68); font-size:12px; line-height:1.7;">
                        “The dashboard is clean and fast. I can track everything بسهولة.”
                    </div>
                </div>

                <div class="gt-person">
                    <div style="display:flex; gap:10px; align-items:center;">
                        <div class="gt-avatar">ML</div>
                        <div>
                            <div style="font-weight:900;">Mona L.</div>
                            <small>Investment Analyst</small>
                        </div>
                    </div>
                    <div style="color:rgba(255,255,255,.68); font-size:12px; line-height:1.7;">
                        “Real-time data and alerts helped me reduce risk بشكل واضح.”
                    </div>
                </div>

                <div class="gt-plan">
                    <div class="tag">Most Popular</div>
                    <small style="color:rgba(255,255,255,.70); font-weight:800;">Basic</small>
                    <h3>Pro Plan</h3>
                    <p class="gt-price">$49 <span>/month</span></p>
                    <ul class="gt-list">
                        <li><b>✓</b> Live prices & watchlists</li>
                        <li><b>✓</b> Advanced charts</li>
                        <li><b>✓</b> Alerts & notifications</li>
                    </ul>
                    <div style="margin-top:12px;">
                        <a class="gt-btn gt-btn-primary" href="{{ url('user/register') }}" style="width:100%;">Choose Plan</a>
                    </div>
                </div>

                <div class="gt-person">
                    <div style="display:flex; gap:10px; align-items:center;">
                        <div class="gt-avatar">MR</div>
                        <div>
                            <div style="font-weight:900;">Mahmoud R.</div>
                            <small>Account Manager</small>
                        </div>
                    </div>
                    <div style="color:rgba(255,255,255,.68); font-size:12px; line-height:1.7;">
                        “Support سريع وواجهة مستخدم ممتازة.”
                    </div>
                </div>
            </div>
        </div>

        {{-- FAQ + CONTACT --}}
        <div class="gt-section" id="faq">
            <div class="gt-faq">
                <div class="gt-accordion">
                    <button class="gt-q" aria-expanded="true">ما هي Golden Trade؟ <span>▾</span></button>
                    <div class="gt-a">دي واجهة Landing حديثة. اربطها بباك إند الأسعار والتداول بتاعك.</div>

                    <button class="gt-q" aria-expanded="false">الأسعار Real-time؟ <span>▾</span></button>
                    <div class="gt-a">اه لو كود الأسعار القديم عندك بيجيب Live من API، سيبه زي ما هو في مكان الأسعار.</div>

                    <button class="gt-q" aria-expanded="false">أقدر أغير الخطط؟ <span>▾</span></button>
                    <div class="gt-a">أكيد—عدّل كروت الخطط وزر الاشتراك حسب نظامك.</div>

                    <button class="gt-q" aria-expanded="false">الموبايل؟ <span>▾</span></button>
                    <div class="gt-a">التصميم Responsive وبيتكيف تلقائيًا على الشاشات الصغيرة.</div>
                </div>

                <div class="gt-faq-side" id="contact">
                    <div style="display:flex; align-items:center; justify-content:space-between;">
                        <div style="font-weight:900;">تحتاج مساعدة؟</div>
                        <div style="opacity:.8;">✦</div>
                    </div>
                    <p class="gt-p" style="margin-top:8px;">
                        حط هنا بيانات التواصل أو لينك واتساب/تيليجرام/الدعم.
                    </p>
                    <a class="gt-btn gt-btn-ghost" href="#" style="width:100%;">Contact Support</a>
                </div>
            </div>

            <div class="gt-cta-bar">
                <div>
                    <h3>Ready to start with GOLDEN TRADE?</h3>
                    <p>ابدأ حسابك دلوقتي وجرّب تجربة استثمار أفضل.</p>
                </div>
                <a class="gt-btn gt-btn-primary" href="{{ url('user/register') }}">Create Account</a>
            </div>

            <div class="gt-footer">
                <div>© {{ date('Y') }} Golden Trade</div>
                <div style="opacity:.8;">All rights reserved</div>
            </div>
        </div>

    </div>
</div>

<script>
    // FAQ Accordion
    (function(){
        const qs = document.querySelectorAll('.gt-q');
        qs.forEach(btn=>{
            btn.addEventListener('click', ()=>{
                const expanded = btn.getAttribute('aria-expanded') === 'true';
                // close others
                qs.forEach(b=> b.setAttribute('aria-expanded','false'));
                btn.setAttribute('aria-expanded', expanded ? 'false' : 'true');
            });
        });
    })();
</script>

</body>
</html>
