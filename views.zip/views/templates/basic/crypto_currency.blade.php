@extends($activeTemplate.'layouts.frontend')
@section('content')

@push('style')
<style>
  header, .header, .header-section, .navbar-area, .menu-area, .site-header,
  footer, .footer, .footer-section, .footer-area { display:none !important; }

  :root{
    --bg:#0b0f14; --stroke:rgba(255,255,255,.10);
    --text:rgba(255,255,255,.92); --muted:rgba(255,255,255,.65);
    --gold:#d2a44b; --gold2:#b9892e;
  }
  body{ background:var(--bg) !important; color:var(--text); }
  .gt-wrap{
    background:
      radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
      radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
      linear-gradient(180deg, var(--bg), #0a0d12);
    min-height:100vh; padding:28px 0 70px;
  }
  .gt-container{ width:min(1180px, calc(100% - 28px)); margin-inline:auto; }
  .gt-nav{ position: sticky; top:14px; z-index:50; margin-bottom:22px; }
  .gt-nav-inner{ display:flex; justify-content:space-between; align-items:center; gap:14px; padding:14px 18px; border-radius:16px; background:rgba(10,14,19,.72); border:1px solid var(--stroke); backdrop-filter: blur(10px); }
  .gt-brand a{ text-decoration:none; display:flex; gap:10px; align-items:center; color:var(--text); }
  .gt-logo{ width:34px;height:34px;display:grid;place-items:center;border-radius:12px;background:linear-gradient(180deg,rgba(210,164,75,.25),rgba(210,164,75,.08));border:1px solid rgba(210,164,75,.35);font-weight:900; }

  .gt-hero{
    border-radius:22px; border:1px solid rgba(255,255,255,.10);
    background: radial-gradient(900px 300px at 0% 0%, rgba(210,164,75,.14), transparent 55%),
                linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.03));
    padding:22px; box-shadow: 0 18px 55px rgba(0,0,0,.45);
    margin-bottom: 16px;
  }
  .gt-title{ margin:0 0 6px; font-weight:900; font-size:22px; }
  .gt-sub{ margin:0; color:var(--muted); font-size:13px; line-height:1.8; }

  /* Search */
  .market-list-search{ display:flex; justify-content:flex-end; }
  .market-list-search .form--control{
    width:min(360px, 100%); border-radius:14px;
    border:1px solid rgba(255,255,255,.10) !important;
    background: rgba(255,255,255,.04) !important;
    color: var(--text) !important;
    padding: 10px 12px !important;
  }

  /* Table */
  .table-section, .section-bg{ background: transparent !important; }
  .table-wrapper{
    border-radius:18px; border:1px solid rgba(255,255,255,.10);
    background: rgba(255,255,255,.04);
    box-shadow: 0 18px 55px rgba(0,0,0,.35);
    overflow:hidden;
  }
  .coin-pair-list-table thead th{
    background: rgba(255,255,255,.04) !important;
    color: rgba(255,255,255,.85) !important;
    border-bottom: 1px solid rgba(255,255,255,.10) !important;
  }
  .coin-pair-list-table td{
    border-color: rgba(255,255,255,.08) !important;
    color: rgba(255,255,255,.78) !important;
  }
  .customer__name{ color: rgba(255,255,255,.88) !important; }
  .crypto-symbol{ font-size:12px; color: rgba(255,255,255,.65) !important; }

  /* Load more */
  .load-more-market-list{
    border-radius:14px !important;
    border: 1px solid rgba(210,164,75,.35) !important;
    background: rgba(210,164,75,.10) !important;
    color: rgba(255,255,255,.90) !important;
    font-weight:900 !important;
  }
</style>
@endpush

<div class="gt-wrap">
  <div class="gt-container">

    <div class="gt-nav">
      <div class="gt-nav-inner">
        <div class="gt-brand">
          <a href="{{ url('/') }}"><div class="gt-logo">GT</div><div style="font-weight:900;">GOLDEN TRADE</div></a>
        </div>
        <div style="display:flex;gap:10px;">
          <a href="{{ url('market-list') }}" style="text-decoration:none;color:rgba(255,255,255,.8);font-size:13px;">Markets</a>
          <a href="{{ url('contact') }}" style="text-decoration:none;color:rgba(255,255,255,.8);font-size:13px;">Contact</a>
        </div>
      </div>
    </div>

    <div class="gt-hero">
      <div style="display:flex;gap:14px;align-items:center;justify-content:space-between;flex-wrap:wrap;">
        <div>
          <h4 class="gt-title">{{ __($pageTitle) }}</h4>
          <p class="gt-sub">@lang('Explore available Cryptocurrency on ') {{ __(gs('site_name')) }}</p>
        </div>

        <form class="market-list-search">
          <input type="search" name="search" class="form-control form--control" placeholder="@lang('Search here ')...">
        </form>
      </div>
    </div>

    <div class="row mt-4 justify-content-center gy-4">
      <div class="col-lg-4 col-md-6"><x-flexible-view :view="$activeTemplate.'coin.top_exchange_coin'"/></div>
      <div class="col-lg-4 col-md-6"><x-flexible-view :view="$activeTemplate.'coin.highlight_coin'"/></div>
      <div class="col-lg-4 col-md-6"><x-flexible-view :view="$activeTemplate.'coin.new_coin'"/></div>
    </div>

    <div class="py-60 table-section" style="padding-top:14px;">
      <div class="table-wrapper">
        <table class="table coin-pair-list-table table--responsive--lg coin-pair-list">
          <thead>
            <tr>
              <th>@lang('Crypto')</th>
              <th>@lang('Price')</th>
              <th>@lang('1h Change')</th>
              <th>@lang('24h Change')</th>
              <th>@lang('7d Change')</th>
              <th>@lang('Marketcap')</th>
            </tr>
          </thead>
          <tbody id="market-list-body"></tbody>
        </table>

        <div class="text-center" style="padding:16px;">
          <button type="button" class="btn btn--base outline btn--sm load-more-market-list">
            <i class="fa fa-spinner"></i> @lang('Load More')
          </button>
        </div>
      </div>
    </div>

    @if ($sections && $sections->secs != null)
      @foreach (json_decode($sections->secs) as $sec)
        @include($activeTemplate . 'sections.' . $sec)
      @endforeach
    @endif

  </div>
</div>

@endsection

@push('script')
<script>
"use strict";
(function($) {

  @if (!app()->offsetExists('lisiten_market_data_event'))
    pusherConnection('market-data', marketChangeHtml);
    @php app()->offsetSet('lisiten_market_data_event',true) @endphp
  @endif

  let skip     = 0;
  let limit    = 10;
  let search   = "";
  let loadMore = false;

  $('.load-more-market-list').on('click',function (e) {
    loadMore = true;
    getCryptoCurrencyList();
  });

  $('.market-list-search').on('submit',function(e){
    e.preventDefault();
    search=$(this).find('input[name=search]').val()
    loadMore=false;
    skip=0;
    limit=10;
    getCryptoCurrencyList();
  });

  function getCryptoCurrencyList() {
    let action = "{{ route('crypto_currency.list') }}";
    $.ajax({
      url: action,
      type: "GET",
      dataType: 'json',
      cache: false,
      data: { skip, limit, search },
      beforeSend:function(){
        if(loadMore){ $('.load-more-market-list').html(`<i class="fa fa-spinner fa-spin"></i>`) }
      },
      complete:function(){
        if(loadMore){
          $('.load-more-market-list').html(`<i class="fa fa-spinner"></i> @lang('Load More')`)
        }else{
          setTimeout(() => { $('.coin-pair-list tr').removeClass('skeleton'); }, 1000);
        }
      },
      success: function(resp) {
        if (!resp.success) { notify('error', resp.message); return false; }

        let html = '';
        if (resp.currencies.length <= 0) {
          html += `<tr class="text-center">
            <td colspan="100%">
              <div class="empty-thumb">
                <img src="{{ asset('assets/images/extra_images/empty.png') }}"/>
                <p class="empty-sell">${loadMore ? 'No more crypto currency found' : 'No crypto currency found'}</p>
              </div>
            </td>
          </tr>`;
          $('.load-more-market-list').addClass('d-none');
          loadMore ? $('#market-list-body').append(html) : $('#market-list-body').html(html);
          return;
        }

        $.each(resp.currencies || [], function(i, currency) {
          let marketData = currency.market_data;
          let htmlClass  = marketData.html_classes || {};

          html += `
          <tr class="${!loadMore ? 'skeleton' : ''}">
            <td>
              <div class="customer d-flex align-items-center">
                <div class="pair-thumb">
                  <div class="coin-img-one">
                    <img src="${currency.image_url}">
                  </div>
                </div>
                <div class="customer__content">
                  <h6 class="customer__name">${currency.name}</h6>
                  <h6 class="customer__name crypto-symbol">${currency.symbol}</h6>
                </div>
              </div>
            </td>
            <td>
              <span class="market-price-${marketData.id} ${htmlClass.price_change != undefined ? htmlClass.price_change : '' }">
                ${showAmount(marketData.price)}
              </span>
            </td>
            <td>
              <span class="market-percent-change-1h-${marketData.id} ${htmlClass.percent_change_1h || ''}">
                ${showAmount(marketData.percent_change_1h,2)}%
              </span>
            </td>
            <td>
              <span class="market-percent-change-24h-${marketData.id} ${htmlClass.percent_change_24h || ''}">
                ${showAmount(marketData.percent_change_24h,2)}%
              </span>
            </td>
            <td>
              <span class="market-percent-change-24h-${marketData.id} ${htmlClass.percent_change_7d || ''}">
                ${showAmount(marketData.percent_change_7d,2)}%
              </span>
            </td>
            <td>
              <span class="market-market_cap-${marketData.id}">${showAmount(marketData.market_cap)}</span>
            </td>
          </tr>`;
        });

        $('.load-more-market-list').removeClass('d-none');
        loadMore ? $('#market-list-body').append(html) : $('#market-list-body').html(html);

        if(skip == 0){ tableDataLabel(); }
        skip += parseInt(limit);

        if(parseInt(skip) >= parseInt(resp.total)){
          $('.load-more-market-list').addClass('d-none')
        }else{
          $('.load-more-market-list').removeClass('d-none')
        }
      }
    });
  }

  getCryptoCurrencyList();

})(jQuery);
</script>
@endpush

@if (!app()->offsetExists('pusher_script'))
@push('script-lib')
<script src="{{ asset('assets/global/js/pusher.min.js') }}"></script>
<script src="{{ asset('assets/global/js/broadcasting.js') }}"></script>
@endpush
@php app()->offsetSet('pusher_script',true) @endphp
@endif

@push('style')
<style>
  .crypto-symbol{ font-size:12px; }
</style>
@endpush
