@extends($activeTemplate.'layouts.frontend')
@section('content')

@push('style')
<style>
  header, .header, .header-section, .navbar-area, .menu-area, .site-header,
  footer, .footer, .footer-section, .footer-area { display:none !important; }

  :root{ --bg:#0b0f14; --stroke:rgba(255,255,255,.10); --text:rgba(255,255,255,.92); --muted:rgba(255,255,255,.65); --gold:#d2a44b; --gold2:#b9892e; }
  body{ background:var(--bg) !important; color:var(--text); }
  .gt-wrap{ background: radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%), linear-gradient(180deg, var(--bg), #0a0d12); min-height:100vh; padding:28px 0 70px; }
  .gt-container{ width:min(1180px, calc(100% - 28px)); margin-inline:auto; }
  .gt-nav{ position: sticky; top:14px; z-index:50; margin-bottom:22px; }
  .gt-nav-inner{ display:flex; justify-content:space-between; align-items:center; gap:14px; padding:14px 18px; border-radius:16px; background:rgba(10,14,19,.72); border:1px solid var(--stroke); backdrop-filter: blur(10px); }
  .gt-brand a{ text-decoration:none; display:flex; gap:10px; align-items:center; color:var(--text); }
  .gt-logo{ width:34px;height:34px;display:grid;place-items:center;border-radius:12px;background:linear-gradient(180deg,rgba(210,164,75,.25),rgba(210,164,75,.08));border:1px solid rgba(210,164,75,.35);font-weight:900; }
  .gt-hero{
    border-radius:22px; border:1px solid rgba(255,255,255,.10);
    background: radial-gradient(900px 300px at 0% 0%, rgba(210,164,75,.14), transparent 55%),
                linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.03));
    padding:22px; box-shadow: 0 18px 55px rgba(0,0,0,.45);
    margin-bottom: 16px;
  }
  .gt-title{ margin:0 0 6px; font-weight:900; font-size:22px; }
  .gt-sub{ margin:0; color:var(--muted); font-size:13px; line-height:1.8; }
  .section-bg, .table-section{ background: transparent !important; }
</style>
@endpush

<div class="gt-wrap">
  <div class="gt-container">

    <div class="gt-nav">
      <div class="gt-nav-inner">
        <div class="gt-brand">
          <a href="{{ url('/') }}"><div class="gt-logo">GT</div><div style="font-weight:900;">GOLDEN TRADE</div></a>
        </div>
        <div style="display:flex;gap:10px;">
          <a href="{{ url('crypto-currency') }}" style="text-decoration:none;color:rgba(255,255,255,.8);font-size:13px;">Crypto</a>
          <a href="{{ url('contact') }}" style="text-decoration:none;color:rgba(255,255,255,.8);font-size:13px;">Contact</a>
        </div>
      </div>
    </div>

    <div class="gt-hero">
      <h4 class="gt-title">@lang('Markets Overview')</h4>
      <p class="gt-sub">@lang('Explore your favorite coin pair on ') {{ __(gs("site_name")) }}</p>
    </div>

    {{-- الجزء ده فيه Widgets — سيبته عشان الوظايف --}}
    <div class="row mt-4 justify-content-center gy-4">
      <div class="col-lg-4 col-md-6"><x-flexible-view :view="$activeTemplate.'coin.top_exchange_coin'"/></div>
      <div class="col-lg-4 col-md-6"><x-flexible-view :view="$activeTemplate.'coin.highlight_coin'"/></div>
      <div class="col-lg-4 col-md-6"><x-flexible-view :view="$activeTemplate.'coin.new_coin'"/></div>
    </div>

    <div style="margin-top:14px;">
      <x-flexible-view :view="$activeTemplate.'sections.coin_pair_list'" :meta="['limit' => 25]" />
    </div>

    @if ($sections && $sections->secs != null)
      @foreach (json_decode($sections->secs) as $sec)
        @include($activeTemplate . 'sections.' . $sec)
      @endforeach
    @endif

  </div>
</div>

@endsection
