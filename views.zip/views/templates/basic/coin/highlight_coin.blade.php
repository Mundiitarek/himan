@php
    $highLightedCoins = App\Models\Currency::active()
        ->crypto()
        ->where('highlighted_coin', Status::YES)
        ->with('marketData')
        ->rankOrdering()
        ->take(4)
        ->get();
@endphp

<style>
    /* Golden Trade Coin Card - Scoped */
    .gt-coin-card{
        border-radius:18px;
        border:1px solid rgba(255,255,255,.10);
        background: rgba(255,255,255,.04);
        box-shadow: 0 18px 55px rgba(0,0,0,.35);
        overflow:hidden;
    }
    .gt-coin-card__head{
        padding:14px 16px;
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        border-bottom:1px solid rgba(255,255,255,.08);
        background: radial-gradient(650px 260px at 20% 20%, rgba(210,164,75,.14), transparent 60%);
    }
    .gt-coin-card__title{
        margin:0;
        font-size:13px;
        font-weight:900;
        color:rgba(255,255,255,.88);
        letter-spacing:.2px;
    }
    .gt-coin-card__hint{
        font-size:12px;
        color:rgba(255,255,255,.60);
        white-space:nowrap;
    }
    .gt-coin-list{ padding: 8px; }
    .gt-coin-row{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:12px;
        padding:10px 10px;
        border-radius:14px;
        transition:.2s ease;
    }
    .gt-coin-row:hover{ background: rgba(255,255,255,.05); }
    .gt-coin-left{
        display:flex;
        align-items:center;
        gap:10px;
        min-width: 0;
    }
    .gt-coin-left img{
        width:34px;height:34px;
        border-radius:12px;
        border:1px solid rgba(255,255,255,.10);
        background: rgba(255,255,255,.06);
        object-fit: cover;
    }
    .gt-coin-symbol{
        font-weight:900;
        color:rgba(255,255,255,.90);
        font-size:13px;
        white-space:nowrap;
    }
    .gt-coin-right{
        display:flex;
        flex-direction:column;
        align-items:flex-end;
        gap:3px;
        white-space:nowrap;
    }
    .gt-coin-price{
        font-weight:900;
        font-size:13px;
        color:rgba(255,255,255,.88);
    }
    .gt-coin-change{
        font-size:12px;
        color: rgba(255,255,255,.70);
    }
    .gt-empty{
        padding: 18px;
        text-align:center;
        color: rgba(255,255,255,.70);
    }
    .gt-empty img{ width:90px; opacity:.9; }
</style>

<div class="gt-coin-card">
    <div class="gt-coin-card__head">
        <h6 class="gt-coin-card__title">@lang('Highlight Coin')</h6>
        <div class="gt-coin-card__hint">@lang('Live')</div>
    </div>

    <div class="gt-coin-list">
        @forelse ($highLightedCoins as $highLightedCoin)
            <div class="gt-coin-row">
                <div class="gt-coin-left">
                    <img src="{{ @$highLightedCoin->image_url }}" alt="coin">
                    <div class="gt-coin-symbol">{{ @$highLightedCoin->symbol }}</div>
                </div>

                <div class="gt-coin-right">
                    <div class="gt-coin-price">
                        <span class="market-price-symbol-{{@$highLightedCoin->marketData->id}} {{ @$highLightedCoin->marketData->html_classes->price_change }}">
                            {{ gs('cur_sym') }}
                        </span>
                        <span class="market-price-{{@$highLightedCoin->marketData->id}} {{ @$highLightedCoin->marketData->html_classes->price_change }}">
                            {{ showAmount(@$highLightedCoin->marketData->price,currencyFormat:false) }}
                        </span>
                    </div>

                    <div class="gt-coin-change">
                        <span class="market-percent-change-1h-{{ @$highLightedCoin->marketData->id }} {{ @$highLightedCoin->marketData->html_classes->percent_change_1h }}">
                            {{ getAmount(@$highLightedCoin->marketData->percent_change_1h) }}%
                        </span>
                    </div>
                </div>
            </div>
        @empty
            <div class="gt-empty">
                <img src="{{ asset('assets/images/extra_images/empty.png') }}" alt="empty" />
                <div style="margin-top:8px; font-size:13px;">@lang('No coin found')</div>
            </div>
        @endforelse
    </div>
</div>
