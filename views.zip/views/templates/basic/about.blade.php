@extends($activeTemplate . 'layouts.frontend')
@section('content')

@push('style')
<style>
  header, .header, .header-section, .navbar-area, .menu-area, .site-header,
  footer, .footer, .footer-section, .footer-area { display:none !important; }

  :root{ --bg:#0b0f14; --stroke:rgba(255,255,255,.10); --text:rgba(255,255,255,.92); --gold:#d2a44b; --gold2:#b9892e; }
  body{ background:var(--bg) !important; color:var(--text); }
  .gt-wrap{ background: radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%), linear-gradient(180deg, var(--bg), #0a0d12); min-height:100vh; padding:28px 0 70px; }
  .gt-container{ width:min(1180px, calc(100% - 28px)); margin-inline:auto; }
  .gt-nav{ position: sticky; top:14px; z-index:50; margin-bottom:22px; }
  .gt-nav-inner{ display:flex; justify-content:space-between; align-items:center; gap:14px; padding:14px 18px; border-radius:16px; background:rgba(10,14,19,.72); border:1px solid var(--stroke); backdrop-filter: blur(10px); }
  .gt-brand a{ text-decoration:none; display:flex; gap:10px; align-items:center; color:var(--text); }
  .gt-logo{ width:34px;height:34px;display:grid;place-items:center;border-radius:12px;background:linear-gradient(180deg,rgba(210,164,75,.25),rgba(210,164,75,.08));border:1px solid rgba(210,164,75,.35);font-weight:900; }
  .gt-btn{ height:38px;padding:0 14px;border-radius:12px;font-weight:700;font-size:13px;display:inline-flex;align-items:center;justify-content:center;text-decoration:none; }
  .gt-btn-primary{ color:#1a1408; background:linear-gradient(180deg,var(--gold),var(--gold2)); }
  .gt-btn-ghost{ color:rgba(255,255,255,.86); background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.10); }
</style>
@endpush

<div class="gt-wrap">
  <div class="gt-container">
    <div class="gt-nav">
      <div class="gt-nav-inner">
        <div class="gt-brand">
          <a href="{{ url('/') }}"><div class="gt-logo">GT</div><div style="font-weight:900;">GOLDEN TRADE</div></a>
        </div>
        <div style="display:flex;gap:10px;">
          <a class="gt-btn gt-btn-ghost" href="{{ url('user/login') }}">Login</a>
          <a class="gt-btn gt-btn-primary" href="{{ url('user/register') }}">Get Started</a>
        </div>
      </div>
    </div>

    @if ($sections && $sections->secs != null)
      @foreach (json_decode($sections->secs) as $sec)
        @include($activeTemplate . 'sections.' . $sec)
      @endforeach
    @endif

  </div>
</div>

@endsection
