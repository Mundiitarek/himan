@extends($activeTemplate.'layouts.frontend')
@section('content')
@php 
    $content = getContent('contact_us.content',true); 
@endphp

@push('style')
<style>
  header, .header, .header-section, .navbar-area, .menu-area, .site-header,
  footer, .footer, .footer-section, .footer-area { display:none !important; }

  :root{
    --bg:#0b0f14; --stroke:rgba(255,255,255,.10);
    --text:rgba(255,255,255,.92); --muted:rgba(255,255,255,.65);
    --gold:#d2a44b; --gold2:#b9892e;
  }
  body{ background:var(--bg) !important; color:var(--text); }
  .gt-wrap{ background: radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%), linear-gradient(180deg, var(--bg), #0a0d12); min-height:100vh; padding:28px 0 70px; }
  .gt-container{ width:min(1180px, calc(100% - 28px)); margin-inline:auto; }
  .gt-nav{ position: sticky; top:14px; z-index:50; margin-bottom:22px; }
  .gt-nav-inner{ display:flex; justify-content:space-between; align-items:center; gap:14px; padding:14px 18px; border-radius:16px; background:rgba(10,14,19,.72); border:1px solid var(--stroke); backdrop-filter: blur(10px); }
  .gt-brand a{ text-decoration:none; display:flex; gap:10px; align-items:center; color:var(--text); }
  .gt-logo{ width:34px;height:34px;display:grid;place-items:center;border-radius:12px;background:linear-gradient(180deg,rgba(210,164,75,.25),rgba(210,164,75,.08));border:1px solid rgba(210,164,75,.35);font-weight:900; }
  .gt-btn{ height:38px;padding:0 14px;border-radius:12px;font-weight:700;font-size:13px;display:inline-flex;align-items:center;justify-content:center;text-decoration:none; }
  .gt-btn-primary{ color:#1a1408; background:linear-gradient(180deg,var(--gold),var(--gold2)); }
  .gt-btn-ghost{ color:rgba(255,255,255,.86); background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.10); }

  .gt-hero{
    border-radius:22px; border:1px solid rgba(255,255,255,.10);
    background: radial-gradient(900px 300px at 0% 0%, rgba(210,164,75,.14), transparent 55%),
                linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.03));
    padding:22px; box-shadow: 0 18px 55px rgba(0,0,0,.45);
    margin-bottom: 16px;
  }
  .gt-title{ margin:0 0 6px; font-weight:900; font-size:22px; }
  .gt-sub{ margin:0; color:var(--muted); font-size:13px; line-height:1.8; }

  .gt-grid{ display:grid; grid-template-columns: 1fr 1fr; gap:14px; margin-top:14px; }
  .gt-card{
    border-radius:18px; border:1px solid rgba(255,255,255,.10);
    background: rgba(255,255,255,.04); padding:18px;
    box-shadow: 0 18px 55px rgba(0,0,0,.35);
  }
  .gt-info{ display:flex; gap:10px; align-items:center; margin-bottom:10px; color:rgba(255,255,255,.78); }
  .gt-ic{
    width:44px;height:44px;border-radius:16px;display:grid;place-items:center;
    background:rgba(210,164,75,.14); border:1px solid rgba(210,164,75,.28);
    color:var(--gold); font-weight:900;
  }
  .gt-form label{ color:rgba(255,255,255,.78); font-weight:700; font-size:12px; margin-bottom:6px; display:block; }
  .gt-form input, .gt-form textarea{
    width:100%; border-radius:14px; border:1px solid rgba(255,255,255,.10);
    background: rgba(255,255,255,.04); color: var(--text);
    padding: 12px 12px; outline:none;
  }
  .gt-form textarea{ min-height:120px; resize:vertical; }
  .gt-form .form-group{ margin-bottom: 12px; }

  /* زرار الثيم القديم لو موجود */
  .btn--base{ background:linear-gradient(180deg,var(--gold),var(--gold2)) !important; border:0 !important; color:#1a1408 !important; border-radius:14px !important; font-weight:900 !important; }

  @media (max-width: 980px){ .gt-grid{ grid-template-columns: 1fr; } }
</style>
@endpush

<div class="gt-wrap">
  <div class="gt-container">

    <div class="gt-nav">
      <div class="gt-nav-inner">
        <div class="gt-brand">
          <a href="{{ url('/') }}"><div class="gt-logo">GT</div><div style="font-weight:900;">GOLDEN TRADE</div></a>
        </div>
        <div style="display:flex;gap:10px;">
          <a class="gt-btn gt-btn-ghost" href="{{ url('/') }}">Home</a>
          <a class="gt-btn gt-btn-primary" href="{{ url('user/register') }}">Get Started</a>
        </div>
      </div>
    </div>

    <div class="gt-hero">
      <h2 class="gt-title">{{ __(@$content->data_values->heading) }}</h2>
      <p class="gt-sub">{{ __(@$content->data_values->subheading) }}</p>
    </div>

    <div class="gt-grid">
      <div class="gt-card">
        <div class="gt-info">
          <div class="gt-ic">@</div>
          <div>
            <div style="font-weight:900;">Email</div>
            <div style="color:rgba(255,255,255,.68); font-size:13px;">{{ @$content->data_values->email }}</div>
          </div>
        </div>
        <div class="gt-info" style="margin-top:12px;">
          <div class="gt-ic">☎</div>
          <div>
            <div style="font-weight:900;">Phone</div>
            <div style="color:rgba(255,255,255,.68); font-size:13px;">{{ @$content->data_values->mobile }}</div>
          </div>
        </div>

        <div style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap;">
          <img style="width:120px;height:120px;object-fit:cover;border-radius:16px;border:1px solid rgba(255,255,255,.10);"
               src="{{ getImage('assets/images/frontend/contact_us/'.@$content->data_values->image_light,'410x410') }}" alt="contact">
          <img style="width:120px;height:120px;object-fit:cover;border-radius:16px;border:1px solid rgba(255,255,255,.10);"
               src="{{ getImage('assets/images/frontend/contact_us/'.@$content->data_values->image_dark,'410x410') }}" alt="contact">
        </div>
      </div>

      <div class="gt-card">
        @php $user=auth()->user(); @endphp
        <form method="post" action="" class="verify-gcaptcha gt-form">
          @csrf

          <div class="form-group">
            <label>@lang('Name')</label>
            <input name="name" type="text" value="{{ old('name',@$user->fullname) }}" @if($user) readonly @endif required placeholder="@lang('Your name')">
          </div>

          <div class="form-group">
            <label>@lang('Email')</label>
            <input name="email" type="email" value="{{ old('email',@$user->email) }}" @if($user) readonly @endif required placeholder="@lang('Your email')">
          </div>

          <div class="form-group">
            <label>@lang('Subject')</label>
            <input name="subject" type="text" value="{{ old('subject') }}" required placeholder="@lang('Write subject')">
          </div>

          <div class="form-group">
            <label>@lang('Message')</label>
            <textarea name="message" required placeholder="@lang('Write Message')">{{ old('message') }}</textarea>
          </div>

          <x-captcha isCustom="true" />

          <div class="form-group" style="margin-top:12px;">
            <button type="submit" class="btn btn--base w-100">@lang('Submit')</button>
          </div>
        </form>
      </div>
    </div>

  </div>
</div>

@endsection
