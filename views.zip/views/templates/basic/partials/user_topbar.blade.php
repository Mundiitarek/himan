@php
    $user=auth()->user();
@endphp

<div class="dashboard-header gt-topbar">
    <style>
        .gt-topbar{
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
        }
        .gt-topbar .dashboard-header__inner{
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 18px;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
            padding: 12px;
        }
        .gt-topbar .copy-link{
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 14px;
            padding: 8px;
            display:flex;
            align-items:center;
            gap: 8px;
        }
        .gt-topbar .copyText{
            background: transparent !important;
            border: none !important;
            color: rgba(255,255,255,.86) !important;
            font-size: 12px;
        }
        .gt-topbar .copyText:focus{ outline: none !important; box-shadow: none !important; }

        .gt-topbar .copyTextBtn{
            width: 36px;
            height: 36px;
            border-radius: 12px;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
            color: rgba(255,255,255,.86);
            transition: .18s ease;
        }
        .gt-topbar .copyTextBtn:hover{
            background: rgba(210,164,75,.14);
            border-color: rgba(210,164,75,.22);
            color:#d2a44b;
            transform: translateY(-1px);
        }

        .gt-topbar .trade-btn{
            background: linear-gradient(180deg, #d2a44b, #b9892e) !important;
            color: #1a1408 !important;
            border-radius: 12px !important;
            font-weight: 900 !important;
            border: none !important;
        }

        .gt-topbar .user-info{
            position: relative;
        }
        .gt-topbar .user-info__button{
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 14px;
            padding: 10px 12px;
            cursor: pointer;
        }
        .gt-topbar .user-info__name{
            color: rgba(255,255,255,.92);
            font-weight: 900;
            font-size: 13px;
            margin: 0;
        }

        .gt-topbar .user-info-dropdown{
            background: rgba(15,18,25,.98);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 16px;
            box-shadow: 0 18px 55px rgba(0,0,0,.45);
            overflow: hidden;
        }
        .gt-topbar .user-info-dropdown__link{
            color: rgba(255,255,255,.86);
            font-weight: 800;
            font-size: 13px;
        }
        .gt-topbar .user-info-dropdown__link:hover{
            background: rgba(210,164,75,.14);
            color:#d2a44b;
        }

        @media (max-width: 768px){
            .gt-topbar .dashboard-header__inner{
                padding: 10px;
            }
            .gt-topbar .dashboard-header__right{
                gap: 10px;
            }
        }
    </style>

    <div class="dashboard-header__inner">
        <div class="dashboard-header__left">
            <div class="copy-link">
                <input type="text" class="copyText" value="{{ route('home') }}?reference={{ $user->username }}" readonly>
                <button class="copy-link__button copyTextBtn" data-bs-toggle="tooltip"  data-bs-placement="right" title="@lang('Copy URL')">
                    <span class="copy-link__icon"><i class="las la-copy"></i>
                    </span>
                </button>
            </div>
        </div>

        <div class="dashboard-header__right">
            <a href="{{ route('trade') }}" target="_blank" class="btn btn--base outline btn--sm trade-btn">
                <span class="icon-trade"></span> @lang('TRADE')
            </a>

            <div class="user-info">
                <div class="user-info__right">
                    <div class="user-info__button">
                        <div class="user-info__profile">
                            <p class="user-info__name">{{ __($user->username) }}</p>
                        </div>
                    </div>
                </div>

                <ul class="user-info-dropdown">
                    <li class="user-info-dropdown__item">
                        <a class="user-info-dropdown__link" href="{{ route('user.profile.setting') }}">
                            <span class="icon"><i class="far fa-user-circle"></i></span>
                            <span class="text">@lang('My Profile')</span>
                        </a>
                    </li>
                    <li class="user-info-dropdown__item">
                        <a class="user-info-dropdown__link" href="{{ route('user.change.password') }}">
                            <span class="icon"><i class="fa fa-key"></i></span>
                            <span class="text">@lang('Change Password')</span>
                        </a>
                    </li>
                    <li class="user-info-dropdown__item">
                        <a class="user-info-dropdown__link" href="{{ route('user.logout') }}">
                            <span class="icon"><i class="far fa-user-circle"></i></span>
                            <span class="text">@lang('Logout')</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
