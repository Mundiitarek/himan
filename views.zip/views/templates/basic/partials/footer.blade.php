@php
    $footer      = getContent('footer.content', true);
    $socialIcons = getContent('social_icon.element', orderById: true);
    $policyPages = getContent('policy_pages.element');
@endphp

<footer class="footer-area gt-footer">
    <style>
        .gt-footer{
            background:
                radial-gradient(900px 450px at 20% 10%, rgba(210,164,75,.10), transparent 65%),
                linear-gradient(180deg, rgba(11,15,20,1) 0%, rgba(10,13,18,1) 100%);
            border-top: 1px solid rgba(255,255,255,.10);
            color: rgba(255,255,255,.92);
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
        }
        .gt-footer .footer-item{
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 18px;
            padding: 16px;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-footer .footer-item__logo img{
            max-height: 38px;
            filter: drop-shadow(0 10px 22px rgba(0,0,0,.35));
        }
        .gt-footer .footer-item__desc{
            color: rgba(255,255,255,.65);
            font-size: 13px;
            line-height: 1.7;
            margin-top: 10px;
            margin-bottom: 0;
        }
        .gt-footer .footer-item__title{
            color: rgba(255,255,255,.92);
            font-weight: 900;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .gt-footer .footer-menu__link{
            color: rgba(255,255,255,.75);
            font-weight: 800;
            font-size: 13px;
            text-decoration: none;
        }
        .gt-footer .footer-menu__link:hover{
            color: #d2a44b;
        }

        .gt-footer .bottom-footer{
            background: rgba(255,255,255,.02);
            border-top: 1px solid rgba(255,255,255,.10);
        }
        .gt-footer .bottom-footer__text{
            color: rgba(255,255,255,.65);
        }

        .gt-footer .social-list__link{
            width: 36px;
            height: 36px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 999px;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
            color: rgba(255,255,255,.86);
            transition: .18s ease;
        }
        .gt-footer .social-list__link:hover{
            background: rgba(210,164,75,.14);
            border-color: rgba(210,164,75,.22);
            color: #d2a44b;
            transform: translateY(-1px);
        }
    </style>

    <div class="py-60">
        <div class="container">
            <div class="row gy-4 justify-content-center">
                <div class="col-sm-6 col-xl-6">
                    <div class="footer-item">
                        <div class="footer-item__logo">
                            <a href="{{ route('home') }}">
                                <img src="{{ siteLogo() }}">
                            </a>
                        </div>
                        <p class="footer-item__desc">{{ __(@$footer->data_values->about_info) }}</p>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-2">
                    <div class="footer-item">
                        <h5 class="footer-item__title">@lang('Quick Links')</h5>
                        <ul class="footer-menu">
                            <li class="footer-menu__item">
                                <a href="{{ route('trade') }}" class="footer-menu__link"> @lang('Trade') </a>
                            </li>
                            <li class="footer-menu__item">
                                <a href="{{ route('market') }}" class="footer-menu__link"> @lang('Market') </a>
                            </li>
                            <li class="footer-menu__item">
                                <a href="{{ route('crypto_currencies') }}" class="footer-menu__link"> @lang('Crypto Currency') </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-2">
                    <div class="footer-item">
                        <h5 class="footer-item__title"> @lang('Company') </h5>
                        <ul class="footer-menu">
                            <li class="footer-menu__item">
                                <a href="{{ route('home') }}" class="footer-menu__link"> @lang('Home') </a>
                            </li>
                            <li class="footer-menu__item">
                                <a href="{{ route('about') }}" class="footer-menu__link">@lang('About')</a>
                            </li>
                            <li class="footer-menu__item">
                                <a href="{{ route('contact') }}" class="footer-menu__link"> @lang('Contact') </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-2">
                    <div class="footer-item">
                        <h5 class="footer-item__title"> @lang('Legal') </h5>
                        <ul class="footer-menu">
                            @foreach ($policyPages as $policyPage)
                                <li class="footer-menu__item">
                                    <a href="{{ route('policy.pages', @$policyPage->slug) }}"
                                        class="footer-menu__link">
                                        {{ __($policyPage->data_values->title) }}
                                    </a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bottom-footer">
        <div class="container">
            <div class="bottom-footer__style py-3">
                <div class="gap-4 d-flex flex-wrap justify-content-between align-items-center">
                    <div class="bottom-footer__text">
                        @php echo copyRightText(); @endphp
                    </div>
                    <div class="footer-list-wrapper">
                        <ul class="social-list">
                            @foreach ($socialIcons as $sIcon)
                                <li class="social-list__item">
                                    <a href="{{ @$sIcon->data_values->url }}" target="_blank" class="social-list__link">
                                        @php echo @$sIcon->data_values->icon; @endphp
                                    </a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
