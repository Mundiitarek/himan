<ul @if($isFirst) class="firstList gt-tree" @endif>
    @foreach($user->allReferrals as $under)
        @if($loop->first)
            @php $layer++ @endphp
        @endif

        <li class="gt-tree__item">
            <span class="gt-tree__name">{{ $under->fullname }}</span>

            @if(($under->allReferrals->count()) > 0 && ($layer < $maxLevel))
                @include($activeTemplate.'partials.under_tree',['user'=>$under,'layer'=>$layer,'isFirst'=>false])
            @endif
        </li>
    @endforeach
</ul>

<style>
    /* Tree styling (safe, no JS dependencies here) */
    .gt-tree{
        list-style: none;
        padding-left: 14px;
        margin: 0;
        color: rgba(255,255,255,.86);
    }
    .gt-tree__item{
        margin: 8px 0;
        padding-left: 10px;
        position: relative;
    }
    .gt-tree__item::before{
        content:"";
        position:absolute;
        left: 0;
        top: 9px;
        width: 6px;
        height: 6px;
        border-radius: 999px;
        background: rgba(210,164,75,.75);
        box-shadow: 0 10px 22px rgba(0,0,0,.35);
    }
    .gt-tree__name{
        display:inline-block;
        padding: 6px 10px;
        border-radius: 999px;
        background: rgba(255,255,255,.04);
        border: 1px solid rgba(255,255,255,.10);
        font-weight: 800;
        font-size: 13px;
    }
</style>
