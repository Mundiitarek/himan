<header class="header gt-header" id="header">
    <style>
        /* ===============================
           Golden Trade Header (Frontend)
           =============================== */
        .gt-header{
            position: sticky;
            top: 0;
            z-index: 9999;
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.10), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.08), transparent 70%),
                linear-gradient(180deg, rgba(11,15,20,.92) 0%, rgba(10,13,18,.88) 100%);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.10);
            box-shadow: 0 18px 55px rgba(0,0,0,.45);
        }

        .gt-header .navbar{
            background: transparent !important;
            padding: 10px 0 !important;
        }

        .gt-header .navbar-brand.logo{
            display:flex;
            align-items:center;
            gap:10px;
            text-decoration:none;
        }

        .gt-header .navbar-brand.logo img{
            max-height: 38px;
            width: auto;
            filter: drop-shadow(0 10px 22px rgba(0,0,0,.35));
        }

        /* Toggler */
        .gt-header .navbar-toggler.header-button{
            width: 42px;
            height: 42px;
            border-radius: 14px;
            background: rgba(255,255,255,.06) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.92) !important;
            display:inline-flex;
            align-items:center;
            justify-content:center;
            box-shadow: 0 18px 55px rgba(0,0,0,.25);
        }
        .gt-header .navbar-toggler.header-button:hover{
            background: rgba(210,164,75,.14) !important;
            border-color: rgba(210,164,75,.22) !important;
            color:#d2a44b !important;
        }

        /* Desktop nav layout */
        .gt-header .nav-menu{
            gap: 6px;
        }
        @media (min-width: 992px){
            .gt-header .nav-menu{
                flex-wrap: nowrap !important;     /* أهم حاجة عشان ما يترصص */
                align-items: center;
            }
        }

        .gt-header .nav-menu .nav-link{
            color: rgba(255,255,255,.82) !important;
            font-weight: 800;
            font-size: 13px;
            letter-spacing: .2px;
            padding: 10px 12px !important;
            border-radius: 14px;
            transition: .18s ease;
            white-space: nowrap; /* يمنع تكسير الكلمات */
        }

        .gt-header .nav-menu .nav-link:hover{
            background: rgba(255,255,255,.05);
            color: rgba(255,255,255,.92) !important;
        }

        /* CTA / Auth buttons */
        .gt-header .btn--base{
            background: linear-gradient(180deg, #d2a44b, #b9892e) !important;
            color: #1a1408 !important;
            border: none !important;
            border-radius: 12px !important;
            font-weight: 900 !important;
        }
        .gt-header .sign-in{
            color: rgba(255,255,255,.82) !important;
            font-weight: 800;
            text-decoration:none;
        }
        .gt-header .sign-in:hover{ color:#d2a44b !important; }

        /* Language pills (AR/EN) */
        .gt-header .gt-lang{
            display:flex;
            gap: 6px;
            align-items:center;
        }
        .gt-header .gt-lang .gt-lang-pill{
            padding: 7px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 900;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
            color: rgba(255,255,255,.86);
            cursor: pointer;
            line-height: 1;
        }
        .gt-header .gt-lang .gt-lang-pill:hover{
            background: rgba(210,164,75,.14);
            border-color: rgba(210,164,75,.22);
            color:#d2a44b;
        }

        /* Collapse panel for mobile/tablet */
        @media (max-width: 991px){
            .gt-header .navbar-collapse{
                margin-top: 12px;
                background: rgba(15,18,25,.98);
                border: 1px solid rgba(255,255,255,.10);
                border-radius: 18px;
                padding: 12px;
                box-shadow: 0 18px 55px rgba(0,0,0,.45);
            }
            .gt-header .nav-menu{
                flex-direction: column;
                align-items: stretch !important;
                gap: 8px;
            }
            .gt-header .nav-menu .nav-link{
                display:flex;
                justify-content: space-between;
                padding: 12px 12px !important;
                border: 1px solid rgba(255,255,255,.08);
                background: rgba(255,255,255,.03);
            }
            .gt-header .nav-item.has-mega-menu .nav-link::after{
                content:"▾";
                opacity: .75;
                font-weight: 900;
            }
        }

        /* Mega menu (Desktop hover) */
        .gt-header .has-mega-menu{ position: relative; }
        .gt-header .mega-menu{
            background: rgba(15,18,25,.98) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            border-radius: 18px !important;
            box-shadow: 0 18px 55px rgba(0,0,0,.45);
            overflow: hidden;
        }

        /* لو الثيم عندك بيظهر الميجا من نفسه، سيبه.
           هنظبط شكله بس */
        .gt-header .mega-menu-list__item{
            border-radius: 16px !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            background: rgba(255,255,255,.04) !important;
        }
        .gt-header .mega-menu-list__item:hover{
            background: rgba(255,255,255,.05) !important;
        }
        .gt-header .mega-menu-list__title{
            color: rgba(255,255,255,.92) !important;
            font-weight: 900 !important;
        }
        .gt-header .mega-menu-list__desc{
            color: rgba(255,255,255,.65) !important;
        }

        /* keep dropdown language styling (if used somewhere else) */
        .gt-header .custom--dropdown__selected{
            background: rgba(255,255,255,.06) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            border-radius: 999px !important;
            padding: 8px 10px !important;
            color: rgba(255,255,255,.86) !important;
        }
        .gt-header .dropdown-list{
            background: rgba(15,18,25,.98) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            border-radius: 16px !important;
            box-shadow: 0 18px 55px rgba(0,0,0,.45);
            overflow: hidden;
        }
        .gt-header .dropdown-list__item:hover{
            background: rgba(210,164,75,.14) !important;
            color: #d2a44b !important;
        }
    </style>

    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light">

            <a class="navbar-brand logo" href="{{ route('home') }}">
                <img src="{{ siteLogo() }}">
            </a>

            <button class="navbar-toggler header-button" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span id="hiddenNav"><i class="las la-bars"></i></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-menu me-auto align-items-lg-center">

                    {{-- Mobile Top Actions (inside dropdown panel) --}}
                    <li class="nav-item d-block d-lg-none">
                        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                            <div class="gt-lang">
                                <button type="button" class="gt-lang-pill change-lang" data-code="en">EN</button>
                                <button type="button" class="gt-lang-pill change-lang" data-code="ar">AR</button>
                            </div>

                            <div class="d-flex gap-2 flex-wrap">
                                @guest
                                    <a href="{{ route('user.login') }}" class="sign-in">@lang('Login')</a>
                                    <a href="{{ route('user.register') }}" class="btn btn--base btn--sm">@lang('Sign up')</a>
                                @else
                                    <a href="{{ route('user.home') }}" class="btn btn--base btn--sm">@lang('Dashboard')</a>
                                    <a href="{{ route('user.logout') }}" class="sign-in">@lang('Logout')</a>
                                @endguest
                            </div>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('market') }}">@lang('Market')</a>
                    </li>

                    <li class="nav-item has-mega-menu">
                        <a class="nav-link" href="javascript:void(0)">@lang('Trade')</a>
                        <div class="mega-menu">
                            <div class="mega-menu__inner">
                                <ul class="mega-menu-list">
                                    <li class="mega-menu-list__item mega-item-bg1">
                                        <a href="{{ route('trade') }}" class="mega-menu-list__link">
                                            <div class="mega-menu-list__content">
                                                <span class="mega-menu-list__title">@lang('SPOT')</span>
                                                <p class="mega-menu-list__desc">@lang('Trade smartly with necessary Spot market tools.')</p>
                                            </div>
                                            <span class="mega-menu-list__icon">
                                                <img class="fit-image" src="{{ getImage('assets/images/extra_images/bar-chart.png', null) }}">
                                            </span>
                                        </a>
                                    </li>
                                    <li class="mega-menu-list__item mega-item-bg2">
                                        <a href="{{ route('p2p') }}" class="mega-menu-list__link">
                                            <div class="mega-menu-list__content">
                                                <span class="mega-menu-list__title">@lang('P2P')</span>
                                                <p class="mega-menu-list__desc">@lang('Buy & sell crypto with your preferred payment methods.')</p>
                                            </div>
                                            <span class="mega-menu-list__icon">
                                                <img class="fit-image" src="{{ getImage('assets/images/extra_images/p2p.png', null) }}">
                                            </span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('crypto_currencies') }}">@lang('Crypto Currency')</a>
                    </li>

                    @php
                        $pages = App\Models\Page::where('is_default', Status::NO)->where('tempname', $activeTemplate)->get();
                    @endphp

                    @foreach ($pages as $item)
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('pages', ['slug' => $item->slug]) }}">
                                {{ __($item->name) }}
                            </a>
                        </li>
                    @endforeach

                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('contact') }}">@lang('Contact')</a>
                    </li>
                </ul>
            </div>

            {{-- Desktop Right Side --}}
            <ul class="header-right d-lg-block d-none">
                <li class="nav-item">
                    <div class="d-flex align-items-center gap-2 flex-wrap">

                        <div class="gt-lang">
                            <button type="button" class="gt-lang-pill change-lang" data-code="en">EN</button>
                            <button type="button" class="gt-lang-pill change-lang" data-code="ar">AR</button>
                        </div>

                        @guest
                            <a href="{{ route('user.login') }}" class="sign-in">@lang('Login')</a>
                            <a href="{{ route('user.register') }}" class="btn btn--base btn--sm">@lang('Sign up')</a>
                        @else
                            <a href="{{ route('user.home') }}" class="btn btn--base btn--sm">@lang('Dashboard')</a>
                            <a href="{{ route('user.logout') }}" class="sign-in">@lang('Logout')</a>
                        @endguest

                    </div>
                </li>
            </ul>

            @if (!request()->routeIs('trade'))
                <div class="theme-switch-wrapper">
                    <label class="theme-switch" for="checkbox">
                        <input type="checkbox" class="d-none" id="checkbox">
                        <span class="slider">
                            <i class="las la-sun"></i>
                        </span>
                    </label>
                </div>
            @endif

        </nav>
    </div>
</header>
