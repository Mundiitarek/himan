<div class="sidebar-menu">
    {{-- Golden Trade Sidebar Styles (scoped) --}}
    <style>
        /* Base */
        .sidebar-menu {
            --gt-bg: #0b0f14;
            --gt-bg2: #0a0d12;
            --gt-card: rgba(255, 255, 255, 0.04);
            --gt-border: rgba(255, 255, 255, 0.10);
            --gt-text: rgba(255, 255, 255, 0.92);
            --gt-muted: rgba(255, 255, 255, 0.65);
            --gt-gold: #d2a44b;
            --gt-gold2: #b9892e;
            --gt-gold-soft: rgba(210, 164, 75, 0.14);
            --gt-shadow: 0 18px 55px rgba(0, 0, 0, 0.35);

            color: var(--gt-text);
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
        }

        /* Container */
        .sidebar-menu__inner {
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210, 164, 75, .12), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210, 164, 75, .08), transparent 70%),
                linear-gradient(180deg, var(--gt-bg) 0%, var(--gt-bg2) 100%);
            border-right: 1px solid var(--gt-border);
            box-shadow: var(--gt-shadow);
            padding: 14px 12px;
            height: 100%;
        }

        /* Close button */
        .sidebar-menu__close {
            width: 38px;
            height: 38px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid var(--gt-border);
            color: var(--gt-text);
            cursor: pointer;
            transition: .18s ease;
            margin-bottom: 12px;
        }

        .sidebar-menu__close:hover {
            background: var(--gt-gold-soft);
            color: var(--gt-gold);
            transform: translateY(-1px);
        }

        /* Logo */
        .sidebar-logo {
            margin-bottom: 14px;
        }

        .sidebar-logo__link {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            padding: 12px 12px;
            border-radius: 18px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--gt-border);
            box-shadow: var(--gt-shadow);
        }

        .sidebar-logo__link::before {
            content: "";
            width: 34px;
            height: 34px;
            border-radius: 12px;
            background: linear-gradient(180deg, var(--gt-gold), var(--gt-gold2));
            flex: 0 0 auto;
        }

        .sidebar-logo__link img {
            max-height: 34px;
            width: auto;
            filter: drop-shadow(0 10px 22px rgba(0, 0, 0, 0.35));
        }

        /* Optional brand text (if you ever want it later)
        .sidebar-logo__link::after{
            content:"Golden Trade";
            margin-left:auto;
            font-weight:900;
            letter-spacing:.4px;
            color: var(--gt-text);
            opacity:.92;
        } */

        /* List */
        .sidebar-menu-list {
            margin: 0;
            padding: 0;
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .sidebar-menu-list__item {
            margin: 0;
            padding: 0;
        }

        /* Links */
        .sidebar-menu-list__link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 12px;
            border-radius: 16px;
            text-decoration: none;
            color: rgba(255, 255, 255, 0.86);
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.08);
            transition: .18s ease;
            position: relative;
            overflow: hidden;
        }

        .sidebar-menu-list__link:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: var(--gt-border);
            transform: translateY(-1px);
        }

        /* Active state (menuActive usually adds "active") */
        .sidebar-menu-list__link.active {
            background: linear-gradient(180deg, rgba(210, 164, 75, 0.18), rgba(185, 137, 46, 0.10));
            border-color: rgba(210, 164, 75, 0.35);
            color: var(--gt-text);
        }

        .sidebar-menu-list__link.active::before {
            content: "";
            position: absolute;
            left: 0;
            top: 10px;
            bottom: 10px;
            width: 4px;
            border-radius: 999px;
            background: linear-gradient(180deg, var(--gt-gold), var(--gt-gold2));
        }

        /* Icon */
        .sidebar-menu-list__link .icon {
            width: 36px;
            height: 36px;
            border-radius: 14px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.08);
            color: rgba(255, 255, 255, 0.90);
            flex: 0 0 auto;
            transition: .18s ease;
        }

        .sidebar-menu-list__link:hover .icon {
            background: var(--gt-gold-soft);
            border-color: rgba(210, 164, 75, 0.22);
            color: var(--gt-gold);
        }

        .sidebar-menu-list__link.active .icon {
            background: var(--gt-gold-soft);
            border-color: rgba(210, 164, 75, 0.22);
            color: var(--gt-gold);
        }

        /* Text */
        .sidebar-menu-list__link .text {
            font-size: 13px;
            font-weight: 800;
            letter-spacing: .2px;
            line-height: 1.2;
        }

        /* Make sidebar nicer on small screens */
        @media (max-width: 575px) {
            .sidebar-menu__inner { padding: 12px 10px; }
            .sidebar-menu-list__link { padding: 11px 10px; }
            .sidebar-menu-list__link .text { font-size: 12.5px; }
        }
    </style>

    <div class="sidebar-menu__inner">
        <span class="sidebar-menu__close d-xl-none d-block"><i class="fas fa-times"></i></span>

        <div class="sidebar-logo">
            <a href="{{ route('user.home') }}" class="sidebar-logo__link">
                <img src="{{ siteLogo() }}">
            </a>
        </div>

        <ul class="sidebar-menu-list">
            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.home') }}" class="sidebar-menu-list__link {{ menuActive('user.home') }}">
                    <span class="icon"><span class="icon-dashboard"></span></span>
                    <span class="text">@lang('Dashboard')</span>
                </a>
            </li>

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.order.open') }}" class="sidebar-menu-list__link {{ menuActive('user.order.*') }} ">
                    <span class="icon"><span class="icon-order"></span></span>
                    <span class="text">@lang('Manage Order')</span>
                </a>
            </li>

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.trade.history') }}" class="sidebar-menu-list__link {{ menuActive('user.trade.history') }} ">
                    <span class="icon"><span class="icon-trade"></span></span>
                    <span class="text">@lang('Trade History')</span>
                </a>
            </li>

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.p2p.dashboard') }}" class="sidebar-menu-list__link {{ menuActive('user.p2p.dashboard') }} ">
                    <span class="icon"><span class="icon-trade"></span></span>
                    <span class="text">@lang('P2P Center')</span>
                </a>
            </li>

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.wallet.list','spot') }}" class="sidebar-menu-list__link {{ menuActive('user.wallet.*') }}">
                    <span class="icon"><span class="icon-wallet"></span></span>
                    <span class="text">@lang('Manage Wallet')</span>
                </a>
            </li>

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.deposit.history') }}" class="sidebar-menu-list__link {{ menuActive('user.deposit.*') }}">
                    <span class="icon"><span class="icon-deposit"></span></span>
                    <span class="text">@lang('Deposit History')</span>
                </a>
            </li>

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.withdraw.history') }}" class="sidebar-menu-list__link {{ menuActive('user.withdraw.history') }}">
                    <span class="icon"><span class="icon-withdraw"></span></span>
                    <span class="text">@lang('Withdraw History')</span>
                </a>
            </li>

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.referrals') }}" class="sidebar-menu-list__link {{ menuActive('user.referrals') }}">
                    <span class="icon"><span class="icon-affiliation"></span></span>
                    <span class="text">@lang('My Affiliation')</span>
                </a>
            </li>

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.transactions') }}" class="sidebar-menu-list__link {{ menuActive('user.transactions') }}">
                    <span class="icon"><span class="icon-transaction"></span></span>
                    <span class="text">@lang('Transaction Histoy')</span>
                </a>
            </li>

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('ticket.index') }}" class="sidebar-menu-list__link {{ menuActive('ticket.*') }}">
                    <span class="icon"><span class="icon-support"></span></span>
                    <span class="text">@lang('Get Support')</span>
                </a>
            </li>

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.twofactor') }}" class="sidebar-menu-list__link {{ menuActive('user.twofactor') }}">
                    <span class="icon"><span class="icon-security"></span></span>
                    <span class="text">@lang('Security')</span>
                </a>
            </li>

            <li class="sidebar-menu-list__item ">
                <a href="{{ route('user.logout') }}" class="sidebar-menu-list__link">
                    <span class="icon"><span class="icon-logout"></span></span>
                    <span class="text">@lang('Logout')</span>
                </a>
            </li>
        </ul>
    </div>
</div>
