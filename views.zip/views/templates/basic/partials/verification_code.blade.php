<div class="mb-3 gt-verify">
    <label class="form-label">@lang('Verification Code')</label>
    <div class="verification-code">
        <input type="text" name="code" id="verification-code" class="form-control overflow-hidden" required autocomplete="off">
        <div class="boxes">
            <span>-</span>
            <span>-</span>
            <span>-</span>
            <span>-</span>
            <span>-</span>
            <span>-</span>
        </div>
    </div>
</div>

@push('style')
    <link rel="stylesheet" href="{{ asset('assets/global/css/verification-code.css') }}">
    <style>
        /* Golden Trade override */
        .gt-verify .form-label{
            color: rgba(255,255,255,.70);
            font-weight: 900;
            font-size: 12px;
        }
        .gt-verify .verification-code{
            position: relative;
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 18px;
            padding: 14px;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-verify #verification-code{
            background: transparent !important;
            border: none !important;
            color: rgba(255,255,255,.92) !important;
            font-weight: 900;
            letter-spacing: 8px;
            font-size: 16px;
            height: 48px;
        }
        .gt-verify #verification-code:focus{ outline: none !important; box-shadow: none !important; }
        .gt-verify .boxes{
            display:flex;
            gap: 8px;
            margin-top: 10px;
        }
        .gt-verify .boxes span{
            flex: 1;
            height: 44px;
            display:flex;
            align-items:center;
            justify-content:center;
            border-radius: 14px;
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.10);
            color: rgba(210,164,75,.75);
            font-weight: 900;
            font-size: 14px;
        }
    </style>
@endpush

@push('script')
    <script>
        $('#verification-code').on('input', function () {
            $(this).val(function(i, val){
                if (val.length == 6) {
                    $('.submit-form').find('button[type=submit]').html('<i class="las la-spinner fa-spin"></i>');
                    $('.submit-form').submit()
                }
                if(val.length > 6){
                    return val.substring(0, val.length - 1);
                }
                return val;
            });
            for (let index = $(this).val().length; index >= 0 ; index--) {
                $($('.boxes span')[index]).html('');
            }
        });
    </script>
@endpush
