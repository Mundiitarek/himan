@extends($activeTemplate . 'layouts.master')
@section('content')

    <style>
        header, footer, .navbar, .footer { display: none !important; }

        .gt-wrap{
            min-height:100vh;
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
                linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
            color: rgba(255,255,255,.92);
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
        }
        .gt-container{ max-width:1180px; margin:auto; padding:18px; }

        .gt-navbar{
            position: sticky; top: 12px; z-index: 999;
            backdrop-filter: blur(10px);
            background: rgba(15,18,25,.75);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 16px;
            padding: 12px 18px;
            display:flex; align-items:center; justify-content:space-between;
            box-shadow: 0 18px 55px rgba(0,0,0,.45);
        }
        .gt-logo{ display:flex; align-items:center; gap:10px; }
        .gt-logo-box{ width:34px; height:34px; border-radius:10px; background: linear-gradient(180deg,#d2a44b,#b9892e); }
        .gt-logo-text{ font-weight:900; letter-spacing:.5px; }

        .gt-lang{ display:flex; gap:6px; }
        .gt-lang a{
            padding:6px 12px; border-radius:999px; font-size:12px;
            text-decoration:none; color:rgba(255,255,255,.85);
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
        }
        .gt-lang a:hover{ background: rgba(210,164,75,.14); color:#d2a44b; }

        .gt-card{
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 18px;
            padding: 18px;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-card:hover{ background: rgba(255,255,255,.05); }

        .gt-hero{ margin-top:22px; margin-bottom:18px; }
        .gt-hero h3{ font-weight:900; margin:0 0 6px; }
        .gt-muted{ color: rgba(255,255,255,.65); font-size:13px; line-height:1.7; margin:0; }

        /* Restyle existing card */
        .gt-wrap .card{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            border-radius: 18px !important;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
            overflow: hidden;
        }
        .gt-wrap .card-body{ color: rgba(255,255,255,.92) !important; }

        /* Inputs */
        .gt-wrap .form--control,
        .gt-wrap .form-control{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.92) !important;
            border-radius: 14px !important;
            min-height: 42px;
        }
        .gt-wrap .form-control::placeholder{ color: rgba(255,255,255,.45); }
        .gt-wrap .form-label{ color: rgba(255,255,255,.70); font-size: 12px; font-weight: 900; }

        /* Primary button */
        .gt-wrap .btn--base{
            background: linear-gradient(180deg, #d2a44b, #b9892e) !important;
            color: #1a1408 !important;
            border: none !important;
            border-radius: 12px !important;
            font-weight: 900 !important;
        }

        /* Profile side info */
        .gt-wrap .information-list .text-muted{ color: rgba(255,255,255,.65) !important; }
        .gt-wrap .information-list .fw-bold{ color: rgba(255,255,255,.88) !important; }

        /* Image */
        .user-image{
            width:150px; height:150px; border-radius:50%;
            margin: 10px auto 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.03);
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
            overflow: hidden;
        }
        .user-image img{ width:100%; height:100%; object-fit: cover; border-radius: inherit; }

        @media (max-width: 768px){
            .gt-navbar{ flex-wrap:wrap; gap:12px; }
            .gt-container{ padding: 14px; }
        }
    </style>

    <div class="gt-wrap">
        <div class="gt-container">

            {{-- ================= GT NAVBAR ================= --}}
            <div class="gt-navbar">
                <div class="gt-logo">
                    <div class="gt-logo-box"></div>
                    <div class="gt-logo-text">Golden Trade</div>
                </div>

                <div class="gt-lang">
                    <a href="{{ route('lang', 'en') }}">EN</a>
                    <a href="{{ route('lang', 'ar') }}">AR</a>
                </div>
            </div>

            {{-- ================= HERO ================= --}}
            <div class="gt-card gt-hero">
                <h3>{{ __($pageTitle) }}</h3>
                <p class="gt-muted">@lang('Update your profile details and account information')</p>
            </div>

            {{-- ================= ORIGINAL CONTENT (kept, wrapped) ================= --}}
            <div class="gt-card">
                <div class="container p-0">
                    <div class="row justify-content-center">
                        <div class="col-lg-10">
                            <div class="card custom--card">
                                <div class="card-body p-0">
                                    <div class="row gy-4 justify-content-center flex-wrap-reverse">
                                        <div class="col-md-5 col-lg-4">
                                            <div class="user-image text-center">
                                                <img src="{{ getImage(getFilePath('userProfile').'/'. $user->image,getFileSize('userProfile'),true) }}">
                                            </div>
                                            <ul class="list-group list-group-flush h-100 p-3 information-list">
                                                <li class="list-group-item d-flex flex-column justify-content-between border-0 bg-transparent">
                                                    <span class="fw-bold text-muted">{{ $user->username }}</span>
                                                    <small class="text-muted"> <i class="la la-user"></i> @lang('Username')</small>
                                                </li>
                                                <li class="list-group-item d-flex flex-column justify-content-between border-0 bg-transparent">
                                                    <span class="fw-bold text-muted">{{ $user->email }}</span>
                                                    <small class="text-muted"><i class="la la-envelope"></i> @lang('Email')</small>
                                                </li>
                                                <li class="list-group-item d-flex flex-column justify-content-between border-0 bg-transparent">
                                                    <span class="fw-bold text-muted">+{{ $user->mobile }}</span>
                                                    <small class="text-muted"><i class="la la-mobile"></i> @lang('Mobile')</small>
                                                </li>
                                                <li class="list-group-item d-flex flex-column justify-content-between border-0 bg-transparent">
                                                    <span class="fw-bold text-muted">{{ @$user->country }}</span>
                                                    <small class="text-muted"><i class="la la-globe"></i> @lang('Country')</small>
                                                </li>
                                                <li class="list-group-item d-flex flex-column justify-content-between border-0 bg-transparent">
                                                    <span class="fw-bold text-muted">{{ @$user->address }}</span>
                                                    <small class="text-muted"><i class="la la-map-marked"></i> @lang('Address')</small>
                                                </li>
                                            </ul>
                                        </div>

                                        <div class="col-md-7 col-lg-8">
                                            <form class="register py-3 pe-3 ps-3 ps-md-0" action="" method="post" enctype="multipart/form-data">
                                                @csrf
                                                <h5 class="mb-3" style="font-weight:900">@lang('Update Profile')</h5>
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label class="form-label">@lang('First Name')</label>
                                                            <input type="text" class="form-control form--control" name="firstname" value="{{ $user->firstname }}" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label class="form-label">@lang('Last Name')</label>
                                                            <input type="text" class="form-control form--control" name="lastname" value="{{ $user->lastname }}" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label class="form-label">@lang('State')</label>
                                                            <input type="text" class="form-control form--control" name="state" value="{{ @$user->address->state }}">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label class="form-label">@lang('City')</label>
                                                            <input type="text" class="form-control form--control" name="city" value="{{ @$user->address->city }}">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label class="form-label">@lang('Zip Code')</label>
                                                            <input type="text" class="form-control form--control" name="zip" value="{{ @$user->address->zip }}">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label class="form-label">@lang('Address')</label>
                                                            <input type="text" class="form-control form--control" name="address" value="{{ @$user->address->address }}">
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-group">
                                                            <label class="form-label">@lang('Image')</label>
                                                            <input type="file" class="form-control form--control" name="image">
                                                        </div>
                                                    </div>
                                                </div>
                                                <button type="submit" class="btn btn--base w-100">@lang('Submit')</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection

@push('style')
    <style>
        /* keep push area if theme depends on it (already styled above) */
        .user-image img { border-radius: inherit; }
    </style>
@endpush
