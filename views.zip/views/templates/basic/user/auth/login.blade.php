@extends($activeTemplate . 'layouts.app')
@section('main-content')
    @php
        $languages   = App\Models\Language::get();
        $content     = getContent('login.content', true);
        $policyPages = getContent('policy_pages.element', false, null, true);
        $langDetails = $languages->where('code', config('app.locale'))->first();
        $credentials = gs('socialite_credentials');
    @endphp

    <style>
        /* Hide old theme header/footer (CSS only) */
        header, footer, .navbar, .footer { display: none !important; }

        /* Golden Trade Base */
        .gt-wrap{
            min-height:100vh;
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
                linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
            color: rgba(255,255,255,.92);
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
            padding: 18px;
        }
        .gt-container{ max-width:1180px; margin:auto; }

        /* Navbar (per page) */
        .gt-navbar{
            position: sticky; top: 12px; z-index: 999;
            backdrop-filter: blur(10px);
            background: rgba(15,18,25,.75);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 16px;
            padding: 12px 18px;
            display:flex; align-items:center; justify-content:space-between;
            box-shadow: 0 18px 55px rgba(0,0,0,.45);
            margin-bottom: 18px;
        }
        .gt-logo{ display:flex; align-items:center; gap:10px; text-decoration:none; }
        .gt-logo-box{ width:34px; height:34px; border-radius:10px; background: linear-gradient(180deg,#d2a44b,#b9892e); }
        .gt-logo-text{ font-weight:900; letter-spacing:.5px; color: rgba(255,255,255,.92); }

        .gt-lang{ display:flex; gap:6px; align-items:center; }
        .gt-lang .gt-lang-pill{
            padding:6px 12px; border-radius:999px; font-size:12px;
            text-decoration:none;
            color:rgba(255,255,255,.85);
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
            cursor: pointer;
            font-weight: 900;
        }
        .gt-lang .gt-lang-pill:hover{
            background: rgba(210,164,75,.14);
            color:#d2a44b;
        }

        /* Restyle existing login/register skeleton without changing structure */
        .account{ background: transparent !important; }
        .account-inner{
            background: transparent !important;
            gap: 16px;
        }

        .account-left,
        .account-right-wrapper{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            border-radius: 18px !important;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
            overflow: hidden;
        }

        .account-left{ padding: 18px; }
        .account-left__logo img{ max-height: 40px; }
        .account-left__subtitle,
        .account-left__title{ color: rgba(255,255,255,.92) !important; }
        .account-left__subtitle{ opacity:.85; }
        .account-left__content{ margin-top: 12px; }
        .account-left__thumb img{
            border-radius: 18px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.03);
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }

        .account-right-wrapper{ padding: 18px; }
        .account-content__member-text,
        .account-form__desc{ color: rgba(255,255,255,.65) !important; }
        .account-link{ color:#d2a44b !important; font-weight:900; }
        .account-link:hover{ color:#b9892e !important; text-decoration: underline; }

        /* Hide old dropdown switch visually (keep it for logic) */
        .custom--dropdown{ display: none !important; }
        .theme-switch-wrapper{ display: none !important; }

        /* Forms */
        .form--label{ color: rgba(255,255,255,.70) !important; font-size: 12px; font-weight: 900; }
        .form--control,
        .form-control{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.92) !important;
            border-radius: 14px !important;
            min-height: 42px;
        }
        .form--control::placeholder{ color: rgba(255,255,255,.45); }

        .forget-password{ color: rgba(255,255,255,.75) !important; font-size: 12px; font-weight: 800; }
        .forget-password:hover{ color:#d2a44b !important; }

        .btn--base{
            background: linear-gradient(180deg, #d2a44b, #b9892e) !important;
            color: #1a1408 !important;
            border: none !important;
            border-radius: 12px !important;
            font-weight: 900 !important;
        }

        /* Footer links */
        .bottom-footer__text,
        .bottom-footer__right-text{ color: rgba(255,255,255,.65) !important; }
        .bottom-footer__right-link{ color: rgba(255,255,255,.75) !important; }
        .bottom-footer__right-link:hover{ color:#d2a44b !important; }

        /* Mobile */
        @media (max-width: 992px){
            .account-inner{ flex-direction: column; }
            .account-left, .account-right-wrapper{ width: 100%; }
        }
        @media (max-width: 768px){
            .gt-navbar{ flex-wrap: wrap; gap: 10px; }
            .gt-wrap{ padding: 14px; }
        }
    </style>

    <div class="gt-wrap">
        <div class="gt-container">
            {{-- ===== GT Navbar (per page) ===== --}}
            <div class="gt-navbar">
                <a href="{{ route('home') }}" class="gt-logo">
                    <span class="gt-logo-box"></span>
                    <span class="gt-logo-text">Golden Trade</span>
                </a>

                {{-- AR/EN switch (keeps existing change-lang behavior) --}}
                <div class="gt-lang">
                    <button type="button" class="gt-lang-pill change-lang" data-code="en">EN</button>
                    <button type="button" class="gt-lang-pill change-lang" data-code="ar">AR</button>
                </div>
            </div>

            <section class="account">
                <div class="account-inner">
                    <div class="account-left">
                        <a href="{{ route('home') }}" class="account-left__logo">
                            <img src="{{ getImage(getFilePath('logo_icon') . '/logo_base.png') }}">
                        </a>
                        <div class="account-left__content">
                            <h5 class="account-left__subtitle">{{ __(@$content->data_values->heading_one) }}</h5>
                            <h3 class="account-left__title">{{ __(@$content->data_values->subheading_one) }}</h3>
                        </div>
                        <div class="account-left__thumb">
                            <img src="{{ getImage('assets/images/frontend/login/' . @$content->data_values->image, '600x600') }}">
                        </div>
                    </div>

                    <div class="account-right-wrapper">
                        <div class="account-content__top">
                            <div class="account-content__member gap-2">
                                <p class="account-content__member-text"> @lang("Don't have an account")? </p>
                                <a href="{{ route('user.register') }}" class="account-link">@lang('Sign Up')</a>

                                @if (gs('multi_language'))
                                    <div class="custom--dropdown">
                                        <div class="custom--dropdown__selected dropdown-list__item">
                                            <div class="thumb">
                                                <img src="{{ getImage(getFilePath('language') . '/' . @$langDetails->flag, getFileSize('language')) }}">
                                            </div>
                                            <span class="text">{{ __(@$langDetails->name) }}</span>
                                        </div>
                                        <ul class="dropdown-list">
                                            <ul class="dropdown-list">
                                                @foreach ($languages as $language)
                                                    <li class="dropdown-list__item change-lang " data-code="{{ @$language->code }}">
                                                        <div class="thumb">
                                                            <img src="{{ getImage(getFilePath('language') . '/' . @$language->flag, getFileSize('language')) }}">
                                                        </div>
                                                        <span class="text">{{ __(@$language->name) }}</span>
                                                    </li>
                                                @endforeach
                                            </ul>
                                        </ul>
                                    </div>
                                @endif

                                <div class="theme-switch-wrapper">
                                    <label class="theme-switch" for="checkbox">
                                        <input type="checkbox" class="d-none" id="checkbox">
                                        <span class="slider">
                                            <i class="las la-sun"></i>
                                        </span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="account-right">
                            <div class="account-content">
                                <div class="account-form">
                                    <h3 class="account-form__title mb-0">{{ __(@$content->data_values->heading_two) }}</h3>
                                    <p class="account-form__desc">{{ __(@$content->data_values->subheading_two) }}</p>

                                    <x-flexible-view :view="$activeTemplate . 'user.auth.social_provider.index'" action="login" />
                                    <x-flexible-view :view="$activeTemplate . 'user.auth.web3.index'" action="login" />

                                    @if (
                                        @$credentials->linkedin->status ||
                                            @$credentials->facebook->status == Status::ENABLE ||
                                            @$credentials->google->status == Status::ENABLE ||
                                            gs('metamask_login'))
                                        <div class="other-option">
                                            <span class="other-option__text">@lang('OR')</span>
                                        </div>
                                    @endif

                                    <form method="POST" action="{{ route('user.login') }}" class="verify-gcaptcha">
                                        @csrf
                                        <div class="form-group">
                                            <label class="form--label">@lang('Username or Email')</label>
                                            <input type="text" name="username" value="{{ old('username') }}" class="form--control"
                                                placeholder="@lang('Enter your username or email')">
                                        </div>

                                        <div class="form-group">
                                            <div class="d-flex justify-content-between">
                                                <label class="form--label">@lang('Password')</label>
                                                <a href="{{ route('user.password.request') }}" class="forget-password">@lang('Forget Password')?</a>
                                            </div>
                                            <div class="position-relative">
                                                <input name="password" type="password" class="form--control" placeholder="@lang('Enter your password')">
                                                <div class="password-show-hide far fa-eye toggle-password fa-eye-slash" id="#toogle-password"></div>
                                            </div>
                                        </div>

                                        <x-captcha isCustom="true" />

                                        <div class="form-group form-check">
                                            <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                                {{ old('remember') ? 'checked' : '' }}>
                                            <label class="form-check-label" for="remember">
                                                @lang('Remember Me')
                                            </label>
                                        </div>

                                        <button type="submit" class="btn btn--base w-100">@lang('Log In')</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="row gy-3 mt-auto">
                            <div class="col-md-6">
                                <div class="bottom-footer__text">
                                    @php echo copyRightText(); @endphp
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="bottom-footer__right">
                                    <span class="bottom-footer__right-text">
                                        @foreach ($policyPages as $policy)
                                            <a class="bottom-footer__right-link"
                                                href="{{ route('policy.pages', $policy->slug) }}" target="_blank">
                                                {{ __(@$policy->data_values->title) }}
                                            </a>
                                        @endforeach
                                    </span>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </div>
    </div>
@endsection
