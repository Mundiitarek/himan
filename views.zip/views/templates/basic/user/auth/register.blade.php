@extends($activeTemplate . 'layouts.app')
@section('main-content')
    @if (gs('registration'))


        @php
            $languages = App\Models\Language::get();
            $content = getContent('register.content', true);
            $langDetails = $languages->where('code', config('app.locale'))->first();
            $credentials = gs('socialite_credentials');
        @endphp

        <style>
            /* Hide old theme header/footer (CSS only) */
            header, footer, .navbar, .footer { display: none !important; }

            .gt-wrap{
                min-height:100vh;
                background:
                    radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
                    radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
                    linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
                color: rgba(255,255,255,.92);
                font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
                padding: 18px;
            }
            .gt-container{ max-width:1180px; margin:auto; }

            .gt-navbar{
                position: sticky; top: 12px; z-index: 999;
                backdrop-filter: blur(10px);
                background: rgba(15,18,25,.75);
                border: 1px solid rgba(255,255,255,.10);
                border-radius: 16px;
                padding: 12px 18px;
                display:flex; align-items:center; justify-content:space-between;
                box-shadow: 0 18px 55px rgba(0,0,0,.45);
                margin-bottom: 18px;
            }
            .gt-logo{ display:flex; align-items:center; gap:10px; text-decoration:none; }
            .gt-logo-box{ width:34px; height:34px; border-radius:10px; background: linear-gradient(180deg,#d2a44b,#b9892e); }
            .gt-logo-text{ font-weight:900; letter-spacing:.5px; color: rgba(255,255,255,.92); }

            .gt-lang{ display:flex; gap:6px; align-items:center; }
            .gt-lang .gt-lang-pill{
                padding:6px 12px; border-radius:999px; font-size:12px;
                text-decoration:none;
                color:rgba(255,255,255,.85);
                background: rgba(255,255,255,.06);
                border: 1px solid rgba(255,255,255,.10);
                cursor: pointer;
                font-weight: 900;
            }
            .gt-lang .gt-lang-pill:hover{
                background: rgba(210,164,75,.14);
                color:#d2a44b;
            }

            /* Restyle existing structure */
            .account{ background: transparent !important; }
            .account-inner{ background: transparent !important; gap: 16px; }

            .account-left,
            .account-right-wrapper{
                background: rgba(255,255,255,.04) !important;
                border: 1px solid rgba(255,255,255,.10) !important;
                border-radius: 18px !important;
                box-shadow: 0 18px 55px rgba(0,0,0,.35);
                overflow: hidden;
            }

            .account-left{ padding: 18px; }
            .account-left__logo img{ max-height: 40px; }
            .account-left__subtitle-two,
            .account-left__title-two{ color: rgba(255,255,255,.92) !important; }
            .account-left__thumb-two img{
                border-radius: 18px;
                border: 1px solid rgba(255,255,255,.10);
                background: rgba(255,255,255,.03);
                box-shadow: 0 18px 55px rgba(0,0,0,.35);
            }

            .account-right-wrapper{ padding: 18px; }
            .account-content__member-text,
            .account-form__desc{ color: rgba(255,255,255,.65) !important; }
            .account-link{ color:#d2a44b !important; font-weight:900; }
            .account-link:hover{ color:#b9892e !important; text-decoration: underline; }

            /* Keep dropdown for logic, hide it visually */
            .custom--dropdown{ display: none !important; }
            .theme-switch-wrapper{ display: none !important; }

            /* Form fields */
            .form--label, .form-label{
                color: rgba(255,255,255,.70) !important;
                font-size: 12px;
                font-weight: 900;
            }
            .form--control,
            .form-control,
            select.form-control,
            .form-select{
                background: rgba(255,255,255,.04) !important;
                border: 1px solid rgba(255,255,255,.10) !important;
                color: rgba(255,255,255,.92) !important;
                border-radius: 14px !important;
                min-height: 42px;
            }
            .form-control::placeholder{ color: rgba(255,255,255,.45); }

            .btn--base{
                background: linear-gradient(180deg, #d2a44b, #b9892e) !important;
                color: #1a1408 !important;
                border: none !important;
                border-radius: 12px !important;
                font-weight: 900 !important;
            }

            /* Modal */
            .modal-content{
                background: rgba(15,18,25,.95);
                border: 1px solid rgba(255,255,255,.10);
                color: rgba(255,255,255,.92);
                border-radius: 18px;
            }

            /* Mobile */
            @media (max-width: 992px){
                .account-inner{ flex-direction: column; }
                .account-left, .account-right-wrapper{ width: 100%; }
            }
            @media (max-width: 768px){
                .gt-navbar{ flex-wrap: wrap; gap: 10px; }
                .gt-wrap{ padding: 14px; }
            }
        </style>

        <div class="gt-wrap">
            <div class="gt-container">

                {{-- ===== GT Navbar (per page) ===== --}}
                <div class="gt-navbar">
                    <a href="{{ route('home') }}" class="gt-logo">
                        <span class="gt-logo-box"></span>
                        <span class="gt-logo-text">Golden Trade</span>
                    </a>

                    {{-- AR/EN switch (keeps existing change-lang behavior) --}}
                    <div class="gt-lang">
                        <button type="button" class="gt-lang-pill change-lang" data-code="en">EN</button>
                        <button type="button" class="gt-lang-pill change-lang" data-code="ar">AR</button>
                    </div>
                </div>

                <section class="account">
                    <div class="account-inner">
                        <div class="account-left">
                            <a href="{{ route('home') }}" class="account-left__logo">
                                <img src="{{ getImage(getFilePath('logo_icon') . '/logo_base.png') }}">
                            </a>
                            <div class="account-left__content">
                                <h5 class="account-left__subtitle-two mb-0">
                                    {{ __(@$content->data_values->title) }}
                                </h5>
                                <h3 class="account-left__title-two">
                                    @php echo highLightedString(@$content->data_values->heading_one,'account-left__title-two-style')  @endphp
                                </h3>
                            </div>
                            <div class="account-left__thumb-two">
                                <img src="{{ getImage('assets/images/frontend/register/' . @$content->data_values->image, '600x600') }}">
                            </div>
                        </div>

                        <div class="account-right-wrapper">
                            <div class="account-content__top">
                                <div class="account-content__member gap-2">
                                    <p class="account-content__member-text"> @lang('Already have an account')? </p>
                                    <a href="{{ route('user.login') }}" class="account-link"> @lang('Sign In') </a>

                                    @if (gs('multi_language'))
                                        <div class="custom--dropdown">
                                            <div class="custom--dropdown__selected dropdown-list__item">
                                                <div class="thumb">
                                                    <img src="{{ getImage(getFilePath('language') . '/' . @$langDetails->flag, getFileSize('language')) }}">
                                                </div>
                                                <span class="text">{{ __(@$langDetails->name) }}</span>
                                            </div>
                                            <ul class="dropdown-list">
                                                <ul class="dropdown-list">
                                                    @foreach ($languages as $language)
                                                        <li class="dropdown-list__item change-lang " data-code="{{ @$language->code }}">
                                                            <div class="thumb">
                                                                <img src="{{ getImage(getFilePath('language') . '/' . @$language->flag, getFileSize('language')) }}">
                                                            </div>
                                                            <span class="text">{{ __(@$language->name) }}</span>
                                                        </li>
                                                    @endforeach
                                                </ul>
                                            </ul>
                                        </div>
                                    @endif
                                </div>
                            </div>

                            {{-- ===== Original form/content remains as-is below (only styled) ===== --}}
                            <div class="account-right">
                                <div class="account-content">
                                    <div class="account-form">
                                        <h3 class="account-form__title mb-0">{{ __(@$content->data_values->heading_two) }}</h3>
                                        <p class="account-form__desc">{{ __(@$content->data_values->subheading_two) }}</p>

                                        <x-flexible-view :view="$activeTemplate . 'user.auth.social_provider.index'" action="register" />
                                        <x-flexible-view :view="$activeTemplate . 'user.auth.web3.index'" action="register" />

                                        @if (
                                            @$credentials->linkedin->status ||
                                                @$credentials->facebook->status == Status::ENABLE ||
                                                @$credentials->google->status == Status::ENABLE ||
                                                gs('metamask_login'))
                                            <div class="other-option">
                                                <span class="other-option__text">@lang('OR')</span>
                                            </div>
                                        @endif

                                        <form action="{{ route('user.register') }}" method="POST" class="verify-gcaptcha">
                                            @csrf

                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="form--label">@lang('First Name')</label>
                                                        <input type="text" class="form--control" name="firstname" value="{{ old('firstname') }}" required>
                                                    </div>
                                                </div>

                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="form--label">@lang('Last Name')</label>
                                                        <input type="text" class="form--control" name="lastname" value="{{ old('lastname') }}" required>
                                                    </div>
                                                </div>

                                                <div class="col-lg-12">
                                                    <div class="form-group">
                                                        <label class="form--label">@lang('Email')</label>
                                                        <input type="email" class="form--control checkUser" name="email" value="{{ old('email') }}" required>
                                                    </div>
                                                </div>

                                                <div class="col-lg-12">
                                                    <div class="form-group">
                                                        <label class="form--label">@lang('Password')</label>
                                                        <input type="password" class="form--control @if(gs('secure_password')) secure-password @endif" name="password" required>
                                                    </div>
                                                </div>

                                                <div class="col-lg-12">
                                                    <div class="form-group">
                                                        <label class="form--label">@lang('Confirm Password')</label>
                                                        <input type="password" class="form--control" name="password_confirmation" required>
                                                    </div>
                                                </div>

                                                @if (gs('agree'))
                                                    <div class="col-lg-12">
                                                        <div class="form-group form-check">
                                                            <input class="form-check-input" type="checkbox" name="agree" id="agree" required>
                                                            <label class="form-check-label" for="agree">
                                                                @lang('I agree with') <a class="account-link" href="{{ route('policy.pages', 'privacy-policy') }}" target="_blank">@lang('Privacy Policy')</a>
                                                            </label>
                                                        </div>
                                                    </div>
                                                @endif

                                                <div class="col-lg-12">
                                                    <x-captcha isCustom="true" />
                                                </div>

                                                <div class="col-lg-12">
                                                    <button type="submit" class="btn btn--base w-100">@lang('Submit')</button>
                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>

                <div class="modal fade custom--modal" id="existModalCenter" tabindex="-1" role="dialog" aria-labelledby="existModalCenterTitle"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="existModalLongTitle">@lang('You are with us')</h5>
                                <span type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                    <i class="las la-times"></i>
                                </span>
                            </div>
                            <div class="modal-body">
                                <h6 class="text-center">@lang('You already have an account please Login ')</h6>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn--dark btn--sm" data-bs-dismiss="modal">@lang('Close')</button>
                                <a href="{{ route('user.login') }}" class="btn btn--base btn--sm">@lang('Login')</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    @else
        @include($activeTemplate . 'partials.registration_disabled')
    @endif
@endsection

@push('style')
    <style>
        .country-code .input-group-text {
            background: #fff !important;
        }

        .country-code select {
            border: none;
        }

        .country-code select:focus {
            border: none;
            outline: none;
        }
    </style>
@endpush

@if (gs('secure_password'))
    @push('script-lib')
        <script src="{{ asset('assets/global/js/secure_password.js') }}"></script>
    @endpush
@endif

@push('script')
    <script>
        "use strict";
        (function($) {

            $('.checkUser').on('focusout', function(e) {
                var url = '{{ route('user.checkUser') }}';
                var value = $(this).val();
                var token = '{{ csrf_token() }}';

                var data = {
                    email: value,
                    _token: token
                }

                $.post(url, data, function(response) {
                    if (response.data != false) {
                        $('#existModalCenter').modal('show');
                    }
                });
            });
        })(jQuery);
    </script>
@endpush
