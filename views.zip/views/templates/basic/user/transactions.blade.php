@extends($activeTemplate . 'layouts.master')
@section('content')

    {{-- ================= GT PAGE STYLE (Golden Trade) ================= --}}
    <style>
        header, footer, .navbar, .footer { display: none !important; }

        .gt-wrap{
            min-height:100vh;
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
                linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
            color: rgba(255,255,255,.92);
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
        }
        .gt-container{ max-width:1180px; margin:auto; padding:18px; }

        .gt-navbar{
            position: sticky; top: 12px; z-index: 999;
            backdrop-filter: blur(10px);
            background: rgba(15,18,25,.75);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 16px;
            padding: 12px 18px;
            display:flex; align-items:center; justify-content:space-between;
            box-shadow: 0 18px 55px rgba(0,0,0,.45);
        }
        .gt-logo{ display:flex; align-items:center; gap:10px; }
        .gt-logo-box{
            width:34px; height:34px; border-radius:10px;
            background: linear-gradient(180deg,#d2a44b,#b9892e);
        }
        .gt-logo-text{ font-weight:900; letter-spacing:.5px; }

        .gt-lang{ display:flex; gap:6px; }
        .gt-lang a{
            padding:6px 12px; border-radius:999px; font-size:12px;
            text-decoration:none; color:rgba(255,255,255,.85);
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
        }
        .gt-lang a:hover{ background: rgba(210,164,75,.14); color:#d2a44b; }

        .gt-card{
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 18px;
            padding: 18px;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-card:hover{ background: rgba(255,255,255,.05); }
        .gt-hero{ margin-top:22px; margin-bottom:18px; }
        .gt-hero h3{ font-weight:900; margin:0 0 6px; }
        .gt-muted{ color: rgba(255,255,255,.65); font-size:13px; line-height:1.7; margin:0; }

        /* Buttons */
        .gt-btn-primary{
            background: linear-gradient(180deg, #d2a44b, #b9892e) !important;
            color: #1a1408 !important;
            border: none !important;
            border-radius: 12px !important;
            font-weight: 900 !important;
        }
        .gt-wrap .btn--base{ border-radius: 12px !important; font-weight: 900; }
        .gt-wrap .btn--sm{ border-radius: 12px !important; }

        /* Filter card */
        .gt-filter-card{ padding: 16px; }
        .gt-wrap .responsive-filter-card,
        .gt-wrap .card.responsive-filter-card{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            border-radius: 18px !important;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-wrap .card-body{ color: rgba(255,255,255,.90); }
        .gt-wrap .form-label{ color: rgba(255,255,255,.70); font-size: 12px; font-weight: 800; }

        /* Inputs */
        .gt-wrap .form--control,
        .gt-wrap .form-control,
        .gt-wrap .form-select{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.92) !important;
            border-radius: 14px !important;
            min-height: 42px;
        }

        /* Table */
        .gt-wrap .table-wrapper{
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-wrap .table thead th{
            background: rgba(255,255,255,.04);
            color: rgba(255,255,255,.86);
            border-bottom: 1px solid rgba(255,255,255,.10) !important;
            font-weight: 900;
            font-size: 12px;
            letter-spacing: .3px;
        }
        .gt-wrap .table tbody td{
            border-top: 1px solid rgba(255,255,255,.08) !important;
            color: rgba(255,255,255,.88);
            font-size: 13px;
        }
        .gt-wrap .table tbody tr:hover{ background: rgba(255,255,255,.03); }

        /* Select2 dark */
        .select2-container--default .select2-selection--single{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            border-radius: 12px !important;
            height: 42px !important;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered{
            color: rgba(255,255,255,.92) !important;
            line-height: 40px !important;
        }
        .select2-dropdown{
            background: rgba(15,18,25,.98) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
        }
        .select2-results__option{ color: rgba(255,255,255,.86) !important; }
        .select2-results__option--highlighted.select2-results__option--selectable{
            background: rgba(210,164,75,.14) !important;
            color: #d2a44b !important;
        }

        @media (max-width: 768px){
            .gt-navbar{ flex-wrap:wrap; gap:12px; }
            .gt-container{ padding: 14px; }
        }
    </style>

    <div class="gt-wrap">
        <div class="gt-container">

            {{-- ================= GT NAVBAR ================= --}}
            <div class="gt-navbar">
                <div class="gt-logo">
                    <div class="gt-logo-box"></div>
                    <div class="gt-logo-text">Golden Trade</div>
                </div>

                <div class="gt-lang">
                    <a href="{{ route('lang', 'en') }}">EN</a>
                    <a href="{{ route('lang', 'ar') }}">AR</a>
                </div>
            </div>

            {{-- ================= HERO ================= --}}
            <div class="gt-card gt-hero">
                <h3>{{ __($pageTitle) }}</h3>
                <p class="gt-muted">@lang('Filter and review your wallet transactions quickly')</p>
            </div>

            {{-- ================= ORIGINAL CONTENT (WRAPPED) ================= --}}
            <div class="gt-card gt-filter-card">

                <div class="row justify-content-center gy-2">
                    <div class="col-lg-12">
                        <div class="show-filter mb-3 text-end">
                            <button type="button" class="btn btn--base showFilterBtn btn--sm gt-btn-primary">
                                <i class="las la-filter"></i> @lang('Filter')
                            </button>
                        </div>

                        <div class="card responsive-filter-card mb-4">
                            <div class="card-body">
                                <form action="">
                                    <div class="d-flex flex-wrap gap-4">

                                        <div class="flex-grow-1">
                                            <label class="form-label">@lang('Transaction Number')</label>
                                            <input type="text" name="search" value="{{ request()->search }}" class="form-control form--control">
                                        </div>

                                        <div class="flex-grow-1">
                                            <label class="form-label">@lang('Currency')</label>
                                            <div class="position-relative w-100">
                                                <select name="symbol" class="form-select form--control select2" data-width="100%">
                                                    <option value="">@lang('All')</option>
                                                    @foreach ($currencies as $currency)
                                                        <option value="{{ $currency->symbol }}" @selected(request()->symbol == $currency->symbol)>
                                                            {{ __($currency->symbol) }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="flex-grow-1">
                                            <label class="form-label">@lang('Type')</label>
                                            <div class="position-relative w-100">
                                                <select name="trx_type" class="form-select form--control select2" data-minimum-results-for-search="-1"
                                                    data-width="100%">
                                                    <option value="">@lang('All')</option>
                                                    <option value="+" @selected(request()->trx_type == '+')>@lang('Plus')</option>
                                                    <option value="-" @selected(request()->trx_type == '-')>@lang('Minus')</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="flex-grow-1">
                                            <label class="form-label">@lang('Remark')</label>
                                            <div class="position-relative w-100">
                                                <select class="form-select form--control select2" name="remark" data-width="100%">
                                                    <option value="">@lang('Any')</option>
                                                    @foreach ($remarks as $remark)
                                                        <option value="{{ $remark->remark }}" @selected(request()->remark == $remark->remark)>
                                                            {{ __(keyToTitle($remark->remark)) }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="flex-grow-1 align-self-end">
                                            <button class="btn btn--base w-100 gt-btn-primary">
                                                <i class="las la-filter"></i> @lang('Filter')
                                            </button>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="table-wrapper">
                            <table class="table table--responsive--lg">
                                <thead>
                                    <tr>
                                        <th>@lang('Currency | Wallet')</th>
                                        <th>@lang('Transacted')</th>
                                        <th>@lang('Trx')</th>
                                        <th>@lang('Amount')</th>
                                        <th>@lang('Post Balance')</th>
                                        <th>@lang('Detail')</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($transactions as $trx)
                                        @php
                                            $curSymbol = @$trx->wallet->currency->symbol;
                                        @endphp
                                        <tr>
                                            <td>
                                                <div class="text-end text-lg-start">
                                                    <span>{{ $curSymbol }}</span>
                                                    <br>
                                                    <small class="gt-muted">{{ @$trx->wallet->name }} |
                                                        {{ __(strToUpper(@$trx->wallet->type_text)) }} </small>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-end text-lg-start">
                                                    {{ showDateTime($trx->created_at) }}<br>
                                                    <span class="gt-muted">{{ diffForHumans($trx->created_at) }}</span>
                                                </div>
                                            </td>
                                            <td>{{ $trx->trx }}</td>
                                            <td>
                                                <span class="fw-bold @if ($trx->trx_type == '+') text--success @else text--danger @endif">
                                                    {{ $trx->trx_type }} {{ showAmount($trx->amount, currencyFormat: false) }}
                                                    {{ $curSymbol }}
                                                </span>
                                            </td>
                                            <td>
                                                {{ showAmount($trx->post_balance, currencyFormat: false) }}
                                                {{ $curSymbol }}
                                            </td>
                                            <td>{{ __($trx->details) }}</td>
                                        </tr>
                                    @empty
                                        @php echo userTableEmptyMessage('transactions') @endphp
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        @if ($transactions->hasPages())
                            {{ paginateLinks($transactions) }}
                        @endif
                    </div>
                </div>

            </div>

        </div>
    </div>
@endsection

@push('topContent')
    <h4 class="mb-4">{{ __($pageTitle) }}</h4>
@endpush

@push('script-lib')
    <script src="{{ asset('assets/global/js/select2.min.js') }}"></script>
@endpush
@push('style-lib')
    <link rel="stylesheet" href="{{ asset('assets/global/css/select2.min.css') }}">
@endpush
