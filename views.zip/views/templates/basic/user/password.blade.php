@extends($activeTemplate.'layouts.master')
@section('content')

<style>
    header, footer, .navbar, .footer { display: none !important; }

    .gt-wrap{
        min-height:100vh;
        background:
            radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
            radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
            linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
        color: rgba(255,255,255,.92);
        font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
    }
    .gt-container{ max-width:1180px; margin:auto; padding:18px; }

    .gt-navbar{
        position: sticky; top: 12px; z-index: 999;
        backdrop-filter: blur(10px);
        background: rgba(15,18,25,.75);
        border: 1px solid rgba(255,255,255,.10);
        border-radius: 16px;
        padding: 12px 18px;
        display:flex; align-items:center; justify-content:space-between;
        box-shadow: 0 18px 55px rgba(0,0,0,.45);
    }
    .gt-logo{ display:flex; align-items:center; gap:10px; }
    .gt-logo-box{ width:34px; height:34px; border-radius:10px; background: linear-gradient(180deg,#d2a44b,#b9892e); }
    .gt-logo-text{ font-weight:900; letter-spacing:.5px; }

    .gt-lang{ display:flex; gap:6px; }
    .gt-lang a{
        padding:6px 12px; border-radius:999px; font-size:12px;
        text-decoration:none; color:rgba(255,255,255,.85);
        background: rgba(255,255,255,.06);
        border: 1px solid rgba(255,255,255,.10);
    }
    .gt-lang a:hover{ background: rgba(210,164,75,.14); color:#d2a44b; }

    .gt-card{
        background: rgba(255,255,255,.04);
        border: 1px solid rgba(255,255,255,.10);
        border-radius: 18px;
        padding: 18px;
        box-shadow: 0 18px 55px rgba(0,0,0,.35);
    }
    .gt-hero{ margin-top:22px; margin-bottom:18px; }
    .gt-hero h3{ font-weight:900; margin:0 0 6px; }
    .gt-muted{ color: rgba(255,255,255,.65); font-size:13px; line-height:1.7; margin:0; }

    /* Restyle card without changing structure */
    .gt-wrap .card{
        background: rgba(255,255,255,.04) !important;
        border: 1px solid rgba(255,255,255,.10) !important;
        border-radius: 18px !important;
        box-shadow: 0 18px 55px rgba(0,0,0,.35);
        overflow: hidden;
    }
    .gt-wrap .card-header{
        background: rgba(255,255,255,.03) !important;
        border-bottom: 1px solid rgba(255,255,255,.10) !important;
        color: rgba(255,255,255,.92) !important;
    }
    .gt-wrap .card-title{ font-weight: 900 !important; }

    /* Inputs (form--control + form-control) */
    .gt-wrap .form--control,
    .gt-wrap .form-control{
        background: rgba(255,255,255,.04) !important;
        border: 1px solid rgba(255,255,255,.10) !important;
        color: rgba(255,255,255,.92) !important;
        border-radius: 14px !important;
        min-height: 42px;
        width: 100%;
        padding: 10px 12px;
    }
    .gt-wrap label.form-label{
        color: rgba(255,255,255,.70) !important;
        font-size: 12px;
        font-weight: 900;
        margin-bottom: 6px;
    }

    /* Button */
    .gt-wrap .btn--base{
        background: linear-gradient(180deg, #d2a44b, #b9892e) !important;
        color: #1a1408 !important;
        border: none !important;
        border-radius: 12px !important;
        font-weight: 900 !important;
    }

    @media (max-width: 768px){
        .gt-navbar{ flex-wrap:wrap; gap:12px; }
        .gt-container{ padding: 14px; }
    }
</style>

<div class="gt-wrap">
    <div class="gt-container">

        {{-- ================= GT NAVBAR ================= --}}
        <div class="gt-navbar">
            <div class="gt-logo">
                <div class="gt-logo-box"></div>
                <div class="gt-logo-text">Golden Trade</div>
            </div>

            <div class="gt-lang">
                <a href="{{ route('lang', 'en') }}">EN</a>
                <a href="{{ route('lang', 'ar') }}">AR</a>
            </div>
        </div>

        {{-- ================= HERO ================= --}}
        <div class="gt-card gt-hero">
            <h3>{{ __($pageTitle ?? __('Change Password')) }}</h3>
            <p class="gt-muted">@lang('Use a strong password to keep your account secure')</p>
        </div>

        {{-- ================= ORIGINAL CONTENT (kept, wrapped) ================= --}}
        <div class="gt-card">
            <div class="row justify-content-center mt-4">
                <div class="col-md-8">
                    <div class="card custom--card">
                        <div class="card-header">
                            <h5 class="card-title">@lang('Change Password')</h5>
                        </div>
                        <div class="card-body">
                            <form action="" method="post">
                                @csrf
                                <div class="form-group">
                                    <label class="form-label">@lang('Current Password')</label>
                                    <input type="password" class="form--control" name="current_password" required autocomplete="current-password">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">@lang('Password')</label>
                                    <input type="password" class="form--control @if(gs("secure_password")) secure-password @endif" name="password" required autocomplete="current-password">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">@lang('Confirm Password')</label>
                                    <input type="password" class="form-control form--control" name="password_confirmation" required autocomplete="current-password">
                                </div>
                                <button type="submit" class="btn btn--base w-100">@lang('Submit')</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection

@if(gs("secure_password"))
    @push('script-lib')
        <script src="{{ asset('assets/global/js/secure_password.js') }}"></script>
    @endpush
@endif
