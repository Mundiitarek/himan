@extends($activeTemplate.'layouts.master')
@section('content')

    <style>
        /* Hide old theme header/footer (CSS only) */
        header, footer, .navbar, .footer { display: none !important; }

        .gt-wrap{
            min-height:100vh;
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
                linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
            color: rgba(255,255,255,.92);
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
        }
        .gt-container{ max-width:1180px; margin:auto; padding:18px; }

        .gt-navbar{
            position: sticky; top: 12px; z-index: 999;
            backdrop-filter: blur(10px);
            background: rgba(15,18,25,.75);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 16px;
            padding: 12px 18px;
            display:flex; align-items:center; justify-content:space-between;
            box-shadow: 0 18px 55px rgba(0,0,0,.45);
        }
        .gt-logo{ display:flex; align-items:center; gap:10px; }
        .gt-logo-box{ width:34px; height:34px; border-radius:10px; background: linear-gradient(180deg,#d2a44b,#b9892e); }
        .gt-logo-text{ font-weight:900; letter-spacing:.5px; }

        .gt-lang{ display:flex; gap:6px; }
        .gt-lang a{
            padding:6px 12px; border-radius:999px; font-size:12px;
            text-decoration:none; color:rgba(255,255,255,.85);
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
        }
        .gt-lang a:hover{ background: rgba(210,164,75,.14); color:#d2a44b; }

        .gt-card{
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 18px;
            padding: 18px;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-card:hover{ background: rgba(255,255,255,.05); }

        .gt-hero{ margin-top:22px; margin-bottom:18px; }
        .gt-hero h3{ font-weight:900; margin:0 0 6px; }
        .gt-muted{ color: rgba(255,255,255,.65); font-size:13px; line-height:1.7; margin:0; }

        /* Restyle existing cards without changing structure */
        .gt-wrap .card.custom--card{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            border-radius: 18px !important;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
            overflow: hidden;
        }
        .gt-wrap .card-header{
            background: rgba(255,255,255,.03) !important;
            border-bottom: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.92) !important;
        }
        .gt-wrap .card-title{ font-weight: 900 !important; }

        .gt-wrap .form-label{
            color: rgba(255,255,255,.70) !important;
            font-size: 12px;
            font-weight: 900;
            margin-bottom: 6px;
        }

        .gt-wrap .form--control,
        .gt-wrap .form-control{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.92) !important;
            border-radius: 14px !important;
            min-height: 42px;
        }
        .gt-wrap .form-control::placeholder{ color: rgba(255,255,255,.45); }

        /* Buttons */
        .gt-wrap .btn--base{
            background: linear-gradient(180deg, #d2a44b, #b9892e) !important;
            color: #1a1408 !important;
            border: none !important;
            border-radius: 12px !important;
            font-weight: 900 !important;
        }
        .gt-wrap .input-group-text{
            background: rgba(255,255,255,.06) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.86) !important;
            border-radius: 12px !important;
            cursor: pointer;
        }

        /* QR */
        .gt-qr{
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 18px;
            padding: 12px;
            display: inline-block;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-qr img{ max-width: 220px; width: 100%; height: auto; border-radius: 12px; }

        /* Links */
        .gt-wrap .text--base{ color:#d2a44b !important; font-weight: 800; }
        .gt-wrap a.text--base:hover{ color:#b9892e !important; }

        @media (max-width: 768px){
            .gt-navbar{ flex-wrap:wrap; gap:12px; }
            .gt-container{ padding: 14px; }
        }
    </style>

    <div class="gt-wrap">
        <div class="gt-container">

            {{-- ================= GT NAVBAR ================= --}}
            <div class="gt-navbar">
                <div class="gt-logo">
                    <div class="gt-logo-box"></div>
                    <div class="gt-logo-text">Golden Trade</div>
                </div>

                <div class="gt-lang">
                    <a href="{{ route('lang', 'en') }}">EN</a>
                    <a href="{{ route('lang', 'ar') }}">AR</a>
                </div>
            </div>

            {{-- ================= HERO ================= --}}
            <div class="gt-card gt-hero">
                <h3>{{ __($pageTitle ?? __('Two Factor Authentication')) }}</h3>
                <p class="gt-muted">@lang('Secure your account using Google Authenticator (2FA)')</p>
            </div>

            {{-- ================= ORIGINAL CONTENT (kept, wrapped) ================= --}}
            <div class="row justify-content-center gy-4">

                @if(!auth()->user()->ts)
                <div class="col-md-6">
                    <div class="card custom--card">
                        <div class="card-header">
                            <h5 class="card-title">@lang('Add Your Account')</h5>
                        </div>

                        <div class="card-body">
                            <h6 class="mb-3" style="font-weight:800;color:rgba(255,255,255,.86)">
                                @lang('Use the QR code or setup key on your Google Authenticator app to add your account. ')
                            </h6>

                            <div class="form-group mx-auto text-center">
                                <span class="gt-qr">
                                    <img class="mx-auto" src="{{$qrCodeUrl}}" alt="QR">
                                </span>
                            </div>

                            <div class="form-group">
                                <label class="form-label">@lang('Setup Key')</label>
                                <div class="input-group" style="gap:10px;">
                                    <input type="text" name="key" value="{{$secret}}" class="form-control form--control referralURL" readonly>
                                    <button type="button" class="input-group-text copytext" id="copyBoard">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                </div>
                            </div>

                            <label style="font-weight:900;color:rgba(255,255,255,.80)"><i class="fas fa-info-circle"></i> @lang('Help')</label>
                            <p class="mb-0" style="color:rgba(255,255,255,.65);line-height:1.7;font-size:13px">
                                @lang('Google Authenticator is a multifactor app for mobile devices. It generates timed codes used during the 2-step verification process. To use Google Authenticator, install the Google Authenticator application on your mobile device.')
                                <a class="text--base" href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en" target="_blank">
                                    @lang('Download')
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
                @endif

                <div class="col-md-6">
                    @if(auth()->user()->ts)
                        <div class="card custom--card">
                            <div class="card-header">
                                <h5 class="card-title">@lang('Disable 2FA Security')</h5>
                            </div>
                            <form action="{{route('user.twofactor.disable')}}" method="POST">
                                <div class="card-body">
                                    @csrf
                                    <input type="hidden" name="key" value="{{$secret}}">
                                    <div class="form-group">
                                        <label class="form-label">@lang('Google Authenticator OTP')</label>
                                        <input type="text" class="form-control form--control" name="code" required>
                                    </div>
                                    <button type="submit" class="btn btn--base w-100">@lang('Submit')</button>
                                </div>
                            </form>
                        </div>
                    @else
                        <div class="card custom--card">
                            <div class="card-header">
                                <h5 class="card-title">@lang('Enable 2FA Security')</h5>
                            </div>
                            <form action="{{ route('user.twofactor.enable') }}" method="POST">
                                <div class="card-body">
                                    @csrf
                                    <input type="hidden" name="key" value="{{$secret}}">
                                    <div class="form-group">
                                        <label class="form-label">@lang('Google Authenticator OTP')</label>
                                        <input type="text" class="form-control form--control" name="code" required>
                                    </div>
                                    <button type="submit" class="btn btn--base w-100">@lang('Submit')</button>
                                </div>
                            </form>
                        </div>
                    @endif
                </div>

            </div>

        </div>
    </div>

@endsection

@push('style')
<style>
    .copied::after {
        background-color: #{{ gs('base_color') }};
    }
</style>
@endpush

@push('script')
    <script>
        (function($){
            "use strict";
            $('#copyBoard').on('click',function(){
                var copyText = document.getElementsByClassName("referralURL");
                copyText = copyText[0];
                copyText.select();
                copyText.setSelectionRange(0, 99999);
                /*For mobile devices*/
                document.execCommand("copy");
                copyText.blur();
                this.classList.add('copied');
                setTimeout(() => this.classList.remove('copied'), 1500);
            });
        })(jQuery);
    </script>
@endpush
