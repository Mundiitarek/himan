@extends($activeTemplate . 'layouts.master')
@section('content')

    {{-- ================= GT PAGE STYLE (Golden Trade) ================= --}}
    <style>
        /* Hide old theme header/footer (CSS only) */
        header, footer, .navbar, .footer { display: none !important; }

        .gt-wrap{
            min-height:100vh;
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
                linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
            color: rgba(255,255,255,.92);
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
        }
        .gt-container{ max-width:1180px; margin:auto; padding:18px; }

        .gt-navbar{
            position: sticky;
            top: 12px;
            z-index: 999;
            backdrop-filter: blur(10px);
            background: rgba(15,18,25,.75);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 16px;
            padding: 12px 18px;
            display:flex; align-items:center; justify-content:space-between;
            box-shadow: 0 18px 55px rgba(0,0,0,.45);
        }
        .gt-logo{ display:flex; align-items:center; gap:10px; }
        .gt-logo-box{
            width:34px; height:34px; border-radius:10px;
            background: linear-gradient(180deg,#d2a44b,#b9892e);
        }
        .gt-logo-text{ font-weight:900; letter-spacing:.5px; }

        .gt-lang{ display:flex; gap:6px; }
        .gt-lang a{
            padding:6px 12px; border-radius:999px; font-size:12px;
            text-decoration:none; color:rgba(255,255,255,.85);
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
        }
        .gt-lang a:hover{ background: rgba(210,164,75,.14); color:#d2a44b; }

        .gt-card{
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 18px;
            padding: 18px;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-card:hover{ background: rgba(255,255,255,.05); }

        .gt-hero{ margin-top:22px; margin-bottom:18px; }
        .gt-hero h3{ font-weight:900; margin:0 0 6px; }
        .gt-muted{ color: rgba(255,255,255,.65); font-size:13px; line-height:1.7; margin:0; }

        .gt-link{ color:#d2a44b; text-decoration:none; font-weight:800; }
        .gt-link:hover{ color:#b9892e; text-decoration:underline; }

        /* Inputs / Buttons */
        .gt-wrap .form--control,
        .gt-wrap .form-control,
        .gt-wrap .form-select{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.92) !important;
            border-radius: 14px !important;
            min-height: 42px;
        }
        .gt-wrap .form-control::placeholder{ color: rgba(255,255,255,.45); }

        .gt-btn-primary{
            background: linear-gradient(180deg, #d2a44b, #b9892e) !important;
            color: #1a1408 !important;
            border: none !important;
            border-radius: 12px !important;
            font-weight: 900 !important;
        }
        .gt-wrap .btn--base{ border-radius: 12px !important; font-weight: 900; }
        .gt-wrap .btn--sm{ border-radius: 12px !important; }

        /* Table (keep structure, restyle only) */
        .gt-table-card{ padding: 16px; }
        .gt-wrap .table-wrapper{
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-wrap table{ margin:0; }
        .gt-wrap .table thead th{
            background: rgba(255,255,255,.04);
            color: rgba(255,255,255,.86);
            border-bottom: 1px solid rgba(255,255,255,.10) !important;
            font-weight: 900;
            font-size: 12px;
            letter-spacing: .3px;
        }
        .gt-wrap .table tbody td{
            border-top: 1px solid rgba(255,255,255,.08) !important;
            color: rgba(255,255,255,.88);
            font-size: 13px;
        }
        .gt-wrap .table tbody tr:hover{ background: rgba(255,255,255,.03); }

        /* Details button (keep class names) */
        .gt-wrap .btn.btn--base.btn--sm.outline{
            background: rgba(255,255,255,.06) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.86) !important;
            border-radius: 12px !important;
            font-weight: 900;
        }
        .gt-wrap .btn.btn--base.btn--sm.outline:hover{
            background: rgba(255,255,255,.09) !important;
        }

        /* Modal */
        .gt-wrap .modal-content{
            background: rgba(15,18,25,.95);
            border: 1px solid rgba(255,255,255,.10);
            color: rgba(255,255,255,.92);
            border-radius: 18px;
        }
        .gt-wrap .list-group-item{
            background: transparent !important;
            border-color: rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.88) !important;
        }

        /* Mobile */
        @media (max-width: 768px){
            .gt-navbar{ flex-wrap:wrap; gap:12px; }
            .gt-container{ padding: 14px; }
        }
    </style>

    <div class="gt-wrap">
        <div class="gt-container">

            {{-- ================= GT NAVBAR ================= --}}
            <div class="gt-navbar">
                <div class="gt-logo">
                    <div class="gt-logo-box"></div>
                    <div class="gt-logo-text">Golden Trade</div>
                </div>

                <div class="gt-lang">
                    <a href="{{ route('lang', 'en') }}">EN</a>
                    <a href="{{ route('lang', 'ar') }}">AR</a>
                </div>
            </div>

            {{-- ================= HERO ================= --}}
            <div class="gt-card gt-hero">
                <h3>{{ __($pageTitle) }}</h3>
                <p class="gt-muted">@lang('Track deposits, statuses, and gateway details in one place')</p>
            </div>

            {{-- ================= ORIGINAL CONTENT (WRAPPED) ================= --}}
            <div class="gt-card gt-table-card">
                <div class="row justify-content-between align-items-center gy-4">
                    <div class="col-lg-4">
                        <h4 class="mb-0" style="font-weight:900">{{ __($pageTitle) }}</h4>
                        <p class="gt-muted mt-2">@lang('Search and review your deposit history')</p>
                    </div>
                    <div class="col-lg-3">
                        <form>
                            <div class="input-group" style="gap:10px;">
                                <input type="text" name="search" class="form-control form--control" value="{{ request()->search }}"
                                    placeholder="@lang('Search by transactions')">
                                <button class="input-group-text gt-btn-primary">
                                    <i class="las la-search"></i>
                                </button>
                            </div>
                        </form>
                    </div>

                    <div class="col-md-12">
                        <div class="table-wrapper">
                            <table class="table table--responsive--lg">
                                <thead>
                                    <tr>
                                        <th>@lang('Currency | Wallet')</th>
                                        <th>@lang('Gateway | Transaction')</th>
                                        <th>@lang('Initiated')</th>
                                        <th>@lang('Amount')</th>
                                        <th>@lang('Status')</th>
                                        <th>@lang('Details')</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($deposits as $deposit)
                                        @php
                                            $symbol = @$deposit->wallet->currency->symbol;
                                        @endphp
                                        <tr>
                                            <td>
                                                <div class="text-end text-lg-start">
                                                    <span>{{ $symbol }}</span>
                                                    <br>
                                                    <small class="gt-muted">{{ @$deposit->wallet->name }} |
                                                        {{ __(strToUpper(@$deposit->wallet->type_text)) }}</small>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-end text-lg-start">
                                                    <span class="text-primary fw-bold">{{ __($deposit->gateway?->name) }}</span>
                                                    <br>
                                                    <small class="gt-muted"> {{ $deposit->trx }} </small>

                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-end text-lg-start fw-normal">
                                                    <span>{{ showDateTime($deposit->created_at) }}</span> <br>
                                                    <small class="gt-muted">{{ diffForHumans($deposit->created_at) }}</small>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-end text-lg-start fw-normal">
                                                    {{ showAmount($deposit->amount, currencyFormat: false) }} +
                                                    <span class="text--danger" title="@lang('charge')">
                                                        {{ showAmount($deposit->charge, currencyFormat: false) }}
                                                    </span>
                                                    <br>
                                                    <span title="@lang('Amount with charge')" class="gt-muted">
                                                        {{ showAmount($deposit->amount + $deposit->charge, currencyFormat: false) }}
                                                        {{ $symbol }}
                                                    </span>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <div class="text-end text-lg-start">
                                                    @php echo $deposit->statusBadge @endphp
                                                </div>
                                            </td>
                                            @php
                                                $details = $deposit->detail != null ? json_encode($deposit->detail) : null;
                                            @endphp
                                            <td>
                                                <button type="button"
                                                    class="btn btn--base btn--sm outline @if ($deposit->method_code >= 1000) detailBtn @else disabled @endif"
                                                    @if ($deposit->method_code >= 1000) data-info="{{ $details }}" @endif
                                                    @if ($deposit->status == Status::PAYMENT_REJECT) data-admin_feedback="{{ $deposit->admin_feedback }}" @endif>
                                                    <i class="las la-desktop"></i> @lang('Details')

                                                </button>
                                            </td>
                                        </tr>
                                    @empty
                                        @php echo userTableEmptyMessage('deposit') @endphp
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        @if ($deposits->hasPages())
                            {{ paginateLinks($deposits) }}
                        @endif
                    </div>
                </div>
            </div>

            {{-- APPROVE MODAL (unchanged structure) --}}
            <div id="detailModal" class="modal fade custom--modal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">@lang('Deposit Details')</h5>
                            <span type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                <i class="las la-times"></i>
                            </span>
                        </div>
                        <div class="modal-body">
                            <ul class="list-group userData mb-2 list-group-flush"></ul>
                            <div class="feedback"></div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection


@push('script')
    <script>
        (function($) {
            "use strict";
            $('.detailBtn').on('click', function() {
                var modal = $('#detailModal');

                var userData = $(this).data('info');
                var html = '';
                if (userData) {
                    userData.forEach(element => {
                        if (element.type != 'file') {
                            html += `
                            <li class="list-group-item d-flex justify-content-between align-items-center ps-0">
                                <span>${element.name}</span>
                                <span">${element.value}</span>
                            </li>`;
                        }
                    });
                }

                modal.find('.userData').html(html);

                if ($(this).data('admin_feedback') != undefined) {
                    var adminFeedback = `
                        <div class="my-3">
                            <strong>@lang('Admin Feedback')</strong>
                            <p>${$(this).data('admin_feedback')}</p>
                        </div>
                    `;
                } else {
                    var adminFeedback = '';
                }

                modal.find('.feedback').html(adminFeedback);
                modal.modal('show');
            });
        })(jQuery);
    </script>
@endpush
