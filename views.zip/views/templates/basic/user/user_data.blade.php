@extends($activeTemplate . 'layouts.frontend')
@section('content')

    <style>
        /* Hide old theme header/footer (CSS only) */
        header, footer, .navbar, .footer { display: none !important; }

        .gt-wrap{
            min-height:100vh;
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
                linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
            color: rgba(255,255,255,.92);
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
        }
        .gt-container{ max-width:1180px; margin:auto; padding:18px; }

        .gt-navbar{
            position: sticky; top: 12px; z-index: 999;
            backdrop-filter: blur(10px);
            background: rgba(15,18,25,.75);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 16px;
            padding: 12px 18px;
            display:flex; align-items:center; justify-content:space-between;
            box-shadow: 0 18px 55px rgba(0,0,0,.45);
        }
        .gt-logo{ display:flex; align-items:center; gap:10px; }
        .gt-logo-box{ width:34px; height:34px; border-radius:10px; background: linear-gradient(180deg,#d2a44b,#b9892e); }
        .gt-logo-text{ font-weight:900; letter-spacing:.5px; }

        .gt-lang{ display:flex; gap:6px; }
        .gt-lang a{
            padding:6px 12px; border-radius:999px; font-size:12px;
            text-decoration:none; color:rgba(255,255,255,.85);
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.10);
        }
        .gt-lang a:hover{ background: rgba(210,164,75,.14); color:#d2a44b; }

        .gt-card{
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            border-radius: 18px;
            padding: 18px;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-card:hover{ background: rgba(255,255,255,.05); }

        .gt-hero{ margin-top:22px; margin-bottom:18px; }
        .gt-hero h3{ font-weight:900; margin:0 0 6px; }
        .gt-muted{ color: rgba(255,255,255,.65); font-size:13px; line-height:1.7; margin:0; }

        /* Restyle alert */
        .gt-wrap .alert.alert-primary{
            background: rgba(210,164,75,.10) !important;
            border: 1px solid rgba(210,164,75,.22) !important;
            color: rgba(255,255,255,.92) !important;
            border-radius: 18px;
        }
        .gt-wrap .alert.alert-primary strong{ color: rgba(255,255,255,.92) !important; }
        .gt-wrap .alert.alert-primary p{ color: rgba(255,255,255,.70) !important; margin-bottom: 0; }

        /* Restyle existing card without changing structure */
        .gt-wrap .card.custom--card{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            border-radius: 18px !important;
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
            overflow: hidden;
        }
        .gt-wrap .card-body{ color: rgba(255,255,255,.92) !important; }

        /* Inputs */
        .gt-wrap .form-label{
            color: rgba(255,255,255,.70) !important;
            font-size: 12px;
            font-weight: 900;
            margin-bottom: 6px;
        }
        .gt-wrap .form--control,
        .gt-wrap .form-control{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.92) !important;
            border-radius: 14px !important;
            min-height: 42px;
        }
        .gt-wrap .form-control::placeholder{ color: rgba(255,255,255,.45); }

        .gt-wrap .input-group-text{
            background: rgba(255,255,255,.06) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.86) !important;
            border-radius: 12px !important;
        }

        /* Button */
        .gt-wrap .btn--base{
            background: linear-gradient(180deg, #d2a44b, #b9892e) !important;
            color: #1a1408 !important;
            border: none !important;
            border-radius: 12px !important;
            font-weight: 900 !important;
        }

        /* Select2 dark */
        .select2-container--default .select2-selection--single{
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            border-radius: 12px !important;
            height: 42px !important;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered{
            color: rgba(255,255,255,.92) !important;
            line-height: 40px !important;
        }
        .select2-dropdown{
            background: rgba(15,18,25,.98) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
        }
        .select2-results__option{ color: rgba(255,255,255,.86) !important; }
        .select2-results__option--highlighted.select2-results__option--selectable{
            background: rgba(210,164,75,.14) !important;
            color: #d2a44b !important;
        }

        /* Keep page spacing comfortable (override pt-120/pb-120 if needed) */
        .gt-pad{ padding: 22px 0; }

        @media (max-width: 768px){
            .gt-navbar{ flex-wrap:wrap; gap:12px; }
            .gt-container{ padding: 14px; }
        }
    </style>

    <div class="gt-wrap">
        <div class="gt-container">

            {{-- ================= GT NAVBAR ================= --}}
            <div class="gt-navbar">
                <div class="gt-logo">
                    <div class="gt-logo-box"></div>
                    <div class="gt-logo-text">Golden Trade</div>
                </div>

                <div class="gt-lang">
                    <a href="{{ route('lang', 'en') }}">EN</a>
                    <a href="{{ route('lang', 'ar') }}">AR</a>
                </div>
            </div>

            {{-- ================= HERO ================= --}}
            <div class="gt-card gt-hero">
                <h3>@lang('Complete your profile')</h3>
                <p class="gt-muted">@lang('Provide the required information to finish your account setup')</p>
            </div>

            {{-- ================= ORIGINAL CONTENT (kept, wrapped) ================= --}}
            <div class="gt-pad">
                <div class="container p-0">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <div class="card custom--card">
                                <div class="card-body">
                                    <div class="alert alert-primary mb-4" role="alert">
                                        <strong>
                                            @lang('Complete your profile')
                                        </strong>
                                        <p>@lang('You need to complete your profile by providing below information.')</p>
                                    </div>

                                    <form method="POST" action="{{ route('user.data.submit') }}">
                                        @csrf
                                        <div class="row">
                                            @if (!$user->email)
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label class="form-label">@lang('E-Mail Address')</label>
                                                        <input type="email" class="form-control form--control checkUser" name="email"
                                                            value="{{ old('email') }}" required>
                                                    </div>
                                                </div>
                                            @endif

                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="form-label">@lang('Username')</label>
                                                    <input type="text" class="form-control form--control" name="username"
                                                        value="{{ old('username') }}">
                                                    <small class="text--danger usernameExist mt-2"></small>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group position-relative">
                                                    <label class="form-label">@lang('Country')</label>
                                                    <select name="country" class="form-control form--control select2" required>
                                                        @foreach ($countries as $key => $country)
                                                            <option data-mobile_code="{{ $country->dial_code }}" value="{{ $country->country }}"
                                                                data-code="{{ $key }}">{{ __($country->country) }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="form-label">@lang('Mobile')</label>
                                                    <div class="input-group ">
                                                        <span class="input-group-text mobile-code"></span>
                                                        <input type="hidden" name="mobile_code">
                                                        <input type="hidden" name="country_code">
                                                        <input type="number" name="mobile" value="{{ old('mobile') }}"
                                                            class="form-control form--control checkUser" required>
                                                    </div>
                                                    <small class="text--danger mobileExist"></small>
                                                </div>
                                            </div>

                                            <div class="form-group col-sm-6">
                                                <label class="form-label">@lang('Address')</label>
                                                <input type="text" class="form-control form--control" name="address" value="{{ old('address') }}">
                                            </div>

                                            <div class="form-group col-sm-6">
                                                <label class="form-label">@lang('State')</label>
                                                <input type="text" class="form-control form--control" name="state" value="{{ old('state') }}">
                                            </div>

                                            <div class="form-group col-sm-6">
                                                <label class="form-label">@lang('Zip Code')</label>
                                                <input type="text" class="form-control form--control" name="zip" value="{{ old('zip') }}">
                                            </div>

                                            <div class="form-group col-sm-6">
                                                <label class="form-label">@lang('City')</label>
                                                <input type="text" class="form-control form--control" name="city" value="{{ old('city') }}">
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn--base w-100">
                                            @lang('Submit')
                                        </button>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection

@push('style-lib')
    <link rel="stylesheet" href="{{ asset('assets/global/css/select2.min.css') }}">
@endpush

@push('script-lib')
    <script src="{{ asset('assets/global/js/select2.min.js') }}"></script>
@endpush

@push('script')
    <script>
        "use strict";
        (function($) {

            @if ($mobileCode)
                $(`option[data-code={{ $mobileCode }}]`).attr('selected', '');
            @endif

            $('.select2').select2({
                width: "100%",
                dropdownParent: $('.position-relative')
            });

            $('select[name=country]').on('change', function() {
                $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
                $('input[name=country_code]').val($('select[name=country] :selected').data('code'));
                $('.mobile-code').text('+' + $('select[name=country] :selected').data('mobile_code'));
                var value = $('[name=mobile]').val();
                var name = 'mobile';
                checkUser(value, name);
            });

            $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
            $('input[name=country_code]').val($('select[name=country] :selected').data('code'));
            $('.mobile-code').text('+' + $('select[name=country] :selected').data('mobile_code'));

            $('.checkUser').on('focusout', function(e) {
                var value = $(this).val();
                var name = $(this).attr('name')
                checkUser(value, name);
            });

            function checkUser(value, name) {
                var url = '{{ route('user.checkUser') }}';
                var token = '{{ csrf_token() }}';

                if (name == 'mobile') {
                    var mobile = `${value}`;
                    var data = {
                        mobile: mobile,
                        mobile_code: $('.mobile-code').text().substr(1),
                        _token: token
                    }
                }
                if (name == 'username') {
                    var data = {
                        username: value,
                        _token: token
                    }
                }
                $.post(url, data, function(response) {
                    if (response.data != false) {
                        $(`.${response.type}Exist`).text(`${response.field} already exist`);
                    } else {
                        $(`.${response.type}Exist`).text('');
                    }
                });
            }
        })(jQuery);
    </script>
@endpush
