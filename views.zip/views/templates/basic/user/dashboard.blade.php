@extends($activeTemplate . 'layouts.master')

@section('content')

{{-- ================= GT GLOBAL STYLE ================= --}}
<style>
/* Hide old theme header/footer */
header, footer, .navbar, .footer {
    display: none !important;
}

/* Base */
.gt-wrap {
    min-height: 100vh;
    background:
        radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
        radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
        linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
    color: rgba(255,255,255,.92);
    font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
}

.gt-container {
    max-width: 1180px;
    margin: auto;
    padding: 18px;
}

/* Navbar */
.gt-navbar {
    position: sticky;
    top: 12px;
    z-index: 999;
    backdrop-filter: blur(10px);
    background: rgba(15,18,25,.75);
    border: 1px solid rgba(255,255,255,.1);
    border-radius: 16px;
    padding: 12px 18px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 18px 55px rgba(0,0,0,.45);
}

.gt-logo {
    display: flex;
    align-items: center;
    gap: 10px;
}

.gt-logo-box {
    width: 34px;
    height: 34px;
    border-radius: 10px;
    background: linear-gradient(180deg,#d2a44b,#b9892e);
}

.gt-logo-text {
    font-weight: 900;
    letter-spacing: .5px;
}

/* Lang Switch */
.gt-lang {
    display: flex;
    gap: 6px;
}

.gt-lang a {
    padding: 6px 12px;
    border-radius: 999px;
    font-size: 12px;
    text-decoration: none;
    color: rgba(255,255,255,.85);
    background: rgba(255,255,255,.06);
    border: 1px solid rgba(255,255,255,.1);
}

.gt-lang a:hover {
    background: rgba(210,164,75,.14);
    color: #d2a44b;
}

/* Cards */
.gt-card {
    background: rgba(255,255,255,.04);
    border: 1px solid rgba(255,255,255,.1);
    border-radius: 18px;
    padding: 18px;
    box-shadow: 0 18px 55px rgba(0,0,0,.35);
}

.gt-card:hover {
    background: rgba(255,255,255,.05);
}

/* Hero */
.gt-hero {
    margin-top: 22px;
    margin-bottom: 22px;
}

/* Mobile */
@media (max-width: 768px) {
    .gt-navbar {
        flex-wrap: wrap;
        gap: 12px;
    }
}
</style>

<div class="gt-wrap">

    <div class="gt-container">

        {{-- ================= GT NAVBAR ================= --}}
        <div class="gt-navbar">
            <div class="gt-logo">
                <div class="gt-logo-box"></div>
                <div class="gt-logo-text">
                    Golden Trade
                </div>
            </div>

            {{-- Language Switch --}}
            <div class="gt-lang">
                <a href="{{ route('lang', 'en') }}">EN</a>
                <a href="{{ route('lang', 'ar') }}">AR</a>
            </div>
        </div>

        {{-- ================= HERO ================= --}}
        <div class="gt-card gt-hero">
            <h3 style="font-weight:900;margin-bottom:6px">
                {{ __($pageTitle) }}
            </h3>
            <p style="color:rgba(255,255,255,.65);font-size:13px">
                @lang('Welcome back to your trading dashboard')
            </p>
        </div>

        {{-- ================= DASHBOARD GRID START ================= --}}
        <div class="row gy-4 justify-content-center">
            <div class="col-xxl-9 col-lg-12">
                <div class="row gy-3">

                    @php
                        $kycContent = getContent('kyc_content.content', true);
                    @endphp

                    {{-- ================== ALERTS (RESTYLED) ================== --}}
                    @if ($user->kv == Status::KYC_UNVERIFIED && $user->kyc_rejection_reason)
                        <div class="col-12">
                            <div class="alert alert--danger skeleton gt-alert" role="alert">
                                <div class="flex-align justify-content-between">
                                    <h5 class="alert-heading text--danger mb-2">@lang('KYC Documents Rejected')</h5>
                                    <button data-bs-toggle="modal" data-bs-target="#kycRejectionReason" class="gt-btn gt-btn-ghost">@lang('Show Reason')</button>
                                </div>
                                <p class="mb-0">
                                    {{ __(@$kycContent->data_values->rejection_content) }}
                                    <a href="{{ route('user.kyc.data') }}" class="gt-link">@lang('See KYC Data')</a>
                                </p>
                            </div>
                        </div>
                    @endif

                    @if ($user->kv == Status::KYC_UNVERIFIED && !$user->kyc_rejection_reason)
                        <div class="col-12">
                            <div class="alert alert--danger skeleton gt-alert" role="alert">
                                <h5 class="alert-heading text--danger mb-2">@lang('KYC Verification Required')</h5>
                                <p class="mb-0">
                                    {{ __(@$kycContent->data_values->unverified_content) }}
                                    <a href="{{ route('user.kyc.form') }}" class="gt-link">@lang('Click here to verify')</a>
                                </p>
                            </div>
                        </div>
                    @endif

                    @if ($user->kv == Status::KYC_PENDING)
                        <div class="col-12">
                            <div class="alert alert--warning flex-column justify-content-start align-items-start skeleton gt-alert gt-alert-warning" role="alert">
                                <h5 class="alert-heading text--warning mb-2">@lang('KYC Verification Pending')</h5>
                                <p class="mb-0">
                                    {{ __(@$kycContent->data_values->pending_content) }}
                                    <a href="{{ route('user.kyc.data') }}" class="gt-link">@lang('See KYC Data')</a>
                                </p>
                            </div>
                        </div>
                    @endif

                    @if (!$user->ts)
                        <div class="col-12">
                            <div class="alert-item 2fa-notice skeleton">
                                <span class="delete-icon skeleton" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Delete">
                                    <i class="las la-times"></i>
                                </span>
                                <div class="alert flex-align alert--danger remove-2fa-notice gt-alert" role="alert">
                                    <span class="alert__icon">
                                        <i class="fas fa-exclamation"></i>
                                    </span>
                                    <div class="alert__content">
                                        <span class="alert__title">
                                            @lang('To secure your account add 2FA verification').
                                            <a href="{{ route('user.twofactor') }}" class="gt-link gt-link-small">@lang('Enable')</a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif

                    {{-- ================== MAIN DASHBOARD AREA ================== --}}
                    <div class="col-12">
                        <div class="dashboard-card-wrapper gt-surface">

                            {{-- Top Widgets --}}
                            <div class="row gy-4 mb-3 justify-content-center">
                                <div class="col-xxl-3 col-sm-6">
                                    <div class="dashboard-card skeleton gt-mini-card">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="dashboard-card__icon text--base gt-ic">
                                                <i class="las la-spinner"></i>
                                            </span>
                                            <div class="dashboard-card__content">
                                                <a href="{{ route('user.order.open') }}" class="dashboard-card__coin-name mb-0 gt-card-title">
                                                    @lang('Open Order')
                                                </a>
                                                <h6 class="dashboard-card__coin-title gt-card-number"> {{ getAmount($widget['open_order']) }} </h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xxl-3 col-sm-6">
                                    <div class="dashboard-card skeleton gt-mini-card">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="dashboard-card__icon text--success gt-ic">
                                                <i class="las la-check-circle"></i>
                                            </span>
                                            <div class="dashboard-card__content">
                                                <a href="{{ route('user.order.completed') }}" class="dashboard-card__coin-name mb-0 gt-card-title">
                                                    @lang('Completed Order')
                                                </a>
                                                <h6 class="dashboard-card__coin-title gt-card-number"> {{ getAmount($widget['completed_order']) }} </h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xxl-3 col-sm-6">
                                    <div class="dashboard-card skeleton gt-mini-card">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="dashboard-card__icon text--danger gt-ic gt-ic-danger">
                                                <i class="las la-times-circle"></i>
                                            </span>
                                            <div class="dashboard-card__content">
                                                <a href="{{ route('user.order.canceled') }}" class="dashboard-card__coin-name mb-0 gt-card-title">
                                                    @lang('Canceled Order')
                                                </a>
                                                <h6 class="dashboard-card__coin-title gt-card-number"> {{ getAmount($widget['canceled_order']) }} </h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xxl-3 col-sm-6">
                                    <div class="dashboard-card skeleton gt-mini-card">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="dashboard-card__icon text--base gt-ic">
                                                <span class="icon-trade fs-50"></span>
                                            </span>
                                            <div class="dashboard-card__content">
                                                <a href="{{ route('user.trade.history') }}" class="dashboard-card__coin-name mb-0 gt-card-title">
                                                    @lang('Total Trade')
                                                </a>
                                                <h6 class="dashboard-card__coin-title gt-card-number"> {{ getAmount($widget['total_trade']) }} </h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- Recent Order + Recent Transactions --}}
                            <div class="row gy-4 mb-3 justify-content-center">
                                <div class="col-lg-6">
                                    <div class="transection h-100 gt-card gt-panel">
                                        <div class="gt-panel-head">
                                            <h5 class="transection__title skeleton gt-panel-title"> @lang('Recent Order') </h5>
                                        </div>

                                        @forelse ($recentOrders as $recentOrder)
                                            <div class="transection__item skeleton gt-item">
                                                <div class="d-flex flex-wrap align-items-center gt-item-left">
                                                    <div class="transection__date gt-date">
                                                        <h6 class="transection__date-number text-white">
                                                            {{ showDateTime($recentOrder->created_at, 'd') }}
                                                        </h6>
                                                        <span class="transection__date-text">
                                                            {{ __(strtoupper(showDateTime($recentOrder->created_at, 'M'))) }}
                                                        </span>
                                                    </div>
                                                    <div class="transection__content gt-item-content">
                                                        <h6 class="transection__content-title">
                                                            @php echo $recentOrder->orderSideBadge; @endphp
                                                        </h6>
                                                        <p class="transection__content-desc">
                                                            @lang('Placed an order in the ')
                                                            {{ @$recentOrder->pair->symbol }} @lang('pair to')
                                                            {{ __(strtolower(strip_tags($recentOrder->orderSideBadge))) }}
                                                            {{ showAmount($recentOrder->amount, currencyFormat: false) }}
                                                            {{ @$recentOrder->pair->coin->symbol }}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="gt-status">
                                                    @php echo $recentOrder->statusBadge; @endphp
                                                </div>
                                            </div>
                                        @empty
                                            <div class="transection__item justify-content-center p-5 skeleton gt-empty">
                                                <div class="empty-thumb text-center">
                                                    <img src="{{ asset('assets/images/extra_images/empty.png') }}" />
                                                    <p class="fs-14">@lang('No order found')</p>
                                                </div>
                                            </div>
                                        @endforelse
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="transection h-100 gt-card gt-panel">
                                        <div class="gt-panel-head">
                                            <h5 class="transection__title skeleton gt-panel-title"> @lang('Recent Transactions') </h5>
                                        </div>

                                        @forelse ($recentTransactions as $recentTransaction)
                                            <div class="transection__item skeleton gt-item">
                                                <div class="d-flex flex-wrap align-items-center gt-item-left">
                                                    <div class="transection__date gt-date">
                                                        <h6 class="transection__date-number text-white">
                                                            {{ showDateTime($recentTransaction->created_at, 'd') }}
                                                        </h6>
                                                        <span class="transection__date-text">
                                                            {{ __(strtoupper(showDateTime($recentTransaction->created_at, 'M'))) }}
                                                        </span>
                                                    </div>
                                                    <div class="transection__content gt-item-content">
                                                        <h6 class="transection__content-title">
                                                            {{ __(ucwords(keyToTitle($recentTransaction->remark))) }}
                                                        </h6>
                                                        <p class="transection__content-desc">
                                                            {{ __($recentTransaction->details) }}
                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="gt-status">
                                                    @if ($recentTransaction->trx_type == '+')
                                                        <span class="badge badge--success gt-badge gt-badge-success">
                                                            @lang('Plus')
                                                        </span>
                                                    @else
                                                        <span class="badge badge--danger gt-badge gt-badge-danger">
                                                            @lang('Minus')
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                        @empty
                                            <div class="transection__item justify-content-center p-5 skeleton gt-empty">
                                                <div class="empty-thumb text-center">
                                                    <img src="{{ asset('assets/images/extra_images/empty.png') }}" />
                                                    <p class="fs-14">@lang('No transactions found')</p>
                                                </div>
                                            </div>
                                        @endforelse
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

            {{-- ================== RIGHT SIDEBAR ================== --}}
            <div class="col-xxl-3">
                <div class="dashboard-right">
                    <div class="right-sidebar gt-card gt-sidebar">
                        <div class="right-sidebar__header mb-3 skeleton">
                            <div class="d-flex flex-between flex-wrap">
                                <div>
                                    <h4 class="mb-0 fs-18">@lang('Wallet Overview')</h4>
                                    <p class="mt-0 fs-12 gt-muted">@lang('Available wallet balance including the converted total balance')</p>
                                </div>
                                <span class="toggle-dashboard-right dashboard--popup-close"><i class="las la-times"></i></span>
                            </div>
                        </div>

                        <div class="text-center mb-3 skeleton">
                            <h3 class="right-sidebar__number mb-0 pb-0 gt-balance">
                                {{ showAmount($estimatedBalance) }}
                            </h3>
                            <span class="fs-14 mt-0 gt-muted">@lang('Estimated Total Balance')</span>
                        </div>

                        <div class="right-sidebar__menu gt-scroll">
                            <div class="wallet-wrapper">
                                @forelse ($wallets as $wallet)
                                    <div class="right-sidebar__item flex-wrap wallet-list skeleton gt-wallet">
                                        <div class="d-flex align-items-center">
                                            <span class="right-sidebar__item-icon">
                                                <img src="{{ @$wallet->currency->image_url }}">
                                            </span>
                                            <h6 class="right-sidebar__item-name">
                                                {{ strLimit(@$wallet->currency->name, 10) }}
                                                <span class="fs-11 d-block gt-muted">
                                                    {{ @$wallet->currency->symbol }}
                                                </span>
                                            </h6>
                                        </div>
                                        <h6 class="right-sidebar__item-number gt-wallet-amount">
                                            {{ showAmount($wallet->balance, currencyFormat: false) }}
                                        </h6>
                                    </div>
                                @empty
                                @endforelse
                            </div>

                            <button type="button" class="w-100 show-more-wallet right-sidebar__button skeleton mt-2 gt-btn gt-btn-ghost">
                                <span class="right-sidebar__button-icon">
                                    <i class="las la-chevron-circle-down"></i>@lang('Show More')
                                </span>
                            </button>
                        </div>
                    </div>

                    <div class="right-sidebar mt-3 gt-card gt-sidebar">
                        <div class="right-sidebar__header mb-3 skeleton">
                            <h4 class="mb-0 fs-18">@lang('Deposit Money')</h4>
                            <p class="mt-0 fs-12 gt-muted">@lang('Make crypto & fiat deposits in a few steps')</p>
                        </div>
                        <div class="right-sidebar__deposit custom-select2">
                            <form class="skeleton deposit-form">
                                <div class="form-group position-relative" id="currency_list_wrapper">
                                    <div class="input-group gt-inputgroup">
                                        <input type="number" step="any" name="amount" class="form--control form-control gt-input"
                                            placeholder="@lang('Amount')">
                                        <div class="input-group-text skeleton gt-input-addon">
                                            <x-currency-list :action="route('user.currency.all')" valueType="2" logCurrency="true" />
                                        </div>
                                    </div>
                                </div>
                                <button class="deposit__button btn btn--base w-100 gt-btn gt-btn-primary" type="submit">
                                    <span class="icon-deposit"></span> @lang('Deposit')
                                </button>
                            </form>
                        </div>
                    </div>

                    <div class="right-sidebar mt-3 gt-card gt-sidebar">
                        <div class="right-sidebar__header mb-3 skeleton">
                            <h4 class="mb-0 fs-18">@lang('Withdraw Money')</h4>
                            <p class="mt-0 fs-12 gt-muted">@lang('Withdrawal your balance with our world-class withdrawal process')</p>
                        </div>
                        <div class="right-sidebar__deposit">
                            <form class="skeleton withdraw-form custom-select2">
                                <div class="form-group position-relative" id="withdraw_currency_list_wrapper">
                                    <div class="input-group gt-inputgroup">
                                        <input type="number" name="amount" step="any" class="form--control form-control gt-input"
                                            placeholder="@lang('Amount')">
                                        <div class="input-group-text skeleton gt-input-addon">
                                            <x-currency-list :action="route('user.currency.all')" id="withdraw_currency_list" parent="withdraw_currency_list_wrapper"
                                                valueType="2" logCurrency="true" />
                                        </div>
                                    </div>
                                </div>
                                <button class="deposit__button btn btn--base w-100 gt-btn gt-btn-primary" type="submit">
                                    <span class="icon-withdraw"></span> @lang('Withdraw')
                                </button>
                            </form>
                        </div>
                    </div>

                </div>
            </div>

        </div> {{-- row --}}
    </div> {{-- container --}}
</div> {{-- wrap --}}

{{-- ================== KEEP THESE EXACT ================== --}}
<x-flexible-view :view="$activeTemplate . 'user.components.canvas.deposit'" :meta="['gateways' => $gateways]" />
<x-flexible-view :view="$activeTemplate . 'user.components.canvas.withdraw'" :meta="['withdrawMethods' => $withdrawMethods]" />

@if ($user->kv == Status::KYC_UNVERIFIED && $user->kyc_rejection_reason)
    <div class="modal fade custom--modal" id="kycRejectionReason">
        <div class="modal-dialog" role="document">
            <div class="modal-content gt-modal">
                <div class="modal-header">
                    <h5 class="modal-title">@lang('KYC Document Rejection Reason')</h5>
                    <span type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <i class="las la-times"></i>
                    </span>
                </div>
                <div class="modal-body">
                    <p>{{ auth()->user()->kyc_rejection_reason }}</p>
                </div>
            </div>
        </div>
    </div>
@endif

@endsection

@push('script-lib')
    <script src="{{ asset('assets/global/js/select2.min.js') }}"></script>
@endpush

@push('style-lib')
    <link rel="stylesheet" href="{{ asset('assets/global/css/select2.min.css') }}">
@endpush

@push('script')
    <script>
        "use strict";
        (function($) {

            $.each($('.canvas-select2'), function(index, element) {
                $('.canvas-select2').select2({
                    dropdownParent: $(this).closest('.position-relative')
                });
            });

            $('.2fa-notice').on('click', '.delete-icon', function(e) {
                $(this).closest('.col-12').fadeOut('slow', function() {
                    $(this).remove();
                });
            });

            let walletSkip = 3;

            $('.show-more-wallet').on('click', function(e) {
                let route = "{{ route('user.more.wallet', ':skip') }}";
                let $this = $(this);
                $.ajax({
                    url: route.replace(':skip', walletSkip),
                    type: "GET",
                    dataType: 'json',
                    cache: false,
                    beforeSend: function() {
                        $this.html(`
                        <span class="right-sidebar__button-icon">
                            <i class="las la-spinner la-spin"></i>
                        </span>`).attr('disabled', true);
                    },
                    complete: function(e) {
                        setTimeout(() => {
                            $this.html(`
                        <span class="right-sidebar__button-icon">
                            <i class="las la-chevron-circle-down"></i>
                        </span>@lang('Show More')`).attr('disabled', false);
                            $('.wallet-list').removeClass('skeleton');
                        }, 500);
                    },
                    success: function(resp) {
                        if (resp.success && (resp.wallets && resp.wallets.length > 0)) {
                            let html = "";
                            $.each(resp.wallets, function(i, wallet) {
                                html += `
                            <div class="right-sidebar__item wallet-list skeleton">
                                <div class="d-flex align-items-center">
                                    <span class="right-sidebar__item-icon">
                                        <img src="${wallet.currency.image_url}">
                                    </span>
                                    <h6 class="right-sidebar__item-name">
                                        ${wallet.currency.name}
                                        <span class="fs-11 d-block">
                                            ${wallet.currency.symbol}
                                        </span>
                                    </h6>
                                </div>

                                <h6 class="right-sidebar__item-number">${getAmount(wallet.balance)}</h6>
                            </div>
                            `
                            });
                            walletSkip += 3;
                            $('.wallet-wrapper').append(html);
                        } else {
                            $this.remove();
                        }

                        $('.right-sidebar__menu').animate({
                            scrollTop: $('.right-sidebar__menu')[0].scrollHeight + 150
                        }, "slow");
                    },
                    error: function() {
                        notify('error', "@lang('Something went to wrong')");
                        $this.remove();
                    }
                });
            });


        })(jQuery);
    </script>
@endpush

@push('topContent')
    <h4 class="mb-4">{{ __($pageTitle) }}</h4>
@endpush

@push('style')
    <style>
        /* Keep original select2 image rule */
        .select2-image { max-width: 50px; }

        /* ===== Golden Trade Additions (page-only) ===== */
        .gt-muted { color: rgba(255,255,255,.65); }
        .gt-link { color: #d2a44b; text-decoration: none; font-weight: 700; }
        .gt-link:hover { color: #b9892e; text-decoration: underline; }
        .gt-link-small { font-size: 12px; }

        .gt-alert {
            border-radius: 18px;
            border: 1px solid rgba(255,120,120,.22);
            background: rgba(255,120,120,.08);
            color: rgba(255,255,255,.9);
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
        }
        .gt-alert-warning {
            border-color: rgba(210,164,75,.22);
            background: rgba(210,164,75,.10);
        }

        .gt-btn {
            border-radius: 12px;
            padding: 9px 12px;
            font-weight: 800;
            font-size: 12px;
            line-height: 1;
            border: 1px solid rgba(255,255,255,.10);
        }
        .gt-btn-primary {
            background: linear-gradient(180deg, #d2a44b, #b9892e);
            color: #1a1408 !important;
            border: none;
        }
        .gt-btn-ghost {
            background: rgba(255,255,255,.06);
            color: rgba(255,255,255,.86);
        }
        .gt-btn-ghost:hover { background: rgba(255,255,255,.09); }

        .gt-surface { padding: 2px; }

        .gt-mini-card {
            border-radius: 18px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
            box-shadow: 0 18px 55px rgba(0,0,0,.35);
            transition: .18s ease;
        }
        .gt-mini-card:hover { background: rgba(255,255,255,.05); transform: translateY(-1px); }

        .gt-ic {
            width: 44px; height: 44px;
            display: inline-flex; align-items: center; justify-content: center;
            border-radius: 14px;
            background: rgba(210,164,75,.14);
            border: 1px solid rgba(255,255,255,.10);
            color: #d2a44b;
        }
        .gt-ic-danger { background: rgba(255,120,120,.10); color: rgba(255,120,120,.92); }

        .gt-card-title { font-weight: 800; color: rgba(255,255,255,.88) !important; text-decoration: none; }
        .gt-card-number { font-weight: 900; margin-top: 6px; }

        .gt-panel { padding: 16px; }
        .gt-panel-title { font-weight: 900; }
        .gt-panel-head { margin-bottom: 10px; }

        .gt-item {
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,.08);
            background: rgba(255,255,255,.03);
            padding: 12px 12px;
            margin-top: 10px;
            display: flex;
            justify-content: space-between;
            gap: 12px;
        }
        .gt-item-left { gap: 12px; }
        .gt-item-content p { margin-bottom: 0; color: rgba(255,255,255,.65); font-size: 12px; line-height: 1.7; }
        .gt-date {
            width: 56px;
            border-radius: 14px;
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.10);
            text-align: center;
            padding: 8px 6px;
        }
        .gt-date .transection__date-text { color: rgba(255,255,255,.65); font-size: 11px; }

        .gt-status { display:flex; align-items:center; }

        .gt-badge {
            border-radius: 999px;
            padding: 6px 10px;
            font-size: 11px;
            font-weight: 900;
            border: 1px solid rgba(255,255,255,.10);
        }
        .gt-badge-success { background: rgba(80,200,140,.10); color: rgba(180,255,220,.92); }
        .gt-badge-danger { background: rgba(255,120,120,.10); color: rgba(255,120,120,.92); }

        .gt-sidebar { padding: 16px; }
        .gt-scroll { max-height: 320px; overflow: auto; padding-right: 4px; }
        .gt-scroll::-webkit-scrollbar { width: 6px; }
        .gt-scroll::-webkit-scrollbar-thumb { background: rgba(255,255,255,.12); border-radius: 999px; }

        .gt-wallet {
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,.08);
            background: rgba(255,255,255,.03);
            padding: 10px 10px;
            margin-bottom: 10px;
        }
        .gt-wallet img { width: 28px; height: 28px; border-radius: 999px; }
        .gt-wallet-amount { font-weight: 900; }

        .gt-inputgroup { border-radius: 14px; overflow: hidden; }
        .gt-input {
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            color: rgba(255,255,255,.92) !important;
        }
        .gt-input::placeholder { color: rgba(255,255,255,.45); }
        .gt-input-addon {
            background: rgba(255,255,255,.03);
            border-left: 1px solid rgba(255,255,255,.08);
        }

        .gt-modal .modal-content,
        .gt-modal {
            background: rgba(15,18,25,.95);
            border: 1px solid rgba(255,255,255,.10);
            color: rgba(255,255,255,.92);
        }

        /* Mobile improvements */
        @media (max-width: 992px) {
            .gt-scroll { max-height: 260px; }
        }
        @media (max-width: 768px) {
            .gt-item { flex-direction: column; }
            .gt-status { justify-content: flex-end; }
            .gt-date { width: 100%; display:flex; justify-content: space-between; align-items:center; }
        }

        /* Select2 inside dark UI */
        .select2-container--default .select2-selection--single {
            background: rgba(255,255,255,.04) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
            border-radius: 12px !important;
            height: 42px !important;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            color: rgba(255,255,255,.92) !important;
            line-height: 40px !important;
        }
        .select2-dropdown {
            background: rgba(15,18,25,.98) !important;
            border: 1px solid rgba(255,255,255,.10) !important;
        }
        .select2-results__option { color: rgba(255,255,255,.86) !important; }
        .select2-results__option--highlighted.select2-results__option--selectable {
            background: rgba(210,164,75,.14) !important;
            color: #d2a44b !important;
        }
    </style>
@endpush

             
