@extends($activeTemplate . 'layouts.master')
@section('content')

<style>
    /* Hide old theme header/footer (CSS only) */
    header, footer, .navbar, .footer { display: none !important; }

    .gt-wrap{
        min-height:100vh;
        background:
            radial-gradient(900px 450px at 20% 20%, rgba(210,164,75,.14), transparent 65%),
            radial-gradient(700px 380px at 85% 35%, rgba(210,164,75,.10), transparent 70%),
            linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
        color: rgba(255,255,255,.92);
        font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
    }
    .gt-container{ max-width:1180px; margin:auto; padding:18px; }

    .gt-navbar{
        position: sticky; top: 12px; z-index: 999;
        backdrop-filter: blur(10px);
        background: rgba(15,18,25,.75);
        border: 1px solid rgba(255,255,255,.10);
        border-radius: 16px;
        padding: 12px 18px;
        display:flex; align-items:center; justify-content:space-between;
        box-shadow: 0 18px 55px rgba(0,0,0,.45);
    }
    .gt-logo{ display:flex; align-items:center; gap:10px; }
    .gt-logo-box{ width:34px; height:34px; border-radius:10px; background: linear-gradient(180deg,#d2a44b,#b9892e); }
    .gt-logo-text{ font-weight:900; letter-spacing:.5px; }

    .gt-lang{ display:flex; gap:6px; }
    .gt-lang a{
        padding:6px 12px; border-radius:999px; font-size:12px;
        text-decoration:none; color:rgba(255,255,255,.85);
        background: rgba(255,255,255,.06);
        border: 1px solid rgba(255,255,255,.10);
    }
    .gt-lang a:hover{ background: rgba(210,164,75,.14); color:#d2a44b; }

    .gt-card{
        background: rgba(255,255,255,.04);
        border: 1px solid rgba(255,255,255,.10);
        border-radius: 18px;
        padding: 18px;
        box-shadow: 0 18px 55px rgba(0,0,0,.35);
    }
    .gt-card:hover{ background: rgba(255,255,255,.05); }

    .gt-hero{ margin-top:22px; margin-bottom:18px; }
    .gt-hero h3{ font-weight:900; margin:0 0 6px; }
    .gt-muted{ color: rgba(255,255,255,.65); font-size:13px; line-height:1.7; margin:0; }

    /* Restyle existing cards without changing structure */
    .gt-wrap .card{
        background: rgba(255,255,255,.04) !important;
        border: 1px solid rgba(255,255,255,.10) !important;
        border-radius: 18px !important;
        box-shadow: 0 18px 55px rgba(0,0,0,.35);
        overflow: hidden;
    }
    .gt-wrap .card-header{
        background: rgba(255,255,255,.03) !important;
        border-bottom: 1px solid rgba(255,255,255,.10) !important;
        color: rgba(255,255,255,.92) !important;
    }
    .gt-wrap .card-body{ color: rgba(255,255,255,.92) !important; }

    .gt-wrap .text--base{ color: #d2a44b !important; }
    .gt-wrap .empty-thumb p{ color: rgba(255,255,255,.65) !important; }

    /* TreeView area */
    .gt-wrap .treeview-container{
        background: rgba(255,255,255,.02);
        border: 1px solid rgba(255,255,255,.08);
        border-radius: 16px;
        padding: 14px;
    }
    .gt-wrap .treeview{
        color: rgba(255,255,255,.88);
    }

    @media (max-width: 768px){
        .gt-navbar{ flex-wrap:wrap; gap:12px; }
        .gt-container{ padding: 14px; }
    }
</style>

<div class="gt-wrap">
    <div class="gt-container">

        {{-- ================= GT NAVBAR ================= --}}
        <div class="gt-navbar">
            <div class="gt-logo">
                <div class="gt-logo-box"></div>
                <div class="gt-logo-text">Golden Trade</div>
            </div>

            <div class="gt-lang">
                <a href="{{ route('lang', 'en') }}">EN</a>
                <a href="{{ route('lang', 'ar') }}">AR</a>
            </div>
        </div>

        {{-- ================= HERO ================= --}}
        <div class="gt-card gt-hero">
            <h3>{{ __($pageTitle) }}</h3>
            <p class="gt-muted">@lang('Manage your referral network and view your downline tree')</p>
        </div>

        {{-- ================= ORIGINAL CONTENT (kept, wrapped) ================= --}}
        <div class="gt-card">
            <div class="row gy-4">
                <div class="col-12">
                    <h4 class="mb-0" style="font-weight:900">{{ __($pageTitle) }}</h4>
                    <p class="gt-muted mt-2">@lang('Referral details and tree view')</p>
                </div>

                @if ($user->referrer)
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h4>@lang('You are referred by') <span class="text--base">{{ @$user->referrer->fullname }}</span></h4>
                        </div>
                    </div>
                </div>
                @endif

                <div class="col-md-12">
                    @if ($user->allReferrals->count() > 0 && $maxLevel > 0)
                        <div class="card">
                            <div class="card-header">
                                <h5 class="text-start"> @lang('Users Referred By Me')</h5>
                            </div>
                            <div class="card-body">
                                <div class="treeview-container">
                                    <ul class="treeview">
                                        <li class="items-expanded"> {{ $user->fullname }} ( {{ $user->username }} )
                                            @include($activeTemplate . 'partials.under_tree', [
                                                'user'    => $user,
                                                'layer'   => 0,
                                                'isFirst' => true,
                                            ])
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @else
                    <div class="card">
                        <div class="card-body p-5">
                            <div class="empty-thumb text-center">
                                <img src="{{ asset('assets/images/extra_images/empty.png') }}" />
                                <p class="fs-14">@lang('No data found')</p>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>

    </div>
</div>
@endsection

@push('style-lib')
    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'dashboard/css/jquery.treeView.css') }}">
@endpush

@push('script-lib')
    <script src="{{ asset($activeTemplateTrue . 'dashboard/js/jquery.treeView.js') }}"></script>
@endpush

@push('script')
    <script>
        (function($) {
            "use strict";
            $('.treeview').treeView();
        })(jQuery);
    </script>
@endpush
