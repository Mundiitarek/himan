@php
    $meta = (object) $meta;
    $pair = @$meta->pair;
@endphp

<style>
    /* Golden Trade - Trade History (scoped component) */
    .gt-history-card {
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.10);
        border-radius: 18px;
        box-shadow: 0 18px 55px rgba(0, 0, 0, 0.35);
        padding: 12px;
        position: relative;
        overflow: hidden;
    }

    .gt-history-card::before {
        content: "";
        position: absolute;
        inset: -1px;
        background:
            radial-gradient(900px 450px at 20% 20%, rgba(210, 164, 75, .14), transparent 65%),
            radial-gradient(700px 380px at 85% 35%, rgba(210, 164, 75, .10), transparent 70%);
        pointer-events: none;
        opacity: .85;
    }

    .gt-history-card>* {
        position: relative;
        z-index: 1;
    }

    .gt-history-title {
        margin: 0;
        font-weight: 900;
        font-size: 14px;
        letter-spacing: .2px;
        color: rgba(255, 255, 255, 0.92);
    }

    .gt-history-sub {
        margin-top: 6px;
        font-size: 12px;
        line-height: 1.8;
        color: rgba(255, 255, 255, 0.65);
    }

    .gt-history-head {
        margin-top: 10px;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.10);
        border-radius: 14px;
        padding: 10px 10px;
        color: rgba(255, 255, 255, 0.65);
        font-size: 12px;
        font-weight: 800;
    }

    /* Keep original classes, just restyle */
    .gt-history-card .history.trade-history {
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding-top: 10px;
    }

    .gt-history-card .history__list {
        margin: 0;
        padding: 10px 10px;
        border-radius: 14px;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.10);
        transition: background .18s ease;
        cursor: pointer;
    }

    .gt-history-card .history__list:hover {
        background: rgba(255, 255, 255, 0.05);
    }

    .gt-history-card .history__amount-item,
    .gt-history-card .history__price-item,
    .gt-history-card .history__date-item {
        font-size: 12px;
        line-height: 1.7;
        color: rgba(255, 255, 255, 0.86);
    }

    .gt-history-card .history__date-item {
        color: rgba(255, 255, 255, 0.65);
    }

    .gt-history-card .text-danger {
        color: rgba(255, 120, 120, 0.92) !important;
        font-weight: 900;
    }

    .gt-history-card .empty-thumb img {
        max-width: 120px;
        opacity: .9;
        filter: drop-shadow(0 18px 55px rgba(0, 0, 0, 0.35));
    }

    .gt-history-card .empty-sell {
        color: rgba(255, 255, 255, 0.65);
        font-size: 12px;
        margin-top: 10px;
    }
</style>

<div class="trading-right__bottom gt-history-card">
    <div class="trading-history">
        <h5 class="trading-history__title gt-history-title"> @lang('Trade History') </h5>
        <div class="gt-history-sub">
            @lang('Latest executed trades for this pair (live updates).')
        </div>
    </div>

    <div class="d-flex trading-market__header justify-content-between text-center gt-history-head">
        <div class="trading-market__header-two">
            @lang('Price')({{ $pair->market->currency->symbol }})
        </div>
        <div class="trading-market__header-one">
            @lang('Amount') ({{ $pair->coin->symbol }})
        </div>
        <div class="trading-market__header-three">
            @lang('Date/Time')
        </div>
    </div>

    <div class="tab-content" id="pills-tabContentfortyfour">
        <div class="tab-pane fade show active" id="pills-marketnineteen" role="tabpanel"
            aria-labelledby="pills-marketnineteen-tab" tabindex="0">
            <div class="market-wrapper">
                <div class="history  trade-history"></div>
            </div>
        </div>
    </div>
</div>

@if (!app()->offsetExists('trade_script'))
@php app()->offsetSet('trade_script',true) @endphp
@push('script')
    <script>
        "use strict";
        (function ($) {
            let pairSymbol    = "{{ $pair->symbol }}";
            let sellSideTrade = parseInt("{{ Status::SELL_SIDE_TRADE }}");


            function newTradeHmtl (data) {
               let trades=data.trade;

               let newHtml=``;
               $.each(trades, function (symbol, trade) {
                    if(pairSymbol != symbol){
                        return;
                    }
                    $.each(trade, function (i, element) {
                        newHtml+=`<ul class="history__list flex-between trade-history-item" data-rate="${element.rate}">
                        <li class="history__amount-item text-start ${ sellSideTrade == parseInt(element.trade_side) ? 'text-danger' : '' }">
                            ${showAmount(element.rate)}
                        </li>
                        <li class="history__price-item text-center"> ${showAmount(element.amount)} </li>
                        <li class="history__date-item"> ${new Date().toLocaleString()} </li>
                    </ul>`
                    });
               });
               $('.trade-history').prepend(newHtml);
            }
            pusherConnection('trade', newTradeHmtl);

            $('.trade-history').on('click','.trade-history-item',function (e) {
                let rate=$(this).data('rate');
                $('.buy-rate').val(getAmount(rate)).trigger('change');
                $('.buy-amount').val(1);
                $('.sell-amount').val(1);
                $('.sell-rate').val(getAmount(rate)).trigger('change');
            });

            function tradeHistory(){
                let action        = "{{ route('trade.history',':curSym') }}";

                $.ajax({
                    url: action.replace(':curSym',"{{@$pair->symbol}}"),
                    type: "GET",
                    dataType: 'json',
                    cache: false,
                    success: function (resp) {
                        let html=``;
                        if(resp.success){
                            if(resp.trades.length > 0){
                                $.each(resp.trades, function (i, trade) {
                                    html+=`<ul class="history__list flex-between trade-history-item" data-rate="${trade.rate}">
                                        <li class="history__amount-item text-start ${ sellSideTrade == parseInt(trade.trade_side) ? 'text-danger' : '' }">
                                            ${showAmount(trade.rate)}
                                        </li>
                                        <li class="history__price-item text-center"> ${showAmount(trade.amount)} </li>
                                        <li class="history__date-item"> ${trade.formatted_date} </li>
                                    </ul>`
                                    ;
                                });
                                $('.trade-history').removeClass('justify-content-center');
                            }else{
                                html+=`
                                <div class="empty-thumb">
                                    <img src="{{ asset('assets/images/extra_images/empty.png') }}"/>
                                    <p class="empty-sell">@lang('No trade found')</p>
                                </div>
                                `;
                                $('.trade-history').addClass('justify-content-center');
                            }
                        }
                        $('.trade-history').html(html);
                    }
                });
            }
            tradeHistory();
        })(jQuery);
    </script>
@endpush
@endif
