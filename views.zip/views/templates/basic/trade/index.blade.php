@extends($activeTemplate . 'layouts.frontend')

@section('content')
    <style>
        /* =========================================================
            Golden Trade - Page Redesign (INDEX) - Scoped
            IMPORTANT: Hide old header/footer ONLY (per rules)
        ========================================================== */
        header,
        footer {
            display: none !important;
        }

        .gt-wrap {
            min-height: 100vh;
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210, 164, 75, .14), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210, 164, 75, .10), transparent 70%),
                linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
            color: rgba(255, 255, 255, 0.92);
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
            padding: 26px 0 42px;
        }

        .gt-container {
            max-width: 1180px;
            margin: 0 auto;
            padding: 0 14px;
        }

        /* Navbar */
        .gt-navbar {
            position: sticky;
            top: 14px;
            z-index: 50;
            margin-bottom: 18px;
        }

        .gt-nav-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 12px 14px;
            border-radius: 16px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.10);
            backdrop-filter: blur(10px);
            box-shadow: 0 18px 55px rgba(0, 0, 0, 0.35);
        }

        .gt-brand {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: rgba(255, 255, 255, 0.92);
        }

        .gt-logo-box {
            width: 34px;
            height: 34px;
            border-radius: 12px;
            background: linear-gradient(180deg, #d2a44b, #b9892e);
            box-shadow: 0 18px 55px rgba(0, 0, 0, 0.35);
            display: grid;
            place-items: center;
            color: #1a1408;
            font-weight: 900;
            letter-spacing: .4px;
            flex: 0 0 auto;
        }

        .gt-brand-title {
            font-weight: 900;
            letter-spacing: .2px;
            line-height: 1.1;
        }

        .gt-brand-sub {
            font-size: 12px;
            color: rgba(255, 255, 255, 0.65);
            margin-top: 2px;
        }

        .gt-nav-actions {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .gt-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.10);
            color: rgba(255, 255, 255, 0.86);
            font-size: 12px;
            line-height: 1.6;
        }

        .gt-pill strong {
            color: rgba(210, 164, 75, 0.92);
            font-weight: 900;
        }

        .gt-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            border-radius: 14px;
            padding: 10px 14px;
            font-size: 12px;
            line-height: 1;
            font-weight: 900;
            text-decoration: none;
            cursor: pointer;
            user-select: none;
            white-space: nowrap;
        }

        .gt-btn-primary {
            background: linear-gradient(180deg, #d2a44b, #b9892e);
            color: #1a1408 !important;
            border: 0;
            box-shadow: 0 18px 55px rgba(0, 0, 0, 0.45);
        }

        .gt-btn-ghost {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.10);
            color: rgba(255, 255, 255, 0.86) !important;
        }

        /* Hero */
        .gt-hero {
            border-radius: 18px;
            padding: 16px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.10);
            box-shadow: 0 18px 55px rgba(0, 0, 0, 0.45);
            position: relative;
            overflow: hidden;
            margin-bottom: 16px;
        }

        .gt-hero::before {
            content: "";
            position: absolute;
            inset: -1px;
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210, 164, 75, .14), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210, 164, 75, .10), transparent 70%);
            pointer-events: none;
            opacity: .9;
        }

        .gt-hero>* {
            position: relative;
            z-index: 1;
        }

        .gt-hero-top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
            flex-wrap: wrap;
        }

        .gt-hero-title {
            font-size: 18px;
            font-weight: 900;
            margin: 0;
            letter-spacing: .2px;
        }

        .gt-hero-sub {
            margin-top: 6px;
            color: rgba(255, 255, 255, 0.65);
            font-size: 12px;
            line-height: 1.8;
        }

        /* Cards wrapper */
        .gt-card {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.10);
            border-radius: 18px;
            box-shadow: 0 18px 55px rgba(0, 0, 0, 0.35);
            padding: 12px;
            position: relative;
            overflow: hidden;
        }

        .gt-card:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        .gt-card-tight {
            padding: 10px;
        }

        /* Trading grid spacing (keep existing bootstrap layout, only restyle) */
        .gt-grid .row.gy-2 {
            --bs-gutter-y: 12px;
        }

        .gt-side-stack {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        /* Offcanvas redesign */
        .offcanvas#deposit-canvas {
            background:
                radial-gradient(900px 450px at 20% 20%, rgba(210, 164, 75, .14), transparent 65%),
                radial-gradient(700px 380px at 85% 35%, rgba(210, 164, 75, .10), transparent 70%),
                linear-gradient(180deg, #0b0f14 0%, #0a0d12 100%);
            color: rgba(255, 255, 255, 0.92);
            border-left: 1px solid rgba(255, 255, 255, 0.10);
        }

        .offcanvas#deposit-canvas .offcanvas-header {
            border-bottom: 1px solid rgba(255, 255, 255, 0.10);
        }

        .offcanvas#deposit-canvas .btn-close {
            opacity: 1;
        }

        .offcanvas#deposit-canvas .btn-close i {
            color: rgba(255, 255, 255, 0.75);
        }

        .offcanvas#deposit-canvas .form-label {
            color: rgba(255, 255, 255, 0.65);
            font-size: 12px;
            font-weight: 700;
        }

        .offcanvas#deposit-canvas .form--control,
        .offcanvas#deposit-canvas .form-control,
        .offcanvas#deposit-canvas .form-select {
            background: rgba(255, 255, 255, 0.04) !important;
            border: 1px solid rgba(255, 255, 255, 0.10) !important;
            border-radius: 14px !important;
            color: rgba(255, 255, 255, 0.92) !important;
            height: auto;
            padding: 12px 12px;
        }

        .offcanvas#deposit-canvas .input-group-text {
            background: rgba(255, 255, 255, 0.06) !important;
            border: 1px solid rgba(255, 255, 255, 0.10) !important;
            color: rgba(210, 164, 75, 0.92) !important;
            border-radius: 14px !important;
            font-weight: 900;
        }

        .offcanvas#deposit-canvas .list-group-item {
            background: rgba(255, 255, 255, 0.03) !important;
            border-color: rgba(255, 255, 255, 0.08) !important;
            color: rgba(255, 255, 255, 0.86) !important;
        }

        .offcanvas#deposit-canvas .deposit__button.btn {
            border-radius: 14px !important;
            border: 0 !important;
            background: linear-gradient(180deg, #d2a44b, #b9892e) !important;
            color: #1a1408 !important;
            font-weight: 900 !important;
            letter-spacing: .3px;
            box-shadow: 0 18px 55px rgba(0, 0, 0, 0.45);
            padding: 12px 14px;
        }

        .offcanvas#deposit-canvas .empty-gateway span .text--base {
            color: rgba(210, 164, 75, 0.92) !important;
        }
    </style>

    <div class="gt-wrap">
        <div class="gt-container">

            {{-- Custom Golden Trade Navbar (page-only) --}}
            <div class="gt-navbar">
                <div class="gt-nav-inner">
                    <a href="{{ url('/') }}" class="gt-brand">
                        <div class="gt-logo-box">GT</div>
                        <div>
                            <div class="gt-brand-title">Golden Trade</div>
                            <div class="gt-brand-sub">@lang('Dark Luxury Trading')</div>
                        </div>
                    </a>

                    <div class="gt-nav-actions">
                        <span class="gt-pill">
                            @lang('Pair'):
                            <strong>{{ @$pair->symbol }}</strong>
                        </span>
                        <span class="gt-pill">
                            @lang('Last'):
                            <strong>{{ getAmount(@$pair->marketData->price) }}</strong>
                        </span>

                        @auth
                            <a href="{{ route('user.home') }}" class="gt-btn gt-btn-ghost">@lang('Dashboard')</a>
                        @else
                            <a href="{{ route('user.login') }}" class="gt-btn gt-btn-ghost">@lang('Login')</a>
                            <a href="{{ route('user.register') }}" class="gt-btn gt-btn-primary">@lang('Register')</a>
                        @endauth
                    </div>
                </div>
            </div>

            {{-- Hero / Header card --}}
            <div class="gt-hero">
                <div class="gt-hero-top">
                    <div>
                        <h1 class="gt-hero-title">
                            @lang('Spot Trading') — {{ @$pair->symbol }}
                        </h1>
                        <div class="gt-hero-sub">
                            @lang('Live market updates, order book, chart and instant buy/sell in one luxury dark interface.')
                        </div>
                    </div>
                </div>
            </div>

            {{-- Original page structure preserved (x-components untouched) --}}
            <div class="gt-grid">
                <div class="row">
                    <x-flexible-view :view="$activeTemplate . 'trade.pair'" :meta="['pair' => $pair, 'screen' => 'small']" />

                    <div class="col-xl-9">
                        <div class="row gy-2">
                            <div class="col-xl-4 pe-lg-1">
                                <div class="gt-card gt-card-tight">
                                    <x-flexible-view :view="$activeTemplate . 'trade.order_book'" :meta="['pair' => $pair, 'screen' => 'big']" />
                                </div>
                            </div>

                            <div class="col-xl-8 col-md-7">
                                <div class="gt-card gt-card-tight mb-2">
                                    <x-flexible-view :view="$activeTemplate . 'trade.pair'" :meta="['pair' => $pair]" />
                                </div>

                                <div class="gt-card gt-card-tight mb-2">
                                    <x-flexible-view :view="$activeTemplate . 'trade.tab'" :meta="['screen' => 'small', 'markets' => $markets, 'pair' => $pair]" />
                                </div>

                                <div class="gt-card mb-2">
                                    <x-flexible-view :view="$activeTemplate . 'trade.buy_sell'" :meta="[
                                        'pair' => $pair,
                                        'marketCurrencyWallet' => $marketCurrencyWallet,
                                        'coinWallet' => $coinWallet,
                                        'screen' => 'big',
                                    ]" />
                                </div>

                                <div class="d-none d-md-block d-xl-none">
                                    <div class="trading-bottom__tab">
                                        <div class="gt-card gt-card-tight">
                                            <x-flexible-view :view="$activeTemplate . 'trade.tab'" :meta="['screen' => 'medium', 'markets' => $markets, 'pair' => $pair]" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-5 d-xl-none d-block p-0">
                                <div class="gt-card">
                                    <x-flexible-view :view="$activeTemplate . 'trade.buy_sell'" :meta="[
                                        'pair' => $pair,
                                        'marketCurrencyWallet' => $marketCurrencyWallet,
                                        'coinWallet' => $coinWallet,
                                        'screen' => 'medium',
                                    ]" />
                                </div>
                            </div>

                            <div class="col-sm-12 mt-0">
                                <div class="gt-card">
                                    <x-flexible-view :view="$activeTemplate . 'trade.my_order'" :meta="['pair' => $pair]" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 ps-lg-1">
                        <div class="gt-side-stack">
                            <div class="gt-card gt-card-tight">
                                <x-flexible-view :view="$activeTemplate . 'trade.pair_list'" :meta="['markets' => $markets]" />
                            </div>
                            <div class="gt-card gt-card-tight">
                                <x-flexible-view :view="$activeTemplate . 'trade.history'" :meta="['pair' => $pair]" />
                            </div>
                        </div>
                    </div>

                    <x-flexible-view :view="$activeTemplate . 'trade.buy_sell'" :meta="[
                        'pair' => $pair,
                        'marketCurrencyWallet' => $marketCurrencyWallet,
                        'coinWallet' => $coinWallet,
                        'screen' => 'small',
                    ]" />
                </div>
            </div>

        </div>
    </div>

    <div class="offcanvas offcanvas-end p-5" tabindex="-1" id="deposit-canvas" aria-labelledby="offcanvasLabel">
        <div class="offcanvas-header">
            <span class="fs-18">
                @lang('Deposit Money')
            </span>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close">
                <i class="fa fa-times-circle"></i>
            </button>
        </div>
        <div class="offcanvas-body">
            @auth
                <form action="{{ route('user.deposit.insert') }}" method="post">
                    @csrf
                    <input type="hidden" name="currency" class="deposit-currency-symbol">
                    <input type="hidden" value="spot" name="wallet_type">
                    <div class="form-group">
                        <label class="form-label">@lang('Amount')</label>
                        <div class="input-group">
                            <input type="number" step="any" class="form--control form-control" name="amount" required>
                            <span class="input-group-text deposit-currency-symbol"></span>
                        </div>
                    </div>
                    <div class="form-group position-relative">
                        <label class="form-label">@lang('Payment Gateway')</label>
                        <select class="form-control form--control form-select select2" name="gateway" required data-minimum-results-for-search="-1">
                        </select>
                    </div>
                    <div class="form-group preview-details d-none">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex flex-wrap justify-content-between">
                                <span>@lang('Limit')</span>
                                <span>
                                    <span class="min fw-bold">0</span>
                                    - <span class="max fw-bold">0</span>
                                    <span class="deposit-currency-symbol"></span>
                                </span>
                            </li>
                            <li class="list-group-item d-flex flex-wrap justify-content-between">
                                <span>@lang('Charge')</span>
                                <span>
                                    <span class="charge fw-bold">0</span>
                                    <span class="deposit-currency-symbol"></span>
                                </span>
                            </li>
                            <li class="list-group-item d-flex flex-wrap justify-content-between">
                                <span> @lang('Payable')</span>
                                <span>
                                    <span class="payable fw-bold">0</span>
                                    <span class="deposit-currency-symbol"></span>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <button class="deposit__button btn btn--base w-100" type="submit"> @lang('Submit') </button>
                </form>
                <div class="p-5 text-center empty-gateway">
                    <img src="{{ asset('assets/images/extra_images/no_money.png') }}" alt="">
                    <span class="mt-3 fs-14">
                        @lang('No payment gateway available for ')
                        <span class="text--base deposit-currency-symbol"></span>
                        @lang('Currency')
                    </span>
                </div>
            @else
                <div class="p-5 text-center d-flex flex-column align-items-center justify-content-center h-100">
                    <img src="{{ asset('assets/images/extra_images/user.png') }}">
                    <span class="fs-12">@lang('Login required for deposit money')</span>
                    <div class="mt-3">
                        <a class="fs-12 text--base" href="{{ route('user.login') }}">@lang('Login')</a>
                        <span>@lang('or')</span>
                        <a class="fs-12 text--base" href="{{ route('user.register') }}">@lang('Register')</a>
                    </div>
                </div>
            @endauth
        </div>
    </div>
@endsection


@push('script-lib')
    <script src="{{ asset('assets/global/js/pusher.min.js') }}"></script>
    <script src="{{ asset('assets/global/js/broadcasting.js') }}"></script>
    <script src="{{ asset('assets/global/js/select2.min.js') }}"></script>
@endpush

@push('style-lib')
    <link rel="stylesheet" href="{{ asset('assets/global/css/select2.min.css') }}">
@endpush

@push('script')
    <script>
        "use strict";



        $.each($('.select2'), function(index, element) {
            $(element).select2({
                dropdownParent: $(this).closest('.position-relative')
            });
        });

        $('.new--deposit').on('click', function(e) {

            @auth
            let currency = $(this).data('currency');
            let gateways = @json($gateways);
            let currencyGateways = gateways.filter(ele => ele.currency == currency);
            

            if (currencyGateways && currencyGateways.length > 0) {
                let gatewaysOption = "";
                $.each(currencyGateways, function(i, currencyGateway) {
                    gatewaysOption += `<option value="${currencyGateway.method_code}"  data-gateway='${JSON.stringify(currencyGateway)}' >
                            ${currencyGateway.name}
                        </option>`;
                });
                $("#deposit-canvas").find('select[name=gateway]').html(gatewaysOption);
                $("#deposit-canvas").find('.deposit-currency-symbol').val(currency);

                $("#deposit-canvas").find(".empty-gateway").addClass('d-none');
                $("#deposit-canvas").find("form").removeClass('d-none');
            } else {
                $("#deposit-canvas").find(".empty-gateway").removeClass('d-none');
                $("#deposit-canvas").find("form").addClass('d-none');
            }
            $("#deposit-canvas").find('.deposit-currency-symbol').text(currency);
        @endauth
        var myOffcanvas = document.getElementById('deposit-canvas');
        var bsOffcanvas = new bootstrap.Offcanvas(myOffcanvas).show();
        });

        @auth
        $('#deposit-canvas').on('change', 'select[name=gateway]', function() {

            if (!$(this).val()) {
                $('#deposit-canvas .preview-details').addClass('d-none');
                return false;
            }

            var resource = $('select[name=gateway] option:selected').data('gateway');
            var fixed_charge = parseFloat(resource.fixed_charge);
            var percent_charge = parseFloat(resource.percent_charge);
            var rate = parseFloat(resource.rate);
            var amount = parseFloat($('#deposit-canvas input[name=amount]').val());

            $('#deposit-canvas .min').text(getAmount(resource.min_amount));
            $('#deposit-canvas .max').text(getAmount(resource.max_amount));


            if (!amount) {
                $('#deposit-canvas .preview-details').addClass('d-none');
                return false;
            }

            $('#deposit-canvas .preview-details').removeClass('d-none');

            var charge = parseFloat(fixed_charge + (amount * percent_charge / 100));
            var payable = parseFloat((parseFloat(amount) + parseFloat(charge)));

            $("#deposit-canvas").find(".empty-gateway").addClass('d-none');
            $("#deposit-canvas").find("form").removeClass('d-none');

            $('#deposit-canvas .charge').text(getAmount(charge));
            $('#deposit-canvas .payable').text(getAmount(payable));

            $('#deposit-canvas .method_currency').text(resource.currency);
            $('#deposit-canvas input[name=amount]').on('input');

        });

        $('#deposit-canvas').on('input', 'input[name=amount]', function() {
            var data = $('#deposit-canvas select[name=gateway]').change();
            $('#deposit-canvas .amount').text(parseFloat($(this).val()).toFixed(2));
        });
        @endauth

        pusherConnection('market-data', marketChangeHtml);

        var swiper = new Swiper(".myswiper-two", {
            slidesPerView: 5,
            spaceBetween: 0,
            navigation: {
                nextEl: ".swiper-button-next-two",
                prevEl: ".swiper-button-prev-two",
            },
            breakpoints: {
                575: {
                    slidesPerView: 7,
                    spaceBetween: 0,
                },
                992: {
                    slidesPerView: 7,
                    spaceBetween: 0,
                },
            },
        });

        window.visit_pair = {
            selection: "{{ @$pair->marketData->id }}",
            symbol: "{{ @$pair->symbol }}",
            site_name: "{{ __(gs('site_name')) }}"
        };

        $('header').find(`.container`).addClass(`custom--container`);

// ================== TwelveData Live Price ==================
(function ($) {

    function toTwelveSymbol(pairSymbol) {
        if (!pairSymbol) return null;

        let s = pairSymbol.replace('_', '/');
        s = s.replace('USDT', 'USD');
        return s.replace('/', '-'); // BTC-USD
    }

    function updateFromTwelve() {
        if (!window.visit_pair || !window.visit_pair.symbol) return;

        let td = toTwelveSymbol(window.visit_pair.symbol);
        if (!td) return;

        fetch(`/api/td/quote/${td}`)
            .then(r => r.json())
            .then(res => {
                if (!res || !res.success || !res.data) return;

                let p = parseFloat(res.data.close);
                if (!p || isNaN(p)) return;

                window.marketPrice = p;

                // تحديث السعر في Market order inputs
                if ($('.buy-rate').is('[readonly]')) $('.buy-rate').val(p).trigger('change');
                if ($('.sell-rate').is('[readonly]')) $('.sell-rate').val(p).trigger('change');
            })
            .catch(() => {});
    }

    updateFromTwelve();
    setInterval(updateFromTwelve, 5000);

})(jQuery);

    </script>
@endpush


@push('style')
    <style>
        .cookies-card {
            background-color: #181d20 !important;
            color: #93988f !important;
        }

        .has-mega-menu .mega-menu {
            background: #181d20 !important;
        }

        .select2-image {
            max-width: 35px;
        }


        /* ////////////////// select 2 //////////////// */
        .select2-dropdown {
            background-color: #09171a;
            border-color: hsl(var(--white)/0.14);
        }

        .select2-container--default .select2-search--dropdown .select2-search__field {
            border-radius: 6px;
            font-weight: 400;
            outline: none;
            width: 100%;
            padding: 10px;
            background-color: transparent;
            border-color: hsl(var(--white) / 0.2) !important;
            color: #fff !important;
            line-height: 1;
            margin: 10px 0px;
        }

        .select2-container--default .select2-selection--single {
            background-color: transparent !important;
            border-color: hsl(var(--white)/0.14);
            height: 52px;
            padding: 10px 0px;

        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            color: hsl(var(--body-color)) !important;
        }

        .select2-container .selection {
            width: 100%;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            top: 11px !important;
            right: 5px !important;
        }

        .select2-container--default .select2-results__option--selected {
            background-color: hsl(var(--base-d-400)) !important;
        }
    </style>
@endpush
