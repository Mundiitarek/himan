<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class TwelveDataService
{
    private string $key;
    private string $baseUrl;

    public function __construct()
    {
        $this->key     = config('services.twelvedata.key');
        $this->baseUrl = rtrim(config('services.twelvedata.base_url'), '/');
    }

    /**
     * Get quote for single symbol
     */
    public function quote(string $symbol): array
    {
        $resp = Http::timeout(10)->get($this->baseUrl . '/quote', [
            'symbol' => $symbol,
            'apikey' => $this->key,
        ]);

        if (!$resp->ok()) {
            throw new \RuntimeException("HTTP Error: " . $resp->status());
        }

        $data = $resp->json();

        if (isset($data['status']) && $data['status'] === 'error') {
            throw new \RuntimeException($data['message'] ?? 'TwelveData error');
        }

        return $data;
    }

    /**
     * Get quotes for multiple symbols (batch request)
     */
    public function quotes(array $symbols): array
    {
        // TwelveData batch quotes: symbols=EUR/USD,GBP/USD,...
        $symbolsStr = implode(',', $symbols);

        $resp = Http::timeout(10)->get($this->baseUrl . '/quote', [
            'symbol' => $symbolsStr,
            'apikey' => $this->key,
        ]);

        if (!$resp->ok()) {
            throw new \RuntimeException("HTTP Error: " . $resp->status());
        }

        $data = $resp->json();

        // TwelveData بيرجعها غالبًا بالشكل:
        // { "EUR/USD": {...}, "GBP/USD": {...} }
        // أو لو في error: { "status": "error", "message": "..." }
        if (isset($data['status']) && $data['status'] === 'error') {
            throw new \RuntimeException($data['message'] ?? 'TwelveData error');
        }

        return $data ?? [];
    }

    /**
     * Helper method للـ GET requests (optional - لو عايز تعمل abstraction)
     */
    private function get(string $endpoint, array $params = []): array
    {
        $params['apikey'] = $this->key;

        $resp = Http::timeout(10)->get($this->baseUrl . $endpoint, $params);

        if (!$resp->ok()) {
            throw new \RuntimeException("HTTP Error: " . $resp->status());
        }

        $data = $resp->json();

        if (isset($data['status']) && $data['status'] === 'error') {
            throw new \RuntimeException($data['message'] ?? 'TwelveData error');
        }

        return $data;
    }
}